/**
 * 支付模块 qtd-pay-container-v4 静态演示（无 jQuery / 无 Swiper）
 * 演示数据内联为 PAY_V4_MOCK（与 docs/demo/data/pay-v4.mock.json 同源，可直接 file:// 打开页面）
 */
(function () {
  var BG_SVG =
    '<svg class="bg" xmlns="http://www.w3.org/2000/svg" width="181" height="142" viewBox="0 0 181 142" fill="none"><g filter="url(#filter0_d_paybg)"><path d="M1.91122 15.1984C1.9121 6.80432 8.71712 0 17.1112 0H100.893C104.156 0 107.334 1.05059 109.954 2.99636L128.111 16.4786C130.732 18.4244 133.909 19.475 137.173 19.475H163.387C171.782 19.475 178.587 26.2793 178.587 34.6734L178.597 121.598C178.598 129.994 171.792 136.8 163.397 136.8H17.1C8.70467 136.8 1.89915 129.994 1.90004 121.598L1.91122 15.1984Z" fill="white"/></g><defs><filter id="filter0_d_paybg" x="-9.75132e-05" y="0" width="180.497" height="141.55" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feMorphology radius="3.8" operator="erode" in="SourceAlpha" result="effect1_dropShadow"/><feOffset dy="2.85"/><feGaussianBlur stdDeviation="2.85"/><feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.12 0"/><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow"/><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow" result="shape"/></filter></defs></svg>';

  var ACTIVE_BG_SVG =
    '<svg class="active-bg" xmlns="http://www.w3.org/2000/svg" width="215" height="171" viewBox="0 0 215 171" fill="none"><g filter="url(#filter0_d_payab)"><path d="M8.01305 21.9983C8.01398 13.1624 15.1771 6 24.013 6H119.856C123.292 6 126.636 7.10589 129.394 9.15406L150.437 24.7787C153.195 26.8269 156.54 27.9328 159.975 27.9328H190.986C199.822 27.9328 206.985 35.0952 206.986 43.9311L206.997 144.063C206.998 152.9 199.834 160.065 190.997 160.065H24.0002C15.163 160.065 7.99929 152.9 8.00022 144.063L8.01305 21.9983Z" fill="url(#paint0_linear_payab)"/><path d="M119.856 3.86035C123.751 3.86037 127.543 5.11446 130.67 7.43652L151.712 23.0605C154.102 24.8348 156.999 25.7929 159.975 25.793H190.986C201.003 25.793 209.124 33.9132 209.125 43.9307L209.136 144.062C209.137 154.082 201.016 162.204 190.997 162.204H24.0005C13.9814 162.204 5.85979 154.082 5.86084 144.062L5.87354 21.998C5.87462 11.9805 13.9956 3.86035 24.0132 3.86035H119.856Z" stroke="#4CAF50" stroke-width="4.27957"/></g><defs><filter id="filter0_d_payab" x="0.000273228" y="0" width="214.997" height="170.065" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feMorphology radius="4.27957" operator="erode" in="SourceAlpha" result="effect1_dropShadow"/><feOffset dy="2"/><feGaussianBlur stdDeviation="4"/><feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.12 0"/><feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow"/><feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow" result="shape"/></filter><linearGradient id="paint0_linear_payab" x1="107.499" y1="6" x2="107.499" y2="160.065" gradientUnits="userSpaceOnUse"><stop stop-color="#E8F5E9"/><stop offset="1" stop-color="white"/></linearGradient></defs></svg>';

  var NAME_SVG =
    '<svg xmlns="http://www.w3.org/2000/svg" width="72" height="8" viewBox="0 0 72 8" fill="none"><path d="M0.79834 6.79861C5.24879 4.26393 10.3338 3.06135 15.4482 3.33401L49.2337 5.13522C56.6726 5.53181 64.091 4.03999 70.7983 0.798607" stroke="#A7F806" stroke-width="1.59685" stroke-linecap="round"/></svg>';

  var PAY_V4_MOCK = {
    source: 'docs/demo/data/sponsor.mock.json（节选 page_type=34 / pageconfig.vipTypeInfo / goods vip_type=34）',
    page_type: 34,
    vipTypeTabs: [
      { id: 24, name: '个人全站VIP', cardIdx: 0, defaultShow: true },
      { id: 29, name: '个人超级SVIP', cardIdx: 1, defaultShow: true },
      { id: 998, name: '企业商用VIP基础版', cardIdx: 2, defaultShow: true },
      { id: 34, name: 'AI创作VIP', cardIdx: 3, defaultShow: true }
    ],
    vipTypeInfo: {
      '24': {
        headText:
          "<img src='https://static.qiantucdn.com/assets/newVipIcon/vip-icon-4.png' alt=''><span>开通VIP会员</span>｜2,090万作品畅享海量下载，每日更新500+",
        rights: [
          "<p><em class='number'>2,090</em><em>万作品下载</em></p><p>支持<i class='mf'>免费</i><i class='mf'>限免</i><i class='gr'>VIP</i>作品</p>",
          '不支持',
          '<p>AI工具</p><p>最高10次/天</p>',
          '<p>新作7天抢先用</p><p>最近上新18,212张</p>',
          '<p><img src="https://static.qiantucdn.com/assets/newVipIcon/vip-icon-4.png?t=1" alt=""></p>',
          '<p><em>无授权（限交流学习）</em></p>'
        ]
      },
      '29': {
        headText:
          "<img src='https://static.qiantucdn.com/assets/newVipIcon/vip-icon-3-1.png' alt=''><span>开通VIP会员</span>｜3,733万作品畅享海量下载，每日更新500+",
        rights: [
          "<p><em class='number'>3,733</em><em>万作品下载</em></p><p>支持<i class='mf'>免费</i><i class='mf'>限免</i><i class='gr'>VIP</i><i class='qyxm'>企业限免</i></p>",
          '不支持',
          '<p>云设计/抠图工具</p><p>10次/天 或 海量</p>',
          '<p>新作7天抢先用</p><p>最近上新18,212张</p>',
          '<p><img src="https://static.qiantucdn.com/assets/newVipIcon/vip-icon-3.png?t=1" alt=""></p>',
          '<p><em>无授权（限交流学习）</em></p>'
        ]
      },
      '998': {
        headText:
          "<img src='https://static.qiantucdn.com/assets/newVipIcon/qy-vip-icon.png' alt=''><span>开通VIP会员</span>｜3,932万作品畅享海量下载，商用授权有保障",
        rights: [
          "<p><em class='number'>3,932</em><em>万作品下载</em></p><p>支持<i class='mf'>免费</i><i class='mf'>限免</i><i class='gr'>VIP</i><i class='qyxm'>企业限免</i><i class='qyzx'>企业专享</i></p>",
          "<p>企业专享作品</p><p><em class='number'>199</em><em>万作品</em></p>",
          '<p>云设计/抠图工具</p><p>5次/天 起量</p>',
          '<p>新作7天抢先用</p><p>最近上新18,212张</p>',
          '<p><img src="https://static.qiantucdn.com/assets/newVipIcon/vip-icon-1.png?t=1" alt=""></p>',
          '<p>商用授权</p><p>个人/注资100万以下主体</p>'
        ]
      },
      '34': {
        headText:
          "<img src='https://static.qiantucdn.com/assets/newVipIcon/vip-icon-10.png' alt=''><span>开通VIP会员</span>｜支持千图AI工具（AI绘画、智能抠图）的创作与使用。",
        rights: [
          "<p><em>全网<i class='b'>65+</i>模型</em> <a href='https://ai.58pic.com/pricing' target='_blank' rel='noopener'>明细</a> &gt; </p><p>最新最热最火模型实时同步，图片/视频/音乐/3D全涵盖。</p>",
          "<p><em><i class='b'>VIP快速</i>生成通道</em></p><p>会员通道 加速生成</p>",
          '<p><em>202,134 模板一键同款</em></p><p>全站作品不写提示词一键复制</p>',
          "<p><em>最高支持<i class='b'>4K</i>高清生成</em></p><p>高清大图一步到位</p>",
          '<p><img src="https://static.qiantucdn.com/assets/newVipIcon/qy-vip-icon.png?t=1" alt=""></p>',
          "<p><em>同时生成<i class='b'>2</i>个任务</em></p><p>多任务并发生成提效100%</p>"
        ]
      }
    },
    goods: [
      {
        id: '1605',
        original_price: 39,
        sale_price: 39,
        vip_type: '34',
        is_renew: '0',
        days: '1',
        tag: '',
        text_limit: '总到账200点',
        is_upgrade_commercial_use: 0
      },
      {
        id: '1776',
        original_price: 39,
        sale_price: 29,
        vip_type: '34',
        is_renew: '1',
        days: '1',
        tag: '赠1月下载VIP',
        text_limit: '总到账200点',
        is_upgrade_commercial_use: 0,
        first_price: 29,
        everytime_price: 39
      },
      {
        id: '1775',
        original_price: 99,
        sale_price: 99,
        vip_type: '34',
        is_renew: '0',
        days: '12',
        tag: '赠1年下载VIP',
        text_limit: '总到账1200点',
        is_upgrade_commercial_use: 0
      },
      {
        id: '1606',
        original_price: 199,
        sale_price: 199,
        vip_type: '34',
        is_renew: '0',
        days: '12',
        tag: '赠1年海量下载VIP',
        text_limit: '总到账2400点',
        is_upgrade_commercial_use: 0
      },
      {
        id: '1604',
        original_price: 299,
        sale_price: 299,
        vip_type: '34',
        is_renew: '0',
        days: '12',
        tag: '赠1年海量超级SVIP',
        text_limit: '总到账2800点',
        is_upgrade_commercial_use: 0
      },
      {
        id: '1774',
        original_price: 499,
        sale_price: 499,
        vip_type: '34',
        is_renew: '0',
        days: '12',
        tag: '赠终身超级SVIP',
        text_limit: '总到账5000点',
        is_upgrade_commercial_use: 0
      }
    ],
    defaultProductId: '1776',
    qrData: 'https://www.58pic.com/index.php?m=sponsor&a=indexnew&page_type=34'
  };

  function productTitle(item) {
    if (item.is_upgrade_commercial_use) return '老用户专享';
    var d = String(item.days);
    if (String(item.is_renew) === '1') {
      return d === '12' ? '连续包年' : '连续包月';
    }
    if (d === '70') return '终身卡';
    if (d === '1') return '月卡';
    if (d === '3') return '3月卡';
    if (d === '36') return '3年卡';
    if (d === '48') return '4年卡';
    if (d === '24') return '2年卡';
    if (d === '12') return '年卡';
    return '套餐';
  }

  function renderProductCard(item) {
    var title = productTitle(item);
    var showTag = item.tag || item.is_upgrade_commercial_use;
    var tagText = item.is_upgrade_commercial_use
      ? '升级' + (item.upgrade_commercial_use_day || '') + '天'
      : item.tag || '';
    var strike =
      Number(item.original_price) !== Number(item.sale_price)
        ? '&nbsp;<i>&yen;' +
          item.original_price +
          '</i>'
        : '';
    return (
      '<div class="swiper-slide info-box" data-vip_type="' +
      item.vip_type +
      '" data-shop-id="' +
      item.id +
      '" data-is_renew="' +
      item.is_renew +
      '" data-sale_price="' +
      item.sale_price +
      '" data-original_price="' +
      item.original_price +
      '">' +
      '<div class="info">' +
      '<p class="name"><span>' +
      title +
      '</span><em>' +
      title +
      '</em>' +
      NAME_SVG +
      '</p>' +
      (showTag
        ? '<p class="tag active">' + tagText + '</p>'
        : '') +
      '<p class="price-box">&yen;<em>' +
      item.sale_price +
      '</em>' +
      strike +
      '</p>' +
      '<p class="limit">' +
      (item.text_limit || '') +
      '</p>' +
      '</div>' +
      '<img class="zuanshi" src="https://static.qiantucdn.com/static/images/ringing/ringingK/icon/item' +
      item.vip_type +
      '.png?1" alt=""/>' +
      BG_SVG +
      ACTIVE_BG_SVG +
      '</div>'
    );
  }

  function containerDataType(pageType) {
    if (pageType === 29) return '2';
    if (pageType === 998 || pageType === 999) return '3';
    if (pageType === 34 || pageType === 341) return '4';
    return '1';
  }

  function bindProductClicks(root, onSelect) {
    root.querySelectorAll('.product-swiper .info-box').forEach(function (el) {
      el.addEventListener('click', function (e) {
        e.preventDefault();
        root.querySelectorAll('.product-swiper .info-box').forEach(function (x) {
          x.classList.remove('active');
        });
        el.classList.add('active');
        onSelect(el);
      });
    });
  }

  function updatePaySide(root, el, mock) {
    var sale = el.getAttribute('data-sale_price');
    var orig = el.getAttribute('data-original_price');
    var priceEl = root.querySelector('.pay-price');
    var total = priceEl && priceEl.querySelector('.total-price');
    var discount = root.querySelector('.discount-price');
    if (total) total.textContent = sale;
    if (priceEl) priceEl.classList.add('active');
    if (discount) {
      var off = Math.max(0, Number(orig) - Number(sale));
      discount.setAttribute('data-price', String(off));
      discount.innerHTML = off > 0 ? '已减<em>' + off + '</em>元' : '已减<em>0</em>元';
    }
    var renew = root.querySelector('.is-renew-box');
    var ai = root.querySelector('.is-ai-box');
    if (renew) {
      var isRenew = String(el.getAttribute('data-is_renew')) === '1';
      renew.classList.toggle('active', isRenew);
      if (isRenew && mock && mock.goods) {
        var pid = el.getAttribute('data-shop-id');
        var p = mock.goods.find(function (g) {
          return String(g.id) === String(pid);
        });
        var emEl = renew.querySelector('em');
        if (emEl && p && p.everytime_price) {
          emEl.textContent = p.everytime_price;
        }
      }
    }
    if (ai) {
      var pid = el.getAttribute('data-shop-id');
      var p = mock.goods.find(function (g) {
        return String(g.id) === String(pid);
      });
      if (p && p.total_limit) {
        ai.classList.add('active');
        ai.textContent =
          '*总到账约 ' + p.total_limit + ' AI点（节选 sponsor.mock.json）';
      } else {
        ai.classList.remove('active');
      }
    }
  }

  function renderVipProductDesc(root, pageType, info) {
    var wrap = root.querySelector('.vip-product-desc');
    if (!wrap || !info) return;
    wrap.setAttribute('data-type', pageType);
    if (pageType === 34) {
      var tpl = document.getElementById('tpl-desc-34');
      if (tpl) wrap.innerHTML = tpl.innerHTML;
      var active = root.querySelector('.product-swiper .info-box.active');
      var pid = active && active.getAttribute('data-shop-id');
      var g =
        window.__payMock &&
        window.__payMock.goods &&
        window.__payMock.goods.find(function (x) {
          return String(x.id) === String(pid);
        });
      var conc = wrap.querySelector('#pay-ai-concurrent');
      if (conc && g && g.ai_concurrent_limit != null) {
        conc.textContent = g.ai_concurrent_limit;
      }
      return;
    }
    var r = info.rights || [];
    wrap.innerHTML =
      '<div class="title"><p>解锁特权<em></em></p><a class="name" href="https://www.58pic.com/pricing/" target="_blank" rel="noopener">VIP会员尊享 <em>30+</em>项VIP特权<i class="icon icon-xiangxia"></i></a></div>' +
      '<div class="product-desc-info">' +
      '<div class="desc-item" style="padding:16px;border-radius:16px;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.1)">' +
      '<div class="left" style="flex:1;min-width:0"><div class="info">' +
      (r[0] || '') +
      '</div></div></div></div>';
  }

  function bindTabs(root, mock) {
    var tabs = root.querySelectorAll('.vip-type-header .vip-type-item');
    var cards = root.querySelectorAll('.head-content .card-box .translate-box .swiper-slide');
    var cardBox = root.querySelector('.head-content .card-box .translate-box');
    var idx = 0;
    function goCard(i) {
      idx = Math.max(0, Math.min(i, cards.length - 1));
      if (cardBox) cardBox.style.transform = 'translateX(' + -idx * 240 + 'px)';
      root.querySelectorAll('.card-box .left svg, .card-box .right svg').forEach(function (svg, k) {
        svg.parentElement.classList.toggle('swiper-button-disabled', k === 0 ? idx === 0 : idx >= cards.length - 1);
      });
    }
    var prev = root.querySelector('.swiper-product-prev');
    var next = root.querySelector('.swiper-product-next');
    var left = root.querySelector('.card-box .left');
    var right = root.querySelector('.card-box .right');
    if (left)
      left.addEventListener('click', function () {
        goCard(idx - 1);
      });
    if (right)
      right.addEventListener('click', function () {
        goCard(idx + 1);
      });

    var pswiper = root.querySelector('.product-swiper');
    if (prev && pswiper) {
      prev.addEventListener('click', function () {
        pswiper.scrollBy({ left: -200, behavior: 'smooth' });
      });
    }
    if (next && pswiper) {
      next.addEventListener('click', function () {
        pswiper.scrollBy({ left: 200, behavior: 'smooth' });
      });
    }

    tabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        var t = Number(tab.getAttribute('data-type'));
        tabs.forEach(function (x) {
          x.classList.remove('active');
        });
        tab.classList.add('active');
        root.setAttribute('data-type', containerDataType(t));
        var list = mock.vipTypeTabs || [];
        var ci = list.find(function (x) {
          return x.id === t;
        });
        if (ci) goCard(ci.cardIdx || 0);
        var info = mock.vipTypeInfo[String(t)];
        renderVipProductDesc(root, t, info);
      });
    });
    var t0 = root.querySelector('.vip-type-item.active');
    if (t0 && mock.vipTypeTabs) {
      var id0 = Number(t0.getAttribute('data-type'));
      var row0 = mock.vipTypeTabs.find(function (x) {
        return x.id === id0;
      });
      if (row0) goCard(row0.cardIdx || 0);
    }
  }

  function main(mock) {
    window.__payMock = mock;
    var root = document.querySelector('.qtd-pay-container-v4');
    if (!root) return;
    var swiperWrap = root.querySelector('.product-swiper .swiper-wrapper');
    if (swiperWrap && mock.goods) {
      swiperWrap.innerHTML = mock.goods.map(renderProductCard).join('');
    }
    var showNav = mock.goods && mock.goods.length > 3;
    root.querySelectorAll('.swiper-product-btn').forEach(function (b) {
      b.style.display = showNav ? 'flex' : 'none';
    });
    var defaultId = mock.defaultProductId || (mock.goods[0] && mock.goods[0].id);
    bindProductClicks(root, function (el) {
      updatePaySide(root, el, mock);
      var at = root.querySelector('.vip-type-item.active');
      var pt = at && Number(at.getAttribute('data-type'));
      if (pt === 34) {
        renderVipProductDesc(root, 34, mock.vipTypeInfo['34']);
      }
    });
    var first = root.querySelector('.product-swiper .info-box[data-shop-id="' + defaultId + '"]');
    if (first) {
      first.classList.add('active');
      updatePaySide(root, first, mock);
    } else if (root.querySelector('.product-swiper .info-box')) {
      var el0 = root.querySelector('.product-swiper .info-box');
      el0.classList.add('active');
      updatePaySide(root, el0, mock);
    }
    renderVipProductDesc(root, mock.page_type, mock.vipTypeInfo[String(mock.page_type)]);
    bindTabs(root, mock);
    var qr = root.querySelector('.pay-code .code');
    if (qr && mock.qrData) {
      qr.innerHTML =
        '<img src="https://api.qrserver.com/v1/create-qr-code/?size=128x128&data=' +
        encodeURIComponent(mock.qrData) +
        '" width="128" height="128" alt="支付二维码演示"/>';
    }
  }

  function load() {
    main(PAY_V4_MOCK);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', load);
  else load();
})();
