# docs/demo 模块说明

本目录遵循 Cursor Skill **`multi-page-static-ui-demo`**（与 **demo 切片** 同构）：根目录 `theme.css` + `MODULES.md` + `index.html` + `modules/mod-NN-<slug>.*`。

- **线上参考**：[千图网首页](https://www.58pic.com/)
- **主题变量来源**：`Client/lib/base/theme.scss`（`--qtd-*`）
- **边界**：纯静态 UI，无接口、无登录态；外链图为 CDN / picsum 占位。

---

## 文件一览

| 文件 | 职责 |
|------|------|
| `theme.css` | 全局 CSS 变量（色板、过渡、头部高度、`--z-index-*` 等） |
| `index.html` | **单页串联**：整页 DOM + 按序 `link` 全部 `mod-*.css` |
| `MODULES.md` | 本说明（文件一览、页面对照、模块对照、主题摘要） |
| `modules/mod-00-base.css` | 重置、字体、`demo-w1200` / `demo-section-title` 等基础类 |
| `modules/mod-01-iconfont.css` | 阿里 iconfont `font_504266_dzom6i255a` |
| `modules/mod-02-site-header.*` | 顶栏 + Hero（搜索 Tab、搜索条、工具矩阵占位） |
| `modules/mod-03-card-tool.*` | 工具矩阵小卡片（单卡片段示例） |
| `modules/mod-04-card-poster.*` | 运营海报条 + `.demo-row-posters` 纵向列表 |
| `modules/mod-05-card-material.*` | 素材/套图卡 + `.demo-grid-materials` |
| `modules/mod-06-site-footer.*` | 页脚 |
| `modules/mod-07-section-promo.*` | 为你推荐 + Tab |
| `modules/mod-08-section-calendar.*` | 营销日历 |
| `modules/mod-09-section-ai-banner.*` | AI 通栏 |
| `modules/mod-10-section-workflow.*` | 工作流卡片 |
| `modules/mod-11-section-industry.*` | 行业专区 |
| `modules/mod-12-section-series.*` | 套图系列 + chip |
| `modules/mod-13-section-commercial.*` | 商用版权 CTA |
| `modules/mod-14-section-hot-tags.*` | 热门搜索标签云 |
| `modules/mod-15-enterprise-switch-dialog.*` | **企业版切换身份**：`QtdDialog` 壳 + 内层对齐 `qySwitchStyle.scss`（`.logo-info-qiye.new-qiye-box-dialog.new-qiye-box-list`、`current-info-box`、`qiye-box-list` / `qiye-box-li`），`.content` 宽 400px |
| `modules/mod-16-newInfoBase-compiled.css` | **顶栏用户信息下拉**主样式：**演示裁剪版**（仅保留 `user-info-dropdown` / `mod-16-user-info-panel` 出现的类，个人 `gr` 主题）；全量以 `qtd-header-v2/public/_newInfoBaseV2.scss` 为准 |
| `modules/mod-16-user-info-shell.css` | 演示用：`.func-info-box.is-user-info` 定位 + 切换身份列表 flex 补缺 |
| `modules/mod-16-user-info-panel.html` | 可复制片段：`.func-info-box.is-user-info` 内 DOM，对齐 `newUserInfoV2.tmpl` |
| `modules/mod-17-pay-v4.css` | **支付弹层** `qtd-pay-container-v4`：内容与 `Client/Tpl/V3/ringingK/components/pay.scss` 同步，末尾含无 Swiper 横向滚动补丁；更新可运行 `node scripts/sync-pay-demo-css.cjs` |
| `modules/mod-17-pay-v4-page.css` | 演示页留白与阴影（对齐 `ringingK.scss` 中 `.ringing-box`） |
| `modules/pay-v4.demo.js` | 支付静态演示：加载 `pay-v4.mock.json`、渲染商品卡、Tab/头图卡/价格区简单交互（无 jQuery） |
| `data/userInfo.mock.json` | 接口形态参考（`userInfo.json` + 模板所需 `vipInfo` / 运营位等），静态页不请求接口 |
| `data/pay-v4.mock.json` | 支付演示专用（节选 `sponsor.mock.json`：`vipTypeInfo`、AI 商品 `goods`） |
| `pages/enterprise-switch.html` | 仅预览 mod-15（遮罩 + 弹窗，含 `mod-01-iconfont` 以显示关闭/对勾图标） |
| `pages/user-info-dropdown.html` | **顶栏用户信息下拉**整页预览（mod-16 + iconfont） |
| `pages/pay-v4.html` | **支付模块 qtd-pay-container-v4** 整页预览（mod-17 + iconfont + `pay-v4.demo.js`） |

各 `mod-*.html` 为 **可复制片段**；与 `index.html` 内对应注释区块 **应保持 DOM 一致**（mod-15 默认仅在 `pages/enterprise-switch.html` 演示）。

---

## 页面对照

| 页面（产品语义） | 静态文件 | 引用的 mod（按序） |
|------------------|----------|---------------------|
| 千图首页 `/` | `index.html` | mod-00 … mod-14（见 `index.html` 的 `<link>`） |
| 企业切换身份弹窗 | `pages/enterprise-switch.html` | mod-01、mod-00、mod-15 |
| 顶栏用户信息下拉 | `pages/user-info-dropdown.html` | mod-01、mod-00、mod-16（compiled + shell） |
| 支付弹层 ringingK pay v4 | `pages/pay-v4.html` | mod-01、mod-00、mod-17（pay + page）、`pay-v4.demo.js`、`data/pay-v4.mock.json` |

后续若拆 **多页**（搜索、详情等），在同目录下增加 `pages/*.html`，并在本表与 **Hub** `index.html` 中补充链接（见 Skill 说明）。

---

## 模块对照（依赖）

| 编号 | 模块 | 依赖 `theme.css` | 备注 |
|------|------|------------------|------|
| 00 | base | 是 | 先引入 |
| 01 | iconfont | 否（独立 @import） | 可选，需图标时保留 |
| 02 | site-header | 是 | 依赖 mod-03 样式用于工具卡 |
| 03 | card-tool | 是 | |
| 04 | card-poster | 是 | mod-07 内海报列表依赖 |
| 05 | card-material | 是 | mod-12 依赖 |
| 06 | site-footer | 是 | |
| 07 | section-promo | 是 | 依赖 mod-04 |
| 08～14 | 各首页区块 | 是 | |
| 15 | enterprise-switch-dialog | 是 | 依赖 mod-00；企业/个人账号列表为假数据 |
| 16 | user-info（compiled + shell + panel 片段） | 是 | 依赖 mod-00、mod-01；样式大文件为编译产物 |

---

## 主题变量摘要

- 主品牌色：`--qtd-brand-color-6` → `#00B277`
- 中性灰阶：`--qtd-fun-color-1` … `--qtd-fun-color-14`
- 头部高度：`--qtd-header-height` → `64px`
- 企业金渐变：`--qy-gradient-color`

---

## 与线上差异

未实现：搜索联想、Tab 切换、轮播、懒加载、登录与埋点。布局为近似还原，非像素级对齐。

---

## 本地预览

直接打开 `docs/demo/index.html`（或 `npx serve docs/demo` 后访问根路径）。需联网加载 iconfont 与外链图。
