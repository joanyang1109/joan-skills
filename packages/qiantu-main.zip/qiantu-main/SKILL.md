---
name: qiantu-main
description: >
  千图主站（58pic.com）官方设计规范还原工具。从真实前端源文件组装 HTML demo，
  class 名和 CSS 变量与生产代码直接对应，可交付前端开发使用。
  当用户提到"千图主站"、"千图素材"、"58pic"、"素材搜索"、"图库"、"素材详情页"、
  "主站风格"、"千图主站demo"、"做个素材平台demo"、"搜索结果页"时触发此 skill。
---

# 千图主站 Demo 系统

## ⚡ 核心原则

> **从源文件组装，不从零生成。**
>
> `demo-source/main-site/` 目录包含前端研发提供的真实 HTML/CSS 模块，与线上代码直接对应。
> 生成 demo 时**读取对应模块文件并直接使用**，不根据文档描述重建。

---

## 产品线速查

| 域名 | 风格 | 品牌色 | 源文件 |
|------|------|--------|--------|
| 58pic.com | 白色背景、绿色品牌色、超大圆角搜索框 | `#00B277` | `demo-source/main-site/` |

---

## 工作流程

### Step 1 — 读取源文件

```
读: demo-source/main-site/theme.css              （主题变量）
读: demo-source/main-site/modules/mod-02-site-header.*    （顶部导航）
读: demo-source/main-site/modules/mod-05-card-material.*  （素材卡片）
读: demo-source/main-site/modules/mod-06-site-footer.*    （底部）
# 按需追加其他模块
```

### Step 2 — 组装单文件 HTML

- 将读取的 CSS 内联到 `<style>` 标签中
- HTML 片段按布局顺序组合
- mock 数据参考 `demo-source/main-site/data/` 目录
- 输出**单个可运行 HTML 文件**

### Step 3 — 按需定制

只改文案/图片占位符和 mock 数据，其余与源文件保持一致。

---

## 主题系统

```css
--qtd-brand-color-6: #00B277;    /* 主品牌绿 */
--qtd-brand-color-5: #00C98A;    /* 品牌绿偏亮 */
--qtd-fun-color-1: #ffffff;      /* 白色 */
--qtd-fun-color-14: #1a1a1a;     /* 最深灰/黑 */
```

> 完整变量表见 `references/main-site-tokens.md`

---

## 模块清单（`demo-source/main-site/modules/`）

| 模块文件 | 功能 |
|---------|------|
| `mod-00-base.css` | 基础重置样式 |
| `mod-01-iconfont.css` | 图标字体 |
| `mod-02-site-header.*` | 顶部导航栏 |
| `mod-03-card-tool.*` | 工具卡片 |
| `mod-04-card-poster.*` | 海报卡片 |
| `mod-05-card-material.*` | 素材卡片（最常用）|
| `mod-06-site-footer.*` | 页脚 |
| `mod-07-section-promo.*` | 促销区块 |
| `mod-08-section-calendar.*` | 日历/节日区块 |
| `mod-09-section-ai-banner.*` | AI 入口 banner |
| `mod-10-section-workflow.*` | 工作流展示 |
| `mod-11-section-industry.*` | 行业分类 |
| `mod-12-section-series.*` | 系列专题 |
| `mod-13-section-commercial.*` | 商用授权区块 |
| `mod-14-section-hot-tags.*` | 热门标签 |
| `mod-15-enterprise-switch-dialog.*` | 企业切换弹窗 |
| `mod-16-user-info-panel.*` | 用户信息面板 |
| `mod-17-pay-v4.*` | 会员购买页 |

**独立页面**（`demo-source/main-site/pages/`）

| 文件 | 功能 |
|------|------|
| `pay-v4.html` | 会员购买页完整版 |
| `user-info-dropdown.html` | 用户信息下拉 |
| `enterprise-switch.html` | 企业切换页 |

---

## 参考文档索引

| 文件 | 内容 |
|------|------|
| `references/main-site-tokens.md` | 主站 CSS 变量完整表 |
| `references/search-results.md` | 搜索结果页规范 |
| `references/detail-page.md` | 素材详情页规范 |
| `references/overlays.md` | 弹窗/浮层规范 |
