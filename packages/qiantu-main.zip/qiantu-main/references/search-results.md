# 搜索结果页规范

> 覆盖千图AI（ai.58pic.com）和千图主站（58pic.com）的搜索/列表页布局与组件。

## 目录

- [一、千图主站 搜索结果页](#一千图主站-搜索结果页58piccom)（瀑布流卡片 · 筛选Tab · 悬浮遮罩操作 · 高级筛选）
- [二、千图AI 搜索/浏览结果页](#二千图ai-搜索浏览结果页aispiccom)（模板卡片 · 筛选分类Tab）
- [三、千图主站 历史类型切换](#三千图主站-历史类型切换)
- [四、空结果状态](#四空结果状态)

---

## 一、千图主站 搜索结果页（58pic.com）

### 页面 URL 格式

```
https://www.58pic.com/58pic/so/{keyword}.html
https://www.58pic.com/tupian/     （素材列表总览）
```

### 整体布局

```
固定 Header（绿色 logo + pill 搜索框）
  └── 分类 Tab 筛选栏（水平滚动）
      └── 筛选条件行（素材类型 / 授权 / 颜色 / 排序）
          └── 瀑布流卡片区域（4-5 列，响应式）
              └── 分页 / 加载更多
```

### 搜索结果 Header

```html
<header class="search-header">
  <!-- 搜索框（保持可操作） -->
  <div class="search-bar-wrap" style="flex:1;max-width:600px">
    <div class="search-bar-inner" style="display:flex;border:2px solid #00B277;border-radius:888px;overflow:hidden">
      <!-- 分类下拉 -->
      <select class="search-category" style="border:none;padding:0 12px;background:transparent;color:#141414;font-size:14px">
        <option>全部</option>
        <option>素材</option>
        <option>模板</option>
      </select>
      <div style="width:1px;background:#e8e8e8;margin:8px 0"></div>
      <!-- 输入框 -->
      <input type="text" value="海报" placeholder="搜索千图网素材"
        style="flex:1;border:none;outline:none;padding:10px 16px;font-size:15px">
      <!-- 搜索按钮 -->
      <button style="padding:0 20px;background:#00B277;color:#fff;border:none;font-size:15px;cursor:pointer">
        搜索
      </button>
    </div>
  </div>
</header>
```

### 筛选 Tab 栏

```html
<div class="filter-tab-bar" style="border-bottom:1px solid #f0f0f0;padding:0 24px;display:flex;gap:4px;overflow-x:auto">
  <a class="filter-tab active" href="#">全部</a>
  <a class="filter-tab" href="#">PSD素材</a>
  <a class="filter-tab" href="#">PNG元素</a>
  <a class="filter-tab" href="#">AI模板</a>
  <a class="filter-tab" href="#">JPG背景</a>
  <a class="filter-tab" href="#">视频</a>
  <a class="filter-tab" href="#">音频</a>
</div>
```

```css
.filter-tab-bar {
  display: flex;
  gap: 4px;
  padding: 0 24px;
  border-bottom: 1px solid #f0f0f0;
  overflow-x: auto;
  white-space: nowrap;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: none;
}
.filter-tab-bar::-webkit-scrollbar { display: none; }

.filter-tab {
  display: inline-block;
  padding: 12px 16px;
  font-size: 14px;
  color: #666;
  text-decoration: none;
  border-bottom: 2px solid transparent;
  transition: all 0.15s ease;
  white-space: nowrap;
}
.filter-tab:hover { color: #00B277; }
.filter-tab.active {
  color: #00B277;
  border-bottom-color: #00B277;
  font-weight: 600;
}
```

### 高级筛选条件行

```html
<div class="filter-options-row" style="padding:12px 24px;display:flex;gap:12px;align-items:center;border-bottom:1px solid #f0f0f0">
  <!-- 授权类型 -->
  <div class="filter-group">
    <span class="filter-label">授权：</span>
    <button class="filter-chip active">全部</button>
    <button class="filter-chip">免费</button>
    <button class="filter-chip">商用</button>
  </div>

  <!-- 颜色筛选 -->
  <div class="filter-group">
    <span class="filter-label">颜色：</span>
    <div class="color-swatches">
      <div class="color-dot" style="background:#ff4d4f" title="红色"></div>
      <div class="color-dot" style="background:#00B277" title="绿色"></div>
      <div class="color-dot" style="background:#1890ff" title="蓝色"></div>
      <div class="color-dot" style="background:#faad14" title="黄色"></div>
    </div>
  </div>

  <!-- 排序 -->
  <div class="filter-group" style="margin-left:auto">
    <span class="filter-label">排序：</span>
    <select class="filter-select">
      <option>最新</option>
      <option>最热</option>
      <option>最多下载</option>
    </select>
  </div>
</div>
```

```css
.filter-chip {
  padding: 4px 12px; border-radius: 100px;
  border: 1.5px solid #e8e8e8;
  background: transparent; font-size: 13px; color: #666;
  cursor: pointer; transition: all 0.15s;
  margin-right: 4px;
}
.filter-chip:hover { border-color: #00B277; color: #00B277; }
.filter-chip.active {
  border-color: #00B277; background: rgba(0,178,119,0.08);
  color: #00B277; font-weight: 600;
}
.color-dot {
  width: 20px; height: 20px; border-radius: 50%;
  cursor: pointer; transition: transform 0.15s;
  border: 2px solid transparent;
}
.color-dot:hover, .color-dot.active { transform: scale(1.2); border-color: #141414; }
```

### 瀑布流卡片（`.pic-card`）

主站使用响应式多列瀑布流：

```html
<!-- 4列瀑布流容器 -->
<div class="pic-waterfall" style="columns:4;column-gap:12px;padding:16px 24px">
  <!-- 素材卡片 -->
  <div class="pic-card">
    <div class="pic-card-inner">
      <!-- 图片主体 -->
      <div class="pic-img-wrap" style="position:relative;overflow:hidden;border-radius:8px">
        <img src="xxx.jpg" alt="海报模板" loading="lazy"
          style="width:100%;display:block;transition:transform 0.3s ease">
        <!-- hover 遮罩 -->
        <div class="pic-mask">
          <button class="mask-btn download">下载</button>
          <button class="mask-btn collect">收藏</button>
          <div class="mask-info">
            <span class="file-type">PSD</span>
            <span class="resolution">3508×4961</span>
          </div>
        </div>
      </div>
      <!-- 卡片底部 -->
      <div class="pic-card-footer" style="padding:8px 4px 4px">
        <p class="pic-title" style="font-size:13px;color:#333;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">春节海报模板设计</p>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:4px">
          <span class="vip-tag">VIP</span>
          <span class="download-count" style="font-size:12px;color:#999">12.8k</span>
        </div>
      </div>
    </div>
  </div>
</div>
```

```css
.pic-waterfall {
  columns: 4;
  column-gap: 12px;
  padding: 16px 24px;
}
@media (max-width: 1200px) { .pic-waterfall { columns: 3; } }
@media (max-width: 768px)  { .pic-waterfall { columns: 2; } }

.pic-card {
  break-inside: avoid;
  margin-bottom: 12px;
  cursor: pointer;
}
.pic-card-inner {
  border-radius: 8px;
  overflow: hidden;
  background: #f5f5f5;
  transition: box-shadow 0.2s, transform 0.2s;
}
.pic-card-inner:hover {
  box-shadow: 0 8px 24px rgba(0,0,0,0.15);
  transform: translateY(-3px);
}
.pic-card-inner:hover img { transform: scale(1.05); }
.pic-card-inner:hover .pic-mask { opacity: 1; }

/* hover 遮罩 */
.pic-mask {
  position: absolute; inset: 0;
  background: rgba(0,0,0,0.45);
  opacity: 0;
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  gap: 8px;
  transition: opacity 0.2s;
  border-radius: 8px;
}
.mask-btn {
  padding: 8px 20px;
  border-radius: 100px;
  font-size: 13px; font-weight: 600; cursor: pointer;
  transition: all 0.15s;
  border: none;
}
.mask-btn.download { background: #00B277; color: #fff; }
.mask-btn.download:hover { background: #009966; }
.mask-btn.collect { background: rgba(255,255,255,0.9); color: #333; }
.mask-btn.collect:hover { background: #fff; }

/* VIP 标签 */
.vip-tag {
  display: inline-block;
  padding: 2px 6px; border-radius: 4px;
  background: linear-gradient(135deg, #ffd700, #ff9500);
  color: #7a4800; font-size: 11px; font-weight: 700;
}

/* 文件类型角标 */
.file-type {
  position: absolute; top: 8px; left: 8px;
  background: rgba(0,0,0,0.6);
  color: #fff; font-size: 11px; font-weight: 700;
  padding: 2px 6px; border-radius: 4px;
  text-transform: uppercase;
}
```

---

## 二、千图AI 搜索/浏览结果页（ai.58pic.com）

AI 站没有独立搜索结果页，主要通过主页的**模板浏览区**和**历史/社区**页面展示网格。

### 模板卡片（`.templateCardImgWrap`）

真实提取自 `ai.58pic.com/history`：

**卡片宽度：382px，边框圆角：16px**

```html
<div class="template-grid">
  <!-- 单个模板卡片 -->
  <div class="template-card-wrap">
    <!-- 图片区域 -->
    <div class="templateCardImgWrap" style="width:382px;border-radius:16px;overflow:hidden;position:relative">
      <!-- 图片 -->
      <div class="templateCardImgBox" style="position:relative">
        <img class="templateCardImgItem" src="xxx.jpg" alt="模板名称"
          style="width:100%;display:block;aspect-ratio:1/1;object-fit:cover">
      </div>

      <!-- hover 遮罩（默认 opacity:0） -->
      <div class="templateCardMaskBox" style="position:absolute;inset:0;opacity:0;transition:opacity .2s;
           display:flex;align-items:flex-end;padding:12px;background:linear-gradient(to top, rgba(0,0,0,.6), transparent)">
        <!-- 操作按钮 -->
        <div class="card-hover-tool-box" style="display:flex;gap:8px">
          <button class="card-hover-tool-item" style="background:#fff;color:#333;border:none;border-radius:17px;padding:6px 14px;font-size:13px;cursor:pointer">
            <i class="icon icon-edit"></i> 编辑
          </button>
          <button class="card-hover-tool-item" style="background:#fff;color:#333;border:none;border-radius:17px;padding:6px 14px;font-size:13px;cursor:pointer">
            <i class="icon icon-download"></i>
          </button>
        </div>
      </div>

      <!-- 标签（左上角） -->
      <div class="templateCardTag" style="position:absolute;top:8px;left:8px">
        <span style="background:rgba(20,20,20,0.7);color:#fff;font-size:11px;padding:2px 8px;border-radius:100px;backdrop-filter:blur(4px)">
          AI生成
        </span>
      </div>
    </div>

    <!-- 卡片底部信息 -->
    <div class="templateCardInfoBox" style="padding:10px 4px 4px">
      <span class="templateCardName" style="font-size:14px;color:var(--qtd-text-primary);
            white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block">
        航拍夕阳下高山视频
      </span>
      <div class="like-btn" style="display:flex;align-items:center;gap:4px;margin-top:4px;font-size:13px;color:var(--qtd-text-secondary)">
        <i class="icon icon-Heart"></i>
        <span>58</span>
      </div>
    </div>
  </div>
</div>
```

```css
/* AI 站模板网格 */
.template-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 16px;
  padding: 16px;
}

/* 卡片容器 */
.template-card-wrap { cursor: pointer; }
.template-card-wrap:hover .templateCardMaskBox { opacity: 1 !important; }
.template-card-wrap:hover .templateCardImgItem { transform: scale(1.03); }

.templateCardImgItem { transition: transform 0.3s ease; }

/* hover 工具按钮 */
.card-hover-tool-item {
  background: #ffffff;
  color: rgb(51,51,51);
  border: none;
  border-radius: 17px;
  padding: 6px 14px;
  font-size: 13px;
  cursor: pointer;
  transition: all 0.15s ease;
  box-shadow: 0 2px 8px rgba(0,0,0,0.15);
}
.card-hover-tool-item:hover {
  background: rgb(178,255,0);
  color: rgb(20,20,20);
}

/* 点赞按钮 */
.like-btn {
  display: flex; align-items: center; gap: 4px;
  cursor: pointer; transition: color 0.15s;
}
.like-btn:hover { color: #ff4d4f; }
.like-btn.liked { color: #ff4d4f; }
.like-btn .icon-Heart { display: none; }
.like-btn.liked .icon-xin { display: none; }
.like-btn.liked .icon-Heart { display: inline; }
```

### 筛选分类 Tab（AI 站）

AI 站顶部有横向滚动的分类 Tab：

```html
<div class="ai-category-tabs" style="display:flex;gap:8px;overflow-x:auto;padding:12px 16px;border-bottom:1px solid var(--qtd-border-light)">
  <button class="ai-cat-tab active">全部</button>
  <button class="ai-cat-tab">图像生成</button>
  <button class="ai-cat-tab">视频生成</button>
  <button class="ai-cat-tab">背景替换</button>
  <button class="ai-cat-tab">人像美化</button>
  <button class="ai-cat-tab">图片放大</button>
  <button class="ai-cat-tab">去除背景</button>
</div>
```

```css
.ai-category-tabs {
  display: flex; gap: 8px;
  overflow-x: auto; padding: 12px 16px;
  border-bottom: 1px solid var(--qtd-border-light, rgba(255,255,255,0.08));
  scrollbar-width: none;
}
.ai-category-tabs::-webkit-scrollbar { display: none; }

.ai-cat-tab {
  flex-shrink: 0;
  padding: 6px 16px; border-radius: 100px;
  border: 1.5px solid var(--qtd-border-default, rgba(255,255,255,0.1));
  background: transparent;
  color: var(--qtd-text-secondary, #888);
  font-size: 13px; cursor: pointer;
  transition: all 0.15s ease;
}
.ai-cat-tab:hover {
  border-color: rgba(178,255,0,0.4);
  color: var(--qtd-text-primary, #fff);
}
.ai-cat-tab.active {
  border-color: rgb(178,255,0);
  background: rgba(178,255,0,0.12);
  color: rgb(178,255,0);
  font-weight: 600;
}
```

---

## 三、千图主站 历史类型切换（`.history-type-item`）

真实提取自 ai.58pic.com/history：

```css
.history-type-item {
  padding: 6px 16px; border-radius: 100px;
  font-size: 14px; cursor: pointer;
  color: var(--qtd-text-secondary);
  transition: all 0.15s ease;
}
.history-type-item:hover { color: var(--qtd-text-primary); }
.history-type-item.active {
  background: var(--qtd-bg-secondary);
  color: var(--qtd-text-primary);
  font-weight: 600;
}
```

---

## 四、空结果状态

```html
<div class="empty-state" style="text-align:center;padding:80px 24px">
  <div style="font-size:64px;margin-bottom:16px">🔍</div>
  <h3 style="font-size:18px;font-weight:600;color:var(--text-primary, #141414);margin:0 0 8px">
    没有找到相关结果
  </h3>
  <p style="font-size:14px;color:var(--text-secondary, #888);margin:0 0 24px">
    试试换个关键词，或查看全部素材
  </p>
  <button class="empty-cta-btn">浏览全部素材</button>
</div>
```
