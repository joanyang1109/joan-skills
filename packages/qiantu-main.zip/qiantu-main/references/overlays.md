# 弹窗与覆盖层规范（三站通用）

> 覆盖层包括：充值/开通VIP弹窗、登录弹窗、下载弹窗、确认对话框、Toast 通知、图片预览灯箱。
> 关键定位规则：**所有弹窗必须挂载到 `document.body`，不得放在有 `overflow:hidden` 或 `transform` 的容器内**。

## 目录

- [一、弹窗系统基础规则](#一弹窗系统基础规则)（挂载原则 · Z-index 层级表）
- [二、充值/开通VIP 弹窗](#二充值开通vip-弹窗)（千图AI · 千图主站）
- [三、图片下载弹窗（主站）](#三图片下载弹窗主站)
- [四、登录弹窗（三站通用结构）](#四登录弹窗三站通用结构)
- [五、Toast 通知](#五toast-通知)
- [六、图片预览灯箱（Lightbox）](#六图片预览灯箱lightbox)

---

## 一、弹窗系统基础规则

### 挂载原则

```html
<!-- ✅ 正确：挂载到 body -->
<body>
  <div id="app">...</div>

  <!-- Modal 挂载在 app 外层 -->
  <div class="modal-root" id="modal-root"></div>
</body>

<!-- ❌ 错误：挂载在有 overflow:hidden 的容器内 -->
<div class="page-container" style="overflow:hidden">
  <div class="modal">...</div>  <!-- 会被裁剪！ -->
</div>
```

### Z-index 层级表

```css
/* 千图站通用 z-index 规范 */
:root {
  --z-base:          0;
  --z-card-hover:    1;
  --z-sticky-header: 100;
  --z-dropdown:      200;
  --z-sidebar:       300;
  --z-modal-backdrop:900;
  --z-modal:         1000;
  --z-toast:         1100;
  --z-tooltip:       1200;
  --z-loading:       9999;
}
```

---

## 二、充值/开通VIP 弹窗

### 千图AI 开通弹窗

AI 站 VIP 弹窗呈现"升级提示"风格，深色主题与页面一致：

```html
<!-- 遮罩层 -->
<div class="modal-backdrop" onclick="closeModal()"></div>

<!-- 弹窗主体 -->
<div class="pay-modal qtd-modal">
  <!-- 关闭按钮 -->
  <button class="modal-close" onclick="closeModal()">
    <i class="icon icon-close"></i>
  </button>

  <!-- 头部：VIP 标识 -->
  <div class="pay-modal-header">
    <div class="vip-badge">
      <span class="vip-icon">👑</span>
      <span>AI创作VIP</span>
    </div>
    <h2 class="pay-modal-title">解锁全部创作权益</h2>
    <p class="pay-modal-subtitle">开通会员，畅享 AI 创作无限可能</p>
  </div>

  <!-- 套餐选择 -->
  <div class="pay-plan-list">
    <div class="pay-plan-item" onclick="selectPlan(this)">
      <div class="pay-plan-name">月卡</div>
      <div class="pay-plan-price">¥39<span>/月</span></div>
    </div>
    <div class="pay-plan-item active" onclick="selectPlan(this)">
      <div class="pay-plan-badge">推荐</div>
      <div class="pay-plan-name">连续包月</div>
      <div class="pay-plan-price">
        ¥29<span>/月</span>
        <del class="pay-plan-original">¥39</del>
      </div>
    </div>
    <div class="pay-plan-item" onclick="selectPlan(this)">
      <div class="pay-plan-name">年卡</div>
      <div class="pay-plan-price">¥99<span>/年</span></div>
    </div>
  </div>

  <!-- 支付二维码区域 -->
  <div class="pay-qrcode-area">
    <div class="qrcode-placeholder"></div>
    <p class="qrcode-tips">微信扫码支付</p>
  </div>

  <!-- 开通按钮 -->
  <button class="pay-cta-btn" onclick="openVip()">立即开通 · ¥29/月</button>

  <!-- 权益列表 -->
  <div class="pay-benefits">
    <span>✓ 200点/月</span>
    <span>✓ 同时2任务</span>
    <span>✓ 全站AI模板</span>
  </div>
</div>
```

```css
/* AI站弹窗样式（深色主题） */
.modal-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.7);
  backdrop-filter: blur(4px);
  z-index: var(--z-modal-backdrop, 900);
  animation: fadeIn 0.15s ease;
}

.pay-modal.qtd-modal {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: var(--z-modal, 1000);

  /* AI 站深色弹窗 */
  background: var(--qtd-bg-primary, #1e1e1e);
  border: 1px solid var(--qtd-border-default, rgba(255,255,255,0.1));
  border-radius: 20px;
  padding: 32px;
  width: 460px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 24px 64px rgba(0, 0, 0, 0.6);
  animation: slideUp 0.2s ease;
}

.modal-close {
  position: absolute;
  top: 16px; right: 16px;
  width: 32px; height: 32px;
  border-radius: 50%;
  background: var(--qtd-bg-secondary, rgba(255,255,255,0.08));
  border: none;
  color: var(--qtd-text-secondary, #999);
  cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  transition: all 0.15s;
}
.modal-close:hover {
  background: rgba(255,255,255,0.15);
  color: var(--qtd-text-primary, #fff);
}

/* 套餐选择项 */
.pay-plan-list {
  display: flex;
  gap: 12px;
  margin: 20px 0;
}
.pay-plan-item {
  flex: 1;
  border: 1.5px solid var(--qtd-border-default, rgba(255,255,255,0.1));
  border-radius: 12px;
  padding: 16px 12px;
  text-align: center;
  cursor: pointer;
  position: relative;
  transition: all 0.15s ease;
}
.pay-plan-item:hover { border-color: rgba(178,255,0,0.4); }
.pay-plan-item.active {
  border-color: rgb(178, 255, 0);
  background: rgba(178,255,0,0.06);
}

/* 推荐角标 */
.pay-plan-badge {
  position: absolute;
  top: -10px; left: 50%; transform: translateX(-50%);
  background: rgb(178, 255, 0);
  color: rgb(20, 20, 20);
  font-size: 11px;
  font-weight: 700;
  padding: 2px 10px;
  border-radius: 100px;
  white-space: nowrap;
}

/* 价格 */
.pay-plan-price {
  font-size: 22px;
  font-weight: 800;
  color: var(--qtd-text-primary, #fff);
  margin-top: 8px;
}
.pay-plan-price span { font-size: 12px; font-weight: 400; color: var(--qtd-text-secondary, #999); }
.pay-plan-original { font-size: 12px; color: #666; text-decoration: line-through; margin-left: 4px; }

/* CTA 按钮 */
.pay-cta-btn {
  width: 100%;
  height: 48px;
  border-radius: 40px;
  background: rgb(178, 255, 0);
  color: rgb(20, 20, 20);
  font-size: 16px;
  font-weight: 700;
  border: none;
  cursor: pointer;
  margin: 20px 0 12px;
  transition: all 0.15s ease;
}
.pay-cta-btn:hover {
  background: rgb(200, 255, 50);
  box-shadow: 0 4px 16px rgba(178,255,0,0.5);
}

/* 权益列表 */
.pay-benefits {
  display: flex;
  gap: 16px;
  justify-content: center;
  font-size: 12px;
  color: var(--qtd-text-secondary, #888);
}

@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes slideUp { from { opacity: 0; transform: translate(-50%, calc(-50% + 20px)); } to { opacity: 1; transform: translate(-50%, -50%); } }
```

---

### 千图主站 开通VIP弹窗

主站弹窗为浅色风格，使用绿色品牌色：

```html
<div class="modal-backdrop qtp-backdrop"></div>
<div class="pay-modal qtp-modal">
  <button class="modal-close qtp-close">×</button>

  <div class="qtp-modal-header" style="text-align:center;padding:24px 32px 0">
    <img src="vip-crown.svg" alt="VIP" style="height:48px;margin-bottom:12px">
    <h2 style="font-size:20px;font-weight:700;color:#141414">开通会员</h2>
    <p style="font-size:14px;color:#666;margin-top:4px">海量素材无限下载</p>
  </div>

  <!-- 套餐选项（横向） -->
  <div class="qtp-plan-tabs" style="display:flex;gap:8px;padding:20px 32px;overflow-x:auto">
    <div class="qtp-plan-tab active">
      <div>月卡</div>
      <div class="price">¥<big>19</big>/月</div>
    </div>
    <div class="qtp-plan-tab">
      <div>季卡</div>
      <div class="price">¥<big>49</big>/季</div>
    </div>
    <div class="qtp-plan-tab">
      <div>年卡 <span class="save-badge">省50%</span></div>
      <div class="price">¥<big>99</big>/年</div>
    </div>
  </div>

  <!-- 支付方式 -->
  <div class="qtp-pay-methods" style="padding:0 32px">
    <label class="pay-method-item active">
      <input type="radio" name="pay" checked>
      <span>微信支付</span>
    </label>
    <label class="pay-method-item">
      <input type="radio" name="pay">
      <span>支付宝</span>
    </label>
  </div>

  <!-- 二维码 -->
  <div style="text-align:center;padding:20px 32px">
    <div class="qrcode-box"></div>
    <p style="font-size:12px;color:#999;margin-top:8px">打开微信扫一扫</p>
  </div>

  <div style="padding:0 32px 24px;font-size:12px;color:#999;text-align:center">
    开通即同意 <a href="#" style="color:#00B277">《会员协议》</a>
  </div>
</div>
```

```css
/* 主站弹窗（浅色） */
.qtp-backdrop {
  background: rgba(0,0,0,0.5);
  backdrop-filter: blur(2px);
}

.qtp-modal {
  background: #ffffff;
  border-radius: 16px;
  width: 420px;
  box-shadow: 0 16px 48px rgba(0,0,0,0.2);
}

.qtp-close {
  background: none; border: none;
  font-size: 20px; color: #999;
  cursor: pointer; transition: color 0.15s;
}
.qtp-close:hover { color: #141414; }

/* 套餐 Tab */
.qtp-plan-tab {
  flex-shrink: 0;
  padding: 12px 20px; border-radius: 10px;
  border: 1.5px solid #e8e8e8;
  cursor: pointer; text-align: center;
  transition: all 0.15s;
  min-width: 100px;
}
.qtp-plan-tab:hover { border-color: #00B277; }
.qtp-plan-tab.active {
  border-color: #00B277;
  background: rgba(0,178,119,0.06);
}
.qtp-plan-tab .price big {
  font-size: 24px; font-weight: 800; color: #141414;
}

/* 省多少角标 */
.save-badge {
  background: rgba(0,178,119,0.15);
  color: #00B277;
  font-size: 11px; font-weight: 600;
  padding: 2px 6px; border-radius: 4px;
}

/* 支付方式 */
.pay-method-item {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 8px 14px; border-radius: 6px;
  border: 1.5px solid #e8e8e8; cursor: pointer;
  margin-right: 8px; font-size: 14px;
  transition: all 0.15s;
}
.pay-method-item.active,
.pay-method-item:has(input:checked) {
  border-color: #00B277;
  background: rgba(0,178,119,0.06);
  color: #00B277;
}

/* 二维码区域 */
.qrcode-box {
  width: 160px; height: 160px;
  background: #f5f5f5;
  border-radius: 8px;
  display: inline-flex; align-items: center; justify-content: center;
  font-size: 12px; color: #999;
  margin: 0 auto;
}
```

---

## 三、图片下载弹窗（主站）

下载前弹出授权选择弹窗：

```html
<div class="download-modal qtp-modal" style="width:480px;padding:24px 32px">
  <h3 style="font-size:18px;font-weight:700;margin:0 0 16px">选择授权类型</h3>

  <!-- 授权选项 -->
  <div class="license-options">
    <div class="license-item">
      <div class="license-info">
        <strong>个人授权</strong>
        <p>仅限个人非商业使用</p>
      </div>
      <span class="license-tag free">免费</span>
    </div>
    <div class="license-item recommended">
      <div class="license-info">
        <strong>商用授权</strong>
        <p>可用于商业项目，享受版权保障</p>
      </div>
      <span class="license-tag vip">VIP权益</span>
    </div>
  </div>

  <div style="display:flex;gap:12px;margin-top:20px">
    <button class="qtp-btn-secondary" style="flex:1" onclick="closeModal()">取消</button>
    <button class="qtp-btn-primary" style="flex:2" onclick="downloadFile()">立即下载</button>
  </div>
</div>
```

```css
.license-item {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 16px; border-radius: 10px;
  border: 1.5px solid #e8e8e8; margin-bottom: 10px;
  cursor: pointer; transition: all 0.15s;
}
.license-item:hover { border-color: #00B277; background: rgba(0,178,119,0.04); }
.license-item.recommended {
  border-color: #00B277; background: rgba(0,178,119,0.06);
}

.license-tag {
  padding: 4px 10px; border-radius: 6px;
  font-size: 12px; font-weight: 600; white-space: nowrap;
}
.license-tag.free { background: #f0f0f0; color: #666; }
.license-tag.vip { background: rgba(0,178,119,0.15); color: #00B277; }
```

---

## 四、登录弹窗（三站通用结构）

三站登录弹窗结构相同，颜色体系不同：

```html
<div class="login-modal" data-site="ai">  <!-- data-site: ai / main / enterprise -->
  <div class="login-modal-body">
    <!-- 品牌标识 -->
    <div class="login-brand">
      <img src="logo.svg" alt="千图AI" class="login-logo">
      <h2>登录 / 注册</h2>
    </div>

    <!-- 手机号登录 -->
    <div class="login-form">
      <div class="input-group">
        <div class="country-code">+86</div>
        <input type="tel" placeholder="请输入手机号" class="login-input">
      </div>
      <div class="input-group">
        <input type="text" placeholder="请输入验证码" class="login-input">
        <button class="send-code-btn">获取验证码</button>
      </div>
      <button class="login-submit-btn">登录 / 注册</button>
    </div>

    <!-- 第三方登录 -->
    <div class="login-divider"><span>或</span></div>
    <div class="login-third-party">
      <button class="third-party-btn wechat">微信登录</button>
    </div>

    <!-- 协议 -->
    <p class="login-agreement">
      登录即同意 <a href="#">用户协议</a> 和 <a href="#">隐私政策</a>
    </p>
  </div>
</div>
```

```css
/* AI 站登录弹窗深色 */
.login-modal[data-site="ai"] {
  background: var(--qtd-bg-primary, #1e1e1e);
  border: 1px solid rgba(255,255,255,0.1);
}
.login-modal[data-site="ai"] .login-input {
  background: var(--qtd-bg-secondary, rgba(255,255,255,0.06));
  border: 1.5px solid var(--qtd-border-default, rgba(255,255,255,0.1));
  color: #ffffff;
}
.login-modal[data-site="ai"] .login-input:focus {
  border-color: rgb(178,255,0);
  box-shadow: 0 0 0 3px rgba(178,255,0,0.15);
}
.login-modal[data-site="ai"] .login-submit-btn {
  background: rgb(178,255,0); color: rgb(20,20,20); font-weight: 700;
}
.login-modal[data-site="ai"] .send-code-btn { color: rgb(178,255,0); }

/* 主站登录弹窗浅色 */
.login-modal[data-site="main"] {
  background: #ffffff;
  box-shadow: 0 16px 48px rgba(0,0,0,0.15);
}
.login-modal[data-site="main"] .login-input:focus {
  border-color: #00B277;
  box-shadow: 0 0 0 3px rgba(0,178,119,0.15);
}
.login-modal[data-site="main"] .login-submit-btn {
  background: #00B277; color: #ffffff; font-weight: 700;
}
.login-modal[data-site="main"] .send-code-btn { color: #00B277; }

/* 企业站登录弹窗 */
.login-modal[data-site="enterprise"] .login-input:focus {
  border-color: #1980FF;
  box-shadow: 0 0 0 3px rgba(25,128,255,0.15);
}
.login-modal[data-site="enterprise"] .login-submit-btn {
  background: #1980FF; color: #ffffff; font-weight: 700;
}

/* 共用样式 */
.login-modal {
  position: fixed; top: 50%; left: 50%;
  transform: translate(-50%, -50%);
  border-radius: 20px;
  width: 400px; padding: 32px;
  z-index: var(--z-modal, 1000);
  animation: slideUp 0.2s ease;
}
.input-group {
  display: flex; align-items: center;
  border: 1.5px solid var(--border, #e8e8e8);
  border-radius: 10px; overflow: hidden;
  margin-bottom: 12px;
}
.login-input {
  flex: 1; border: none; outline: none;
  padding: 12px 14px; font-size: 14px;
  background: transparent;
}
.login-submit-btn {
  width: 100%; height: 48px; border: none;
  border-radius: 10px; font-size: 16px;
  cursor: pointer; margin-top: 8px;
  transition: all 0.15s ease;
}
.login-submit-btn:hover { opacity: 0.9; }
.login-agreement { font-size: 12px; color: #999; text-align: center; margin-top: 16px; }
.login-agreement a { color: #00B277; text-decoration: none; }
```

---

## 五、Toast 通知

```css
/* Toast 容器（固定在顶部中央） */
.toast-container {
  position: fixed;
  top: 72px;   /* header 高度下方 */
  left: 50%;
  transform: translateX(-50%);
  z-index: var(--z-toast, 1100);
  display: flex; flex-direction: column; gap: 8px;
  pointer-events: none;
}

/* Toast 样式 */
.toast {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 10px 16px;
  border-radius: 10px;
  font-size: 14px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
  animation: toastIn 0.2s ease, toastOut 0.2s ease 2.8s forwards;
  pointer-events: auto;
  white-space: nowrap;
}
.toast.success { background: #fff; border: 1px solid rgba(0,178,119,0.3); color: #00B277; }
.toast.error   { background: #fff; border: 1px solid rgba(255,77,79,0.3); color: #ff4d4f; }
.toast.info    { background: #fff; border: 1px solid rgba(24,144,255,0.3); color: #1890ff; }

/* AI 站深色 Toast */
.qtd-ai-dark-mode .toast {
  background: rgba(40,40,40,0.95);
  border-color: rgba(255,255,255,0.12);
  color: #ffffff;
  backdrop-filter: blur(8px);
}
.qtd-ai-dark-mode .toast.success { border-color: rgba(178,255,0,0.4); color: rgb(178,255,0); }

@keyframes toastIn { from { opacity:0; transform:translateY(-10px); } to { opacity:1; transform:translateY(0); } }
@keyframes toastOut { from { opacity:1; } to { opacity:0; transform:translateY(-10px); } }
```

---

## 六、图片预览灯箱（Lightbox）

```html
<div class="lightbox-backdrop" onclick="closeLightbox()"></div>
<div class="lightbox">
  <button class="lightbox-close">×</button>
  <button class="lightbox-prev">‹</button>
  <button class="lightbox-next">›</button>

  <div class="lightbox-img-wrap">
    <img src="xxx.jpg" class="lightbox-img" alt="">
    <!-- 加载 Loading -->
    <div class="lightbox-loading">
      <div class="spinner"></div>
    </div>
  </div>

  <!-- 底部信息栏 -->
  <div class="lightbox-footer">
    <div class="lightbox-title">素材名称</div>
    <div class="lightbox-actions">
      <button class="lightbox-download-btn">下载</button>
      <button class="lightbox-like-btn">收藏</button>
    </div>
  </div>
</div>
```

```css
.lightbox {
  position: fixed; top: 50%; left: 50%;
  transform: translate(-50%, -50%);
  z-index: var(--z-modal, 1000);
  background: rgba(20,20,20,0.95);
  border-radius: 16px;
  max-width: 90vw; max-height: 90vh;
  overflow: hidden;
  display: flex; flex-direction: column;
}
.lightbox-img-wrap {
  flex: 1; overflow: hidden;
  display: flex; align-items: center; justify-content: center;
}
.lightbox-img {
  max-width: 100%; max-height: calc(90vh - 80px);
  object-fit: contain;
  border-radius: 4px;
}
.lightbox-prev, .lightbox-next {
  position: absolute; top: 50%; transform: translateY(-50%);
  background: rgba(255,255,255,0.15);
  border: none; color: #fff;
  width: 40px; height: 40px; border-radius: 50%;
  font-size: 24px; cursor: pointer;
  transition: background 0.15s;
}
.lightbox-prev:hover, .lightbox-next:hover { background: rgba(255,255,255,0.3); }
.lightbox-prev { left: 16px; }
.lightbox-next { right: 16px; }
```
