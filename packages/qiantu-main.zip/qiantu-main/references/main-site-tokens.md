# 千图主站 (58pic.com) 设计 Tokens

> **权威来源**：`demo-source/main-site/theme.css`（由前端从 `Client/lib/base/theme.scss` 直接转写）。
> **class 命名**：主站 demo 使用 `demo-*` 前缀（如 `demo-top-nav`、`demo-card-tool`），与线上 React 组件名对齐但不完全相同。

## CSS 变量速查（来自 demo-source/main-site/theme.css）

### 品牌色（绿色系）

```css
--qtd-brand-color-1: #F5FFFA;
--qtd-brand-color-2: #B9F0D6;
--qtd-brand-color-3: #82E0B8;
--qtd-brand-color-4: #4FD19D;
--qtd-brand-color-5: #25C288;
--qtd-brand-color-6: #00B277;   /* ★ 主品牌绿 */
--qtd-brand-color-7: #008F64;
--qtd-brand-color-8: #006B4F;
--qtd-brand-color-9: #004739;
--qtd-brand-color-10: #00241E;

--qtd-brand-color-outline-1: rgba(37, 194, 136, 0.2);
--qtd-brand-color-outline-2: rgba(0, 178, 119, 0.2);
```

### 业务色

```css
--qtd-business-color-1: #F5FBFF;
--qtd-business-color-3: #9ed3ff;
--qtd-business-color-6: #1980ff;   /* 蓝色（链接/企业入口） */
--qtd-business-color-7: #105fcc;

--qtd-gold-color-6: #f5d993;       /* 金色（VIP 相关） */
--qtd-tools-color-6: #FD395D;      /* 红色（工具/热门） */
--qtd-link-color-6: #1980FF;       /* 通用链接蓝 */
--qtd-error-color-6: #FA5555;
--qtd-warning-color-6: #FD8320;
```

### 中性灰阶（14级）

```css
--qtd-fun-color-1:  #FFFFFF;
--qtd-fun-color-2:  #FAFAFA;
--qtd-fun-color-3:  #F5F5F5;
--qtd-fun-color-4:  #E8E8E8;
--qtd-fun-color-5:  #E0E0E0;
--qtd-fun-color-6:  #D8D8D8;
--qtd-fun-color-7:  #B8B8B8;
--qtd-fun-color-8:  #999999;
--qtd-fun-color-9:  #808080;
--qtd-fun-color-10: #666666;
--qtd-fun-color-11: #4D4D4D;
--qtd-fun-color-12: #333333;
--qtd-fun-color-13: #1F1F1F;
--qtd-fun-color-14: #141414;
```

### 渐变 / 特殊

```css
--qy-gradient-color: linear-gradient(90deg, #F9EAB7 0%, #EDC46E 100%);  /* 企业金色 */
--pro-gradient-color: linear-gradient(90deg, #A0B1C9 8.13%, #FFF 82.26%, #A0B1C9 94.99%);

--qtd-header-height: 64px;          /* 顶栏高度 */

--demo-ai-tab-accent: #B2FF00;       /* AI 标签页强调色 */
--demo-ai-border-purple: #988FFF;    /* AI 边框紫色 */

--qtd-modal-color-1: rgba(0, 0, 0, 0.8);
--qtd-transition-cubic-1: cubic-bezier(0.645, 0.045, 0.355, 1);
--qtd-transition-delay-1: 0.3s;
--z-index-1: 999;
--z-index-10: 9;
```

## 自定义字体（加载自 CDN）

```css
/* 来自 mod-00-base.css */
@font-face { font-family: "Bebas";          src: url("https://static.qiantucdn.com/assets/fonts/Bebas.ttf"); }
@font-face { font-family: "zihunyuwanti";   src: url("https://static.qiantucdn.com/assets/fonts/zhywt3.ttf?30"); }
@font-face { font-family: "DouyinSansBold"; src: url("https://static.qiantucdn.com/assets/fonts/DouyinSansBold.otf"); }
```

## 主站核心 class 名（真实来源）

主站 demo 使用 `demo-*` 前缀，对应线上组件名：

| demo class | 线上组件/位置 | 说明 |
|------------|--------------|------|
| `demo-top-nav` | Header | 顶部导航栏 |
| `demo-logo` | Header logo | 品牌标识 |
| `demo-hero` | Hero section | 首屏搜索区 |
| `demo-qt-search` | SearchBox | 超大搜索框（圆角） |
| `demo-search-type` | SearchType tab | 素材/AI创作切换 |
| `demo-w1200` | Container | 1200px 内容容器 |
| `demo-card-tool` | CardTool | AI工具小卡片（160×90） |
| `demo-card-tool__hot` | badge | Hot 标签（橙红） |
| `demo-card-poster` | CardPoster | 运营海报卡 |
| `demo-card-material` | CardMaterial | 素材/套图卡 |
| `demo-btn-brand` | Button primary | 品牌绿主按钮 |
| `demo-btn-gold` | Button gold | 企业VIP金色按钮 |
| `demo-btn-ghost` | Button ghost | 幽灵按钮 |
| `demo-section-title` | SectionTitle | 区块标题 |

## 模块文件清单（demo-source/main-site/modules/）

| 文件 | 内容 |
|------|------|
| `mod-00-base.css` | 重置 + 基础容器类 |
| `mod-01-iconfont.css` | 阿里 iconfont（`font_504266_dzom6i255a`） |
| `mod-02-site-header.*` | 顶栏 + Hero 搜索区（含工具卡片矩阵） |
| `mod-03-card-tool.*` | AI工具小卡 |
| `mod-04-card-poster.*` | 运营海报条 |
| `mod-05-card-material.*` | 素材/套图卡 |
| `mod-06-site-footer.*` | 页脚 |
| `mod-07-section-promo.*` | 为你推荐 + Tab |
| `mod-08-section-calendar.*` | 营销日历 |
| `mod-09-section-ai-banner.*` | AI 通栏 |
| `mod-10-section-workflow.*` | 工作流卡片 |
| `mod-11-section-industry.*` | 行业专区 |
| `mod-12-section-series.*` | 套图系列 |
| `mod-13-section-commercial.*` | 商用版权 CTA |
| `mod-14-section-hot-tags.*` | 热门搜索标签云 |
| `mod-15-enterprise-switch-dialog.*` | 企业/个人切换弹窗 |
| `mod-16-user-info-panel.html` + 2 css | 顶栏用户信息下拉 |
| `mod-17-pay-v4.*` | VIP支付弹层（含 mock 数据） |

## 独立页面（demo-source/main-site/pages/）

| 文件 | 内容 |
|------|------|
| `enterprise-switch.html` | 企业/个人身份切换弹窗独立预览 |
| `user-info-dropdown.html` | 用户信息下拉面板独立预览 |
| `pay-v4.html` | VIP支付弹层完整预览（含 mock 数据） |

## 与旧文档差异

| 旧写法（已废弃） | 正确写法 |
|------------------|----------|
| `--qtp-brand` | `--qtd-brand-color-6` (#00B277) |
| `--qtp-bg-white` | `--qtd-fun-color-1` (#FFFFFF) |
| `.qtp-search-box` | `demo-qt-search` |
| `.qtp-nav` | `demo-top-nav` |
| `.qtp-card` | `demo-card-tool` / `demo-card-material` |
