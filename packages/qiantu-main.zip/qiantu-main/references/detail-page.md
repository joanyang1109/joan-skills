# 素材/作品详情页规范

> 覆盖千图主站素材详情页和千图AI作品详情页的布局、组件与交互模式。

## 目录

1. [千图主站 素材详情页](#一千图主站-素材详情页)
2. [千图AI 作品/模板详情页](#二千图ai-作品模板详情页)
3. [千图企业站 素材详情页](#三千图企业站-素材详情页)
4. [共用：面包屑导航](#四共用面包屑导航)
5. [页面底部推荐（"相关素材"）](#五页面底部推荐相关素材)

---

## 一、千图主站 素材详情页

### 页面 URL 格式

```
https://www.58pic.com/58pic/{id}.html
https://www.58pic.com/tupian/{id}.html
```

### 页面整体布局（左右分栏）

```
固定 Header
  └── 面包屑导航（首页 > 素材分类 > 当前素材名）
      └── 主内容区（左右两栏）
          ├── 左栏（约 60%）：预览图 + 标签 + 相关推荐
          └── 右栏（约 40%）：素材信息 + 下载操作区
              └── 相关素材推荐（底部）
```

### 左栏：预览图区域

```html
<div class="detail-preview-area" style="flex:0 0 60%;padding-right:24px">
  <!-- 主预览图 -->
  <div class="preview-img-wrap" style="border-radius:12px;overflow:hidden;background:#f5f5f5;position:relative">
    <img src="preview.jpg" alt="素材预览"
      style="width:100%;display:block;cursor:zoom-in">
    <!-- 水印提示（展示用） -->
    <div class="watermark-tip" style="position:absolute;bottom:12px;right:12px;
         background:rgba(0,0,0,0.5);color:#fff;font-size:12px;padding:4px 10px;border-radius:4px;
         backdrop-filter:blur(4px)">
      下载后无水印
    </div>
  </div>

  <!-- 缩略图列表（多页预览） -->
  <div class="thumbnail-list" style="display:flex;gap:8px;margin-top:12px;overflow-x:auto">
    <div class="thumb-item active" style="width:72px;height:72px;border-radius:6px;overflow:hidden;
         border:2px solid #00B277;cursor:pointer;flex-shrink:0">
      <img src="thumb1.jpg" style="width:100%;height:100%;object-fit:cover">
    </div>
    <div class="thumb-item" style="width:72px;height:72px;border-radius:6px;overflow:hidden;
         border:2px solid transparent;cursor:pointer;flex-shrink:0">
      <img src="thumb2.jpg" style="width:100%;height:100%;object-fit:cover">
    </div>
  </div>

  <!-- 素材标签 -->
  <div class="detail-tags" style="margin-top:16px;display:flex;flex-wrap:wrap;gap:8px">
    <span class="detail-tag">海报</span>
    <span class="detail-tag">促销</span>
    <span class="detail-tag">节日</span>
    <span class="detail-tag">红色</span>
  </div>
</div>
```

```css
/* 缩略图 hover/active */
.thumb-item {
  transition: border-color 0.15s;
}
.thumb-item:hover { border-color: rgba(0,178,119,0.4); }
.thumb-item.active { border-color: #00B277; }

/* 标签 */
.detail-tag {
  display: inline-block;
  padding: 4px 12px; border-radius: 100px;
  background: #f5f5f5; color: #666;
  font-size: 13px; cursor: pointer;
  text-decoration: none;
  transition: all 0.15s;
}
.detail-tag:hover { background: rgba(0,178,119,0.1); color: #00B277; }
```

### 右栏：下载操作区

```html
<div class="detail-action-area" style="flex:0 0 40%;position:sticky;top:80px">
  <!-- 素材标题 -->
  <h1 class="detail-title" style="font-size:22px;font-weight:700;color:#141414;line-height:1.4;margin:0 0 12px">
    春节喜庆促销海报模板
  </h1>

  <!-- 素材信息 -->
  <div class="detail-meta" style="display:flex;flex-wrap:wrap;gap:12px;margin-bottom:20px;font-size:13px;color:#888">
    <span><b style="color:#333">格式：</b>PSD</span>
    <span><b style="color:#333">尺寸：</b>3508×4961px</span>
    <span><b style="color:#333">大小：</b>45.6 MB</span>
    <span><b style="color:#333">类别：</b>海报设计</span>
  </div>

  <!-- VIP 权益提示 -->
  <div class="vip-benefit-tip" style="background:rgba(0,178,119,0.08);border:1px solid rgba(0,178,119,0.2);
       border-radius:10px;padding:12px 16px;margin-bottom:16px;display:flex;align-items:center;gap:8px">
    <span style="font-size:18px">👑</span>
    <div>
      <div style="font-size:14px;font-weight:600;color:#141414">VIP会员 免费下载</div>
      <div style="font-size:12px;color:#888">开通VIP，畅下海量素材</div>
    </div>
  </div>

  <!-- 主下载按钮 -->
  <div style="display:flex;gap:12px;margin-bottom:16px">
    <button class="download-btn-primary" style="flex:1;height:48px;background:#00B277;color:#fff;
             border:none;border-radius:10px;font-size:16px;font-weight:700;cursor:pointer">
      立即下载
    </button>
    <button class="collect-btn" style="width:48px;height:48px;border-radius:10px;
             border:1.5px solid #e8e8e8;background:#fff;cursor:pointer;font-size:20px">
      🤍
    </button>
  </div>

  <!-- 下载统计 -->
  <div class="detail-stats" style="display:flex;gap:20px;font-size:13px;color:#888;margin-bottom:20px">
    <span>📥 下载 <b style="color:#333">12,856</b></span>
    <span>👁 浏览 <b style="color:#333">48,200</b></span>
    <span>❤️ 收藏 <b style="color:#333">3,415</b></span>
  </div>

  <!-- 作者信息 -->
  <div class="author-card" style="display:flex;align-items:center;gap:10px;padding:14px;
       border-radius:10px;border:1px solid #f0f0f0">
    <img src="avatar.jpg" style="width:40px;height:40px;border-radius:50%;object-fit:cover">
    <div style="flex:1">
      <div style="font-size:14px;font-weight:600;color:#141414">千图官方</div>
      <div style="font-size:12px;color:#888">1,234 作品</div>
    </div>
    <button style="padding:6px 14px;border-radius:100px;border:1.5px solid #e8e8e8;
             background:#fff;font-size:13px;cursor:pointer;transition:all .15s"
            onmouseover="this.style.borderColor='#00B277';this.style.color='#00B277'"
            onmouseout="this.style.borderColor='#e8e8e8';this.style.color=''">
      + 关注
    </button>
  </div>
</div>
```

```css
.download-btn-primary {
  transition: all 0.15s ease;
}
.download-btn-primary:hover {
  background: #009966;
  box-shadow: 0 4px 16px rgba(0,178,119,0.35);
}
.download-btn-primary:active { transform: scale(0.98); }

.collect-btn {
  transition: all 0.15s ease;
}
.collect-btn:hover { border-color: #ff4d4f; }
.collect-btn.collected { border-color: #ff4d4f; background: rgba(255,77,79,0.06); }
```

---

## 二、千图AI 作品/模板详情页

### 页面结构（模态展示 or 独立页）

AI 站点击模板后，通常以**弹窗/侧边抽屉**展示详情，而非独立跳转页：

```
模板卡片点击
  └── 弹窗详情层（z-index: 1000）
      ├── 左侧：大图预览（带主题切换）
      └── 右侧：操作面板
              ├── 模板名称
              ├── 使用模板 / 立即生成 按钮
              ├── 样式参数选项（宽高比 / 风格）
              └── 相关模板推荐
```

### AI 站详情弹窗

```html
<div class="ai-detail-modal">
  <div class="ai-detail-backdrop" onclick="closeDetail()"></div>

  <div class="ai-detail-panel">
    <!-- 关闭 -->
    <button class="ai-detail-close">
      <i class="icon icon-close"></i>
    </button>

    <div class="ai-detail-body">
      <!-- 左侧：大图预览 -->
      <div class="ai-preview-col">
        <div class="ai-preview-img-wrap" style="border-radius:16px;overflow:hidden;background:var(--qtd-bg-secondary)">
          <img src="template-full.jpg" alt="模板预览" style="width:100%;display:block">
        </div>

        <!-- 缩略图 -->
        <div style="display:flex;gap:8px;margin-top:12px;overflow-x:auto">
          <div class="ai-thumb active">
            <img src="thumb1.jpg" style="width:64px;height:64px;object-fit:cover;border-radius:8px">
          </div>
        </div>
      </div>

      <!-- 右侧：操作面板 -->
      <div class="ai-action-col" style="padding:24px;display:flex;flex-direction:column;gap:16px">
        <h2 class="ai-template-title" style="font-size:20px;font-weight:700;color:var(--qtd-text-primary)">
          夕阳航拍山地视频
        </h2>

        <!-- 分类标签 -->
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <span class="ai-detail-tag">风景</span>
          <span class="ai-detail-tag">自然</span>
          <span class="ai-detail-tag">航拍</span>
        </div>

        <!-- 主操作按钮 -->
        <button class="ai-use-template-btn">
          <i class="icon icon-magic"></i>
          使用此模板生成
        </button>

        <!-- 相似模板 -->
        <div style="margin-top:8px">
          <div style="font-size:14px;font-weight:600;color:var(--qtd-text-primary);margin-bottom:10px">相似模板</div>
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
            <div style="border-radius:8px;overflow:hidden;cursor:pointer;aspect-ratio:1/1">
              <img src="similar1.jpg" style="width:100%;height:100%;object-fit:cover">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
```

```css
/* AI 站详情弹窗 */
.ai-detail-backdrop {
  position: fixed; inset: 0;
  background: rgba(0,0,0,0.65);
  backdrop-filter: blur(4px);
  z-index: 990;
}

.ai-detail-panel {
  position: fixed;
  top: 50%; left: 50%;
  transform: translate(-50%, -50%);
  z-index: 1000;
  background: var(--qtd-bg-primary, #1a1a1a);
  border: 1px solid var(--qtd-border-default, rgba(255,255,255,0.1));
  border-radius: 20px;
  width: min(900px, 90vw);
  max-height: 90vh;
  overflow: hidden;
  animation: slideUp 0.2s ease;
}

.ai-detail-body {
  display: grid;
  grid-template-columns: 1fr 380px;
  height: 100%;
  overflow-y: auto;
}

/* 左列预览 */
.ai-preview-col {
  padding: 24px;
  background: var(--qtd-bg-secondary, rgba(255,255,255,0.04));
}

/* 缩略图 */
.ai-thumb {
  cursor: pointer; border-radius: 8px; overflow: hidden;
  border: 2px solid transparent; transition: border-color 0.15s;
}
.ai-thumb:hover { border-color: rgba(178,255,0,0.4); }
.ai-thumb.active { border-color: rgb(178,255,0); }

/* 标签 */
.ai-detail-tag {
  padding: 4px 10px; border-radius: 100px;
  background: var(--qtd-bg-secondary, rgba(255,255,255,0.08));
  color: var(--qtd-text-secondary, #888);
  font-size: 13px; cursor: pointer;
  transition: all 0.15s;
}
.ai-detail-tag:hover {
  background: rgba(178,255,0,0.12);
  color: rgb(178,255,0);
}

/* 使用模板按钮 */
.ai-use-template-btn {
  width: 100%; height: 48px;
  background: rgb(178, 255, 0);
  color: rgb(20, 20, 20);
  border: none; border-radius: 12px;
  font-size: 16px; font-weight: 700;
  cursor: pointer;
  display: flex; align-items: center; justify-content: center; gap: 8px;
  transition: all 0.15s ease;
}
.ai-use-template-btn:hover {
  background: rgb(200, 255, 50);
  box-shadow: 0 4px 16px rgba(178,255,0,0.5);
}

.ai-detail-close {
  position: absolute; top: 16px; right: 16px;
  width: 32px; height: 32px; border-radius: 50%;
  background: rgba(255,255,255,0.1);
  border: none; color: #fff; cursor: pointer;
  transition: all 0.15s; z-index: 10;
  display: flex; align-items: center; justify-content: center;
}
.ai-detail-close:hover { background: rgba(255,255,255,0.2); }
```

---

## 三、千图企业站 素材详情页

企业站素材详情页与主站相同结构，但使用深色体系和蓝色品牌色：

```css
/* 企业站详情页覆盖样式 */
.qte-detail-page {
  background: var(--qte-bg-page, #141414);
  color: var(--qte-text-primary, #ffffff);
}

/* 下载按钮 → 蓝色 */
.qte-detail-page .download-btn-primary {
  background: #1980FF;
  color: #ffffff;
}
.qte-detail-page .download-btn-primary:hover {
  background: #1a6fd4;
  box-shadow: 0 4px 16px rgba(25,128,255,0.4);
}

/* VIP 权益提示 → 蓝色边框 */
.qte-detail-page .vip-benefit-tip {
  background: rgba(25,128,255,0.08);
  border-color: rgba(25,128,255,0.2);
}

/* 标签 → 深色背景 */
.qte-detail-page .detail-tag {
  background: rgba(255,255,255,0.08);
  color: rgba(255,255,255,0.6);
}
.qte-detail-page .detail-tag:hover {
  background: rgba(25,128,255,0.15);
  color: #1980FF;
}
```

---

## 四、共用：面包屑导航

```html
<nav class="breadcrumb" aria-label="面包屑">
  <a href="/" class="bc-item">首页</a>
  <span class="bc-sep">›</span>
  <a href="/tupian/" class="bc-item">素材</a>
  <span class="bc-sep">›</span>
  <a href="/tupian/haibao.html" class="bc-item">海报</a>
  <span class="bc-sep">›</span>
  <span class="bc-item bc-current">春节喜庆促销海报模板</span>
</nav>
```

```css
.breadcrumb {
  display: flex; align-items: center; flex-wrap: wrap;
  gap: 4px; padding: 12px 0; font-size: 13px;
}
.bc-item { color: #888; text-decoration: none; transition: color 0.15s; }
.bc-item:hover { color: #00B277; }
.bc-item.bc-current { color: #141414; font-weight: 500; cursor: default; }
.bc-sep { color: #ccc; }

/* AI 站深色面包屑 */
.qtd-ai-dark-mode .bc-item { color: var(--qtd-text-tertiary, #666); }
.qtd-ai-dark-mode .bc-item:hover { color: rgb(178,255,0); }
.qtd-ai-dark-mode .bc-item.bc-current { color: var(--qtd-text-primary, #fff); }
```

---

## 五、页面底部推荐（"相关素材"）

详情页底部常有同类素材推荐，复用瀑布流卡片：

```html
<section class="related-section" style="margin-top:48px;padding:0 24px">
  <h3 style="font-size:18px;font-weight:700;color:#141414;margin:0 0 16px">相关素材推荐</h3>
  <!-- 复用搜索结果页的 .pic-waterfall 组件 -->
  <div class="pic-waterfall" style="columns:5">
    <!-- 卡片... -->
  </div>
</section>
```
