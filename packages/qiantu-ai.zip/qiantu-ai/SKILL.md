---
name: qiantu-ai
description: >
  千图AI（ai.58pic.com）和千图智能设计（canvas.58pic.com）官方设计规范还原工具。
  从真实前端源文件组装 HTML demo，class 名和 CSS 变量与生产代码直接对应，可交付前端开发使用。
  当用户提到"千图AI"、"AI创作"、"AI绘图"、"AI生图"、"即梦"、"AI工具界面"、
  "千图AI demo"、"千图AI风格"、"画布编辑器"、"智能设计"、"canvas编辑器"、
  "做个AI产品demo"、"AI工具原型"时触发此 skill。
---

# 千图AI + 智能设计 Demo 系统

## ⚡ 核心原则

> **从源文件组装，不从零生成。**
>
> `demo-source/` 目录包含前端研发提供的真实 HTML/CSS 模块，与线上代码直接对应。
> 生成 demo 时**读取对应模块文件并直接使用**，不根据文档描述重建。

---

## 两条产品线速查

| 产品线 | 域名 | 风格关键字 | 源文件目录 | 必读参考 |
|--------|------|-----------|-----------|---------|
| **千图AI** | ai.58pic.com | 荧光绿 `#d8ff00`、深色/浅色双主题、顶部导航+左侧图标栏 | `demo-source/ai-site/` | `references/design-tokens.md` |
| **千图智能设计** | canvas.58pic.com | 浅灰点阵背景 `#ebebeb`、白底悬浮工具条、深色AI输入条 | `demo-source/canvas-editor/` | `references/smart-design.md` |

---

## 工作流程

### Step 1 — 判断产品线

- "AI创作/生图/AI绘画/模型/定价/会员" → **千图AI**（`demo-source/ai-site/`）
- "画布/编辑器/设计/智能设计/无限画布/文字工具" → **千图智能设计**（`demo-source/canvas-editor/`）

### Step 2 — 读取源文件

**千图AI 示例：做首页**
```
读: demo-source/ai-site/theme.css
读: demo-source/ai-site/modules/app-header.html + .css
读: demo-source/ai-site/pages/home/modules/hero-titles.html + .css
读: demo-source/ai-site/modules/create-box-newv2.html + .css
读: demo-source/ai-site/modules/community-masonry.html + .css
```

**千图智能设计 示例：做编辑器界面**
```
读: demo-source/canvas-editor/theme.css
读: demo-source/canvas-editor/modules/mod-01-background.html + .css
读: demo-source/canvas-editor/modules/mod-02-canvas-stage.html + .css
读: demo-source/canvas-editor/modules/mod-04-top-center-toolbar.html + .css
读: demo-source/canvas-editor/modules/mod-10-ai-prompt-bar.html + .css
```

### Step 3 — 组装单文件 HTML

- 将读取的 CSS **内联**到 `<style>` 标签中
- 将 HTML 片段按布局顺序组合
- 加入必要的 JS 交互（参考 `modules/theme-toggle.js`）
- 输出**单个可运行 HTML 文件**

### Step 4 — 按需定制

只改以下内容，其余保持与源文件一致：
- 文案/图片占位符
- 演示用的 mock 数据
- 页面标题

---

## 千图AI 主题系统

**主题切换机制**：`html` 元素加 `.qtd-ai-light-mode` class = 浅色模式；默认（无此 class）= 深色模式。

| 变量 | 深色值 | 浅色值 | 用途 |
|------|--------|--------|------|
| `--qtd-ai-drak-bg-1` | `#141414` | `#ffffff` | 页面主背景 |
| `--qtd-ai-drak-bg-2` | `#1f1f1f` | `#f5f5f5` | 卡片背景 |
| `--qtd-ai-text-color-hover-1` | `#d8ff00` | `#141414` | 品牌荧光绿/深色 |
| `--new-grey-1` | `rgba(255,255,255,0.04)` | `rgba(0,0,0,0.04)` | 最浅灰 |

> 完整变量表见 `references/design-tokens.md`

---

## 千图智能设计 主题系统

```css
--qtd-page-bg: #ebebeb;          /* 点阵画布背景 */
--qtd-accent-lime: #c8ff00;      /* 品牌lime绿 */
--qtd-ai-dark-bg: rgba(31,31,31,0.92);  /* AI输入条深色背景 */
```

> 完整规范见 `references/smart-design.md`

---

## 模块清单

**AI站模块**（`demo-source/ai-site/modules/`）

| 文件 | 功能 |
|------|------|
| `app-header.html/.css` | 顶部导航栏 |
| `create-box-newv2.html/.css` | 创作输入框 |
| `community-masonry.html/.css` | 社区瀑布流 |
| `page-shell.html/.css` | 页面框架 |

**AI站页面**（`demo-source/ai-site/pages/`）

| 目录 | 内容 |
|------|------|
| `home/modules/` | 首页各区块（hero-titles, classify-ai-tools 等）|
| `pricing/` | 定价页完整源码 + data.full.json |

**智能设计模块**（`demo-source/canvas-editor/modules/`）

| 文件前缀 | 功能 |
|---------|------|
| `mod-01` | 点阵背景 |
| `mod-02` | 画布舞台 |
| `mod-03` | 左上角 Logo+页面管理 |
| `mod-04` | 顶部工具条 |
| `mod-05` | 右上角操作区 |
| `mod-06` | 右侧反馈入口 |
| `mod-07` | 底部缩放控制 |
| `mod-08` | 底部中央铅笔工具 |
| `mod-09` | 右下角视图切换 |
| `mod-10` | AI 提示词输入条 |
| `mod-11` | 下载弹窗 |
| `mod-12` | 文字工具栏 |

---

## 参考文档索引

| 文件 | 内容 |
|------|------|
| `references/design-tokens.md` | 千图AI CSS 变量完整表 |
| `references/smart-design.md` | 智能设计设计规范 |
| `references/components.md` | 千图AI 真实组件 class 名 |
| `references/layouts.md` | 布局模板（4种） |
| `references/pricing.md` | 定价页规范 |
| `references/advanced-interactions.md` | 高级交互模式 |
| `references/interaction-states.md` | hover/focus/active 状态 |
