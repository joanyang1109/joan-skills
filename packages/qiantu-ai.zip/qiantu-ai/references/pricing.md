# 千图三站定价页规范

> 基于真实页面逆向提取。三个产品线定价页的视觉语言、组件结构和布局模式完全不同，需分别处理。

## 目录

- [一、千图AI 定价页](#一千图ai-定价页aispricingcom)（促销Banner · 7档套餐+点数下拉 · 翻页 · 模型对比表 · 价值对比区）
- [二、千图主站 定价页](#二千图主站-定价页58piccompricing)（5种套餐 · 对比表格 · 品牌绿）
- [三、千图企业站 定价页](#三千图企业站-定价页qiyespricingcom)（双卡切换 · 渐变按钮 · 深色背景）
- [完整定价页 HTML 示例（千图AI）](#完整定价页-html-示例千图ai)

---

## 一、千图AI 定价页（ai.58pic.com/pricing）

### 页面整体结构

```
顶部 Header（同首页）
促销 Banner（限时活动标语 + 赠品说明 + 折扣角标 + 单独购买点数入口）
  └── 个人/企业 Tab 切换器（pill 型）
      └── 套餐卡片区（上一组 / 卡片列表 / 下一组 翻页）
          ├── 每张卡片：套餐名 + 点数档位下拉 + 价格 + 特权行 + CTA + 权益列表
          └── "详细对比模型权益" 展开按钮
              └── 底部完整模型对比表（图片/视频/3D/音乐 × N个套餐列）
价值对比区（"为什么前1%的设计师选择千图AI？"）
FAQ 折叠区
底部 CTA（准备好升级你的职业生涯了吗？）
```

> **架构说明**：定价数据从 CDN 动态加载（`data.full.json`），页面展示逻辑与数据分离。生成 demo 时可将数据内嵌为 JS 变量或直接硬编码。

---

### 促销 Banner

```html
<div class="promo-banner">
  <span class="promo-badge">春季限时优惠</span>
  <span class="promo-text">买AI创作VIP 赠下载VIP</span>
  <button class="promo-buy-points">单独购买点数</button>
  <span class="discount-badge">5折优惠</span>
</div>
```

```css
.promo-banner {
  display: flex; align-items: center; gap: 12px;
  padding: 12px 24px;
  background: rgb(20, 20, 20);
  color: #fff; font-size: 14px;
}
.promo-badge {
  padding: 2px 10px; border-radius: 100px;
  background: rgb(212, 253, 83); color: #141414;
  font-size: 12px; font-weight: 600;
}
.discount-badge {
  padding: 2px 8px; border-radius: 100px;
  background: rgba(255,255,255,0.15); color: #fff;
  font-size: 12px;
}
.promo-buy-points {
  background: none; border: 1px solid rgba(255,255,255,0.4);
  color: #fff; padding: 4px 12px; border-radius: 100px;
  font-size: 12px; cursor: pointer;
}
```

---

### 个人/企业切换 Tab（`.publicItem`）

```css
.tab-switcher {
  display: inline-flex;
  background: var(--qtd-bg-secondary);
  border-radius: 88px;
  padding: 4px;
}
.publicItem {
  padding: 8px 24px; border-radius: 88px; font-size: 14px;
  cursor: pointer; transition: all 0.2s ease;
  color: var(--qtd-text-secondary); background: transparent;
}
.publicItem.active {
  background: #fff; color: rgb(51,51,51);
  font-weight: 600; box-shadow: 0 2px 8px rgba(0,0,0,0.12);
}
```

---

### 套餐卡片区 + 翻页按钮

```html
<div class="pricing-carousel-wrap">
  <button class="carousel-btn prev-btn">上一组</button>
  <div class="pricing-cards-container">
    <!-- 卡片列表（见下方单张卡片结构） -->
  </div>
  <button class="carousel-btn next-btn">下一组</button>
</div>
```

```css
.pricing-carousel-wrap {
  display: flex; align-items: center; gap: 16px;
  position: relative;
}
.carousel-btn {
  width: 40px; height: 40px; border-radius: 50%;
  background: #fff; border: 1px solid #e8e8e8;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  cursor: pointer; font-size: 12px; flex-shrink: 0;
  transition: all 0.15s;
}
.carousel-btn:hover { border-color: #141414; }
.carousel-btn:disabled { opacity: 0.3; cursor: not-allowed; }
.pricing-cards-container {
  display: flex; gap: 16px; overflow: hidden;
}
```

---

### 定价卡片（`.productCard`）

卡片宽度约 **280–328px**，整体白色背景，推荐卡片荧光绿边框发光。

```css
.productCard {
  width: 280px; min-height: 700px;
  border-radius: 16px; background: #fff;
  border: 2px solid transparent;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  overflow: hidden; transition: all 0.2s ease;
  display: flex; flex-direction: column;
}
.productCard.active {
  border: 2px solid rgb(178,255,0);
  box-shadow: 0 4px 16px rgba(178,255,0,0.6);
}
.productCard:hover {
  box-shadow: 0 8px 24px rgba(0,0,0,0.15);
  transform: translateY(-2px);
}
```

---

### 点数档位下拉选择器（卡片内 combobox）

每张付费卡片头部都有一个下拉选择器，让用户在当前套餐内选择不同点数档位，价格随之联动更新。

```html
<div class="points-tier-selector">
  <select class="points-select" onchange="updateCardPrice(this)">
    <option value="0">200点 · ¥39</option>
    <option value="1">500点 · ¥99</option>
  </select>
</div>
```

```css
.points-tier-selector {
  margin-bottom: 12px;
}
.points-select {
  width: 100%; padding: 8px 12px;
  border: 1px solid #e8e8e8; border-radius: 8px;
  font-size: 14px; color: #141414; background: #fff;
  cursor: pointer; appearance: none;
  background-image: url("data:image/svg+xml,..."); /* 自定义箭头 */
  background-repeat: no-repeat; background-position: right 10px center;
}
.points-select:focus { border-color: rgb(178,255,0); outline: none; }
```

---

### "同时享" 特权标签行

年卡套餐特有，展示折扣力度和香蕉模型无限用权益：

```html
<div class="perks-row">
  <span class="perk-label">同时享:</span>
  <span class="perk-tag discount-tag">扣点7.5折</span>
  <span class="perk-banana">🍌全能香蕉2.0 <strong>无限用</strong></span>
</div>
```

```css
.perks-row {
  display: flex; align-items: center; gap: 6px;
  padding: 8px 0; font-size: 12px;
  border-top: 1px solid #f0f0f0;
}
.perk-label { color: #999; }
.perk-tag {
  padding: 2px 8px; border-radius: 100px;
  font-size: 11px; font-weight: 600;
}
.discount-tag {
  background: rgba(212,253,83,0.25); color: #5a6a00;
}
.perk-banana {
  font-size: 12px; color: #333;
}
.perk-banana strong { color: #141414; font-weight: 600; }
```

---

### 套餐数据（当前7档，2025年版）

| 套餐名 | 基础价 | 点数档位（下拉） | 特权 | 并发任务 | CTA |
|--------|--------|----------------|------|--------|-----|
| 免费 | ¥0 | 每日10点（不可选） | — | 2 | 当前计划（灰） |
| AI创作VIP 月卡 | ¥39 | 200点/500点 | — | 2 | 立即开通（白框） |
| AI创作VIP 连续包月 | ¥29（原¥39）| 200点/500点 | 赠1月下载VIP | 2 | 立即开通（黑底，推荐） |
| AI创作VIP 年卡 | ¥99 | 1200/2400/6000/9600点 | 1年下载VIP · 7.5折 · 香蕉2.0无限 | 4 | 立即开通（白框） |
| AI创作VIP 年卡 | ¥199 | 2400/6000/9600点 | 1年下载VIP · 6折 · 香蕉2.0/Pro无限 | 6 | 立即开通（白框） |
| AI创作VIP 年卡 | ¥299 | 2800/3800/4800点 | 1年超级SVIP · 5.5折 · 香蕉4K无限 | 8 | 立即开通（白框） |
| AI创作VIP 年卡 | ¥499 | 5000/6000/10000/15000点 | 终身超级SVIP · 4折 · 香蕉4K无限 | 10 | 立即开通（白框） |
| 企业PLUS | 按需定制 | — | — | — | 查看解决方案 |

> **到账规则**：月卡/连续包月/单次年卡 → 一次性到账；分月年卡（¥99/¥199）→ 每月到账，月底清零。

---

### CTA 按钮样式

```css
/* 当前计划（免费档，禁用） */
.productCardContentButton.currentPlan {
  background: rgb(232,232,232); color: rgb(51,51,51);
  border-color: rgb(232,232,232); cursor: not-allowed;
}
/* 普通立即开通 */
.productCardContentButton.open {
  background: #fff; color: rgb(51,51,51); border-color: rgb(51,51,51);
}
.productCardContentButton.open:hover {
  background: rgb(20,20,20); color: #fff; border-color: rgb(20,20,20);
}
/* 推荐卡片内的 CTA（黑底） */
.productCard.active .productCardContentButton {
  background: rgb(20,20,20); color: #fff; border-color: rgb(51,51,51);
}
.productCard.active .productCardContentButton:hover {
  background: rgb(178,255,0); color: rgb(20,20,20); border-color: rgb(178,255,0);
}
/* 通用按钮结构 */
.productCardContentButton {
  width: 100%; height: 40px; border-radius: 40px;
  font-size: 15px; font-weight: 600; border: 1px solid;
  cursor: pointer; display: flex; align-items: center;
  justify-content: center; transition: all 0.15s ease;
}
```

---

### 权益列表项（`.productCardBottomItem`）

```css
.productCardBottomItem {
  display: flex; align-items: flex-start; gap: 8px;
  padding: 10px 0; font-size: 14px; color: var(--qtd-text-primary);
  border-bottom: 1px solid var(--qtd-border-light);
}
.productCardBottomItem .icon-check { color: rgb(178,255,0); flex-shrink: 0; margin-top: 2px; }
/* 不支持项（叉号，灰色） */
.productCardBottomItem .icon-cross { color: #ccc; flex-shrink: 0; margin-top: 2px; }
```

---

### 底部模型对比表

点击"详细对比模型权益"展开，展示各套餐对应每个模型的用量：

```html
<button class="model-detail-toggle" onclick="toggleModelTable()">
  <span>详细对比模型权益</span>
  <span class="toggle-icon">▼</span>
</button>

<div class="model-comparison-table" id="modelTable" style="display:none">
  <!-- 分类行 -->
  <div class="model-category-header">图片模型</div>
  <!-- 模型行 -->
  <div class="model-row">
    <div class="model-name">即梦4.5 <span class="model-cost">图片2点/张</span></div>
    <!-- 每列：免费 / 月卡 / 连续包月 / 年卡... -->
    <div class="model-plan-cell free">100张</div>
    <div class="model-plan-cell paid">200张</div>
    <!-- ...更多套餐列 -->
  </div>
</div>
```

```css
.model-detail-toggle {
  display: flex; align-items: center; gap: 8px;
  padding: 12px 24px; background: none;
  border: 1px solid #e8e8e8; border-radius: 8px;
  font-size: 14px; color: #333; cursor: pointer;
  transition: all 0.15s;
}
.model-detail-toggle:hover { border-color: #141414; }
.model-comparison-table {
  width: 100%; border-collapse: collapse; font-size: 13px;
  margin-top: 16px;
}
.model-category-header {
  padding: 10px 16px; font-weight: 700; font-size: 14px;
  background: #f7f7f7; color: #141414;
  border-top: 1px solid #e8e8e8;
}
.model-row {
  display: grid;
  grid-template-columns: 200px repeat(7, 1fr); /* 1名称列 + 7套餐列 */
  border-bottom: 1px solid #f0f0f0;
}
.model-name {
  padding: 10px 16px; color: #333; font-size: 13px;
}
.model-cost {
  font-size: 11px; color: #999; margin-left: 4px;
}
.model-plan-cell {
  padding: 10px 8px; text-align: center;
  font-size: 12px; color: #333;
}
.model-plan-cell.unlimited {
  color: rgb(0,178,119); font-weight: 600;
}
```

**图片模型列表**（含点数成本）：

| 模型 | 点数 | 模型 | 点数 |
|------|------|------|------|
| 即梦4.5 | 2点/张 | 全能香蕉2.0 | 2点/张 |
| 豆包4.0 | 1点/张 | 即梦5.0 | 2点/张 |
| 即梦4.0 | 2点/张 | 智能GPT1.5 | 8点/张 |
| 通义2.1专业 | 1点/张 | 全能香蕉Pro | 2点/张 |
| 豆包3.0/2.1/2.0Pro | 1点/张 | minimax_music | 5点/张 |

**视频模型列表**（主要型号）：

| 模型 | 点数 | 模型 | 点数 |
|------|------|------|------|
| 可灵2.1标准 | 35点/个 | Seedance2.0 | 140点/个 |
| 可灵2.0大师 | 160点/个 | 全能VeoQ3.1 | 20点/个 |
| 海螺视频2.3 | 50点/个 | ViduQ3高级 | 160点/个 |
| 豆包1.0Pro | 60点/个 | 通义2.2专业 | 30点/个 |

**3D模型**：混元3D极速版(80点)、混元3DPro(1点)、智能3D文/图生3D(1点)、豆包3D1.0(20点)

**音乐模型**：智能SunoQV5 (5点/首)

---

### 价值对比区

```html
<section class="value-comparison">
  <h2>为什么前1%的设计师选择千图AI？</h2>
  <p class="value-subtitle">买一个模型的价格，解锁图片/视频/音乐等全套模型</p>
  <div class="value-compare-grid">
    <!-- 左：竞品成本 -->
    <div class="compare-col competitor">
      <div class="compare-title">订阅模型会员</div>
      <div class="compare-item">🎨 即梦/豆包… <strong>¥56/月起</strong></div>
      <div class="compare-item">🎬 可灵/海螺 <strong>¥78/月起</strong></div>
      <div class="compare-total">年度总花费不低于 <span class="big-num">¥300</span></div>
    </div>
    <!-- 右：千图AI -->
    <div class="compare-col qiantu">
      <div class="compare-title">模型全能合一</div>
      <div class="compare-tags">
        <span>多模态模型</span>
        <span>AI模板一键同款</span>
      </div>
      <div class="compare-price">仅需 <strong>¥29</strong>/月起</div>
      <button class="compare-cta">立即开通</button>
    </div>
  </div>
</section>
```

```css
.value-comparison {
  padding: 60px 24px; text-align: center;
  background: var(--qtd-bg-secondary);
}
.value-compare-grid {
  display: grid; grid-template-columns: 1fr 1fr;
  gap: 24px; max-width: 640px; margin: 32px auto 0;
}
.compare-col {
  padding: 24px; border-radius: 16px;
  background: var(--qtd-bg-primary);
  border: 1px solid var(--qtd-border-light);
}
.compare-col.qiantu {
  border-color: rgb(178,255,0);
  box-shadow: 0 4px 16px rgba(178,255,0,0.2);
}
.big-num { font-size: 28px; font-weight: 800; color: #141414; }
.compare-price strong { font-size: 28px; font-weight: 800; color: rgb(178,255,0); }
```

---

## 二、千图主站 定价页（58pic.com/pricing）

### 页面结构

```
顶部 Header（同主站）
页面 title: "定价 & 套餐"
主体白色背景，非深色

套餐对比区（.simple-contrast-table-wrap）
  └── 横向 5 列套餐对比表
      └── 权益详情展开（contrastTable-wrap）
升级提醒区（.up-vip-wrap-new）
老用户权益说明区（.old-vip-desc-wrap）
```

### 套餐列表（5种）

| 套餐名 | 价格 | 定位 |
|--------|------|------|
| 免费 | ¥0 | 基础免费 |
| AI创作VIP 个人版 | ¥29/月 | AI功能 |
| 下载VIP 个人版 | ¥19/月起 | 素材下载 |
| 商用VIP 个人版 | ¥199/年起 | 商用授权 |
| 商用VIP 企业版 | ¥999/年起 | 企业采购 |

### 主站定价卡片样式

```css
/* 主站用绿色品牌色体系，非荧光绿 */
:root {
  --qtp-price-highlight: #00B277;      /* 主站绿色 */
  --qtp-price-bg: #ffffff;             /* 白色背景 */
  --qtp-price-border: #e8e8e8;         /* 浅灰边框 */
  --qtp-price-active-border: #00B277;  /* 激活卡片绿色边框 */
}

/* 套餐卡片 */
.price-plan-card {
  background: var(--qtp-price-bg);
  border: 1.5px solid var(--qtp-price-border);
  border-radius: 12px;
  padding: 24px;
  transition: all 0.2s ease;
}
.price-plan-card:hover {
  border-color: var(--qtp-price-highlight);
  box-shadow: 0 4px 16px rgba(0, 178, 119, 0.15);
}

/* 推荐卡片 */
.price-plan-card.active {
  border-color: var(--qtp-price-highlight);
  box-shadow: 0 4px 16px rgba(0, 178, 119, 0.2);
}

/* 价格数字 */
.vip-price {
  font-size: 14px;
  color: rgb(153, 153, 153);   /* 灰色，旁边有大号价格展示 */
}

/* 开通按钮 */
.open-vip-btn {
  background: var(--qtp-price-highlight);
  color: #ffffff;
  border-radius: 20px;
  padding: 10px 24px;
  font-size: 14px;
  font-weight: 600;
  border: none;
  cursor: pointer;
  transition: all 0.15s ease;
}
.open-vip-btn:hover {
  background: #009966;   /* 深一度的绿 */
}

/* 套餐对比表 */
.simple-contrast-table-wrap {
  width: 100%;
  overflow-x: auto;
}
```

### 权益类别项（`.vip-type-equity-content-item`）

```css
.vip-type-equity-content-item {
  padding: 12px 16px;
  border-radius: 8px;
  transition: background 0.15s ease;
}
/* hover 态（真实观测有 .hover class） */
.vip-type-equity-content-item.hover,
.vip-type-equity-content-item:hover {
  background: rgba(0, 178, 119, 0.06);
}
```

---

## 三、千图企业站 定价页（qiye.58pic.com/enterprise/pricing）

### 页面结构

```
顶部 Header（白色/深色企业站风格）
  └── 两栏切换卡片（中小微企业VIP / 大型企业PLUS）
      └── 激活卡片：具体定价方案（3-4个子套餐）
          └── 功能权益对比表
联系销售 / 获取方案 CTA
```

### 套餐切换卡（`.vip-card-item`）

```css
/* 切换器容器 */
.vip-card-change {
  display: flex;
  gap: 16px;
}

/* 卡片 */
.vip-card-item {
  width: 480px;
  padding: 24px;
  border-radius: 16px;
  cursor: pointer;
  transition: all 0.2s ease;
  /* 非激活：有背景图 (to-left-1.png) */
  background-size: cover;
}

/* 激活态 */
.vip-card-item.active {
  /* 背景图 to-right-1.png（渐变科技感） */
  background-size: cover;
}

/* 标题 */
.vip-card-item p {
  font-size: 20px;
  font-weight: 700;
  color: #ffffff;
  margin: 0 0 8px 0;
}

/* VIP/PLUS 徽标 */
.vip-card-item em.qt-number {
  font-style: normal;
  font-size: 20px;
  font-weight: 800;
  /* 渐变金/品牌色 */
  background: linear-gradient(to right, #40FFAA, #4079FF);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
```

### 企业套餐定价数据

**中小微企业 VIP（1-50人）：**

| 套餐 | 年付价 | 原价 |
|------|--------|------|
| 基础版 | ¥299/年 | ¥399 |
| 标准版 | ¥799/年 | ¥999 |
| 旗舰版 | ¥1,599/年 | ¥1,999 |

**大型企业 PLUS：** 不限用量、不限主体、更多用途授权，需联系销售定制。

### 企业站 CTA 按钮（`.qtd-btn`）

企业站使用蓝色系主色（区别于AI站荧光绿），使用 `.qtd-btn` 系统：

```css
/* 蓝色主按钮（企业站） */
.qtd-btn.qtd-primary-business-btn {
  background: rgb(25, 128, 255);   /* 品牌蓝 */
  color: rgb(255, 255, 255);
  border-radius: 8px;
  padding: 10px 20px;
  font-size: 14px;
  font-weight: 600;
  border: none;
  cursor: pointer;
  transition: all 0.15s ease;
}
.qtd-btn.qtd-primary-business-btn:hover {
  background: #1a6fd4;
  box-shadow: 0 4px 12px rgba(25, 128, 255, 0.4);
}

/* 大尺寸按钮 */
.qtd-btn.qtd-large-btn {
  padding: 14px 32px;
  font-size: 16px;
  border-radius: 10px;
}

/* 获取方案（青蓝渐变按钮） */
.qtd-btn-gradient {
  background: linear-gradient(to right, #40FFAA, #4079FF);
  color: #ffffff;
  border: none;
  border-radius: 8px;
  padding: 12px 24px;
  font-weight: 600;
  cursor: pointer;
}
.qtd-btn-gradient:hover {
  opacity: 0.9;
  box-shadow: 0 4px 16px rgba(64, 121, 255, 0.4);
}
```

---

## 完整定价页 HTML 示例（千图AI）

包含：促销 Banner + Tab 切换 + 翻页 + 卡片（点数下拉 + 特权行 + CTA + 权益列表）结构骨架。

```html
<!-- 促销 Banner -->
<div class="promo-banner">
  <span class="promo-badge">春季限时优惠</span>
  <span>买AI创作VIP 赠下载VIP</span>
  <button class="promo-buy-points">单独购买点数</button>
  <span class="discount-badge">5折优惠</span>
</div>

<!-- 标题区 -->
<div class="pricing-hero" style="text-align:center;padding:48px 24px 24px">
  <h1 style="font-size:32px;font-weight:800;color:var(--qtd-text-primary)">AI创作VIP</h1>
  <p style="color:var(--qtd-text-secondary);margin-top:8px">AI时代设计师的标配</p>
  <!-- 个人/企业 Tab -->
  <div class="tab-switcher" style="margin-top:24px">
    <div class="publicItem active">个人</div>
    <div class="publicItem">企业</div>
  </div>
</div>

<!-- 卡片区 + 翻页 -->
<div class="pricing-carousel-wrap" style="display:flex;align-items:flex-start;gap:12px;padding:0 24px">
  <button class="carousel-btn" disabled>上一组</button>

  <div class="pricing-cards-container" style="display:flex;gap:12px;flex:1;overflow:hidden">

    <!-- 免费卡片 -->
    <div class="productCard" style="flex:1;min-width:220px">
      <div style="padding:20px">
        <div class="productCardContentName">免费</div>
        <div style="font-size:11px;color:#999;margin-bottom:12px">每日到账 10点</div>
        <div class="productCardContentPrice">¥0</div>
        <button class="productCardContentButton currentPlan" style="margin-top:16px">当前计划</button>
      </div>
      <div style="padding:0 20px">
        <div class="productCardBottomItem"><span style="color:rgb(178,255,0)">✓</span><span>每天赠送 10 点</span></div>
        <div class="productCardBottomItem"><span style="color:rgb(178,255,0)">✓</span><span>同时 2 个任务</span></div>
        <div class="productCardBottomItem"><span style="color:#ccc">✗</span><span style="color:#999">不支持高清 2K/4K</span></div>
      </div>
    </div>

    <!-- 月卡 -->
    <div class="productCard" style="flex:1;min-width:220px">
      <div style="padding:20px">
        <div class="productCardContentName">AI创作VIP 月卡</div>
        <div style="font-size:11px;color:#999;margin-bottom:8px">总到账 200点</div>
        <!-- 点数档位下拉 -->
        <select class="points-select">
          <option>200点 · ¥39</option>
          <option>500点 · ¥99</option>
        </select>
        <div class="productCardContentPrice" style="margin-top:12px">¥39</div>
        <button class="productCardContentButton open" style="margin-top:16px">立即开通</button>
      </div>
      <div style="padding:0 20px">
        <div class="productCardBottomItem"><span style="color:rgb(178,255,0)">✓</span><span>一次性到账 200 点</span></div>
        <div class="productCardBottomItem"><span style="color:rgb(178,255,0)">✓</span><span>最高 4K 高清生成</span></div>
        <div class="productCardBottomItem"><span style="color:rgb(178,255,0)">✓</span><span>同时 2 个任务</span></div>
      </div>
    </div>

    <!-- 连续包月（推荐，active） -->
    <div class="productCard active" style="flex:1;min-width:220px;position:relative">
      <div style="position:absolute;top:12px;right:12px;background:rgb(178,255,0);color:#141414;
                  padding:2px 10px;border-radius:100px;font-size:11px;font-weight:700">推荐</div>
      <div style="padding:20px">
        <div class="productCardContentName">AI创作VIP 连续包月</div>
        <div style="font-size:11px;color:#999;margin-bottom:8px">总到账 200点</div>
        <select class="points-select">
          <option>200点 · ¥29</option>
          <option>500点 · ¥72</option>
        </select>
        <div class="productCardContentPrice" style="margin-top:12px">
          ¥29 <span style="font-size:14px;color:#999;text-decoration:line-through;margin-left:4px">¥39</span>
        </div>
        <!-- 赠品标签 -->
        <div style="font-size:12px;color:#5a6a00;background:rgba(212,253,83,.25);
                    padding:3px 10px;border-radius:100px;display:inline-block;margin-top:6px">
          🎁 赠1月下载VIP
        </div>
        <button class="productCardContentButton" style="margin-top:16px;background:#141414;color:#fff;border-color:#333">
          立即开通
        </button>
      </div>
      <div style="padding:0 20px">
        <div class="productCardBottomItem"><span style="color:rgb(178,255,0)">✓</span><span>一次性到账 200 点</span></div>
        <div class="productCardBottomItem"><span style="color:rgb(178,255,0)">✓</span><span>最高 4K 高清生成</span></div>
      </div>
    </div>

    <!-- 年卡 ¥99（含特权行） -->
    <div class="productCard" style="flex:1;min-width:220px">
      <div style="padding:20px">
        <div class="productCardContentName">AI创作VIP 年卡</div>
        <div style="font-size:11px;color:#999;margin-bottom:8px">总到账 1,200点</div>
        <select class="points-select">
          <option>1,200点 · ¥99</option>
          <option>2,400点 · ¥198</option>
          <option>6,000点 · ¥495</option>
          <option>9,600点 · ¥795</option>
        </select>
        <!-- 特权行 -->
        <div class="perks-row" style="margin-top:10px">
          <span style="color:#999;font-size:12px">同时享:</span>
          <span class="perk-tag discount-tag">扣点7.5折</span>
          <span style="font-size:12px">🍌香蕉2.0 <strong>无限用</strong></span>
        </div>
        <div class="productCardContentPrice" style="margin-top:8px">¥99</div>
        <button class="productCardContentButton open" style="margin-top:16px">立即开通</button>
      </div>
      <div style="padding:0 20px">
        <div class="productCardBottomItem"><span style="color:rgb(178,255,0)">✓</span><span>每月到账 100 点</span></div>
        <div class="productCardBottomItem"><span style="color:rgb(178,255,0)">✓</span><span>1年下载VIP</span></div>
        <div class="productCardBottomItem"><span style="color:rgb(178,255,0)">✓</span><span>同时 4 个任务</span></div>
      </div>
    </div>

  </div><!-- /pricing-cards-container -->

  <button class="carousel-btn">下一组</button>
</div>

<!-- 模型对比表切换按钮 -->
<div style="text-align:center;margin:32px 0">
  <button class="model-detail-toggle" onclick="this.nextElementSibling.style.display=
    this.nextElementSibling.style.display==='none'?'block':'none'">
    详细对比模型权益 ▼
  </button>
  <div style="display:none;margin-top:16px;overflow-x:auto">
    <div class="model-category-header">图片模型</div>
    <div class="model-row">
      <div class="model-name">即梦4.5 <span class="model-cost">2点/张</span></div>
      <div class="model-plan-cell">100张</div>
      <div class="model-plan-cell">200张</div>
      <div class="model-plan-cell">200张</div>
      <div class="model-plan-cell">1200张</div>
    </div>
    <!-- 更多模型行... -->
    <div class="model-category-header">视频模型</div>
    <div class="model-row">
      <div class="model-name">可灵2.1标准 <span class="model-cost">35点/个</span></div>
      <div class="model-plan-cell">5个</div>
      <div class="model-plan-cell">5个</div>
      <div class="model-plan-cell">5个</div>
      <div class="model-plan-cell">34个</div>
    </div>
  </div>
</div>

<style>
.promo-banner{display:flex;align-items:center;gap:12px;padding:12px 24px;background:#141414;color:#fff;font-size:14px}
.promo-badge{padding:2px 10px;border-radius:100px;background:rgb(212,253,83);color:#141414;font-size:12px;font-weight:600}
.discount-badge{padding:2px 8px;border-radius:100px;background:rgba(255,255,255,.15);color:#fff;font-size:12px}
.promo-buy-points{background:none;border:1px solid rgba(255,255,255,.4);color:#fff;padding:4px 12px;border-radius:100px;font-size:12px;cursor:pointer}
.tab-switcher{display:inline-flex;background:var(--qtd-bg-secondary,#f5f5f5);border-radius:88px;padding:4px}
.publicItem{padding:8px 24px;border-radius:88px;font-size:14px;cursor:pointer;transition:all 0.2s;color:#666}
.publicItem.active{background:#fff;color:#333;font-weight:600;box-shadow:0 2px 8px rgba(0,0,0,.12)}
.carousel-btn{width:40px;height:40px;border-radius:50%;background:#fff;border:1px solid #e8e8e8;cursor:pointer;flex-shrink:0;align-self:center}
.carousel-btn:disabled{opacity:.3;cursor:not-allowed}
.productCard{border-radius:16px;background:#fff;border:2px solid transparent;box-shadow:0 2px 8px rgba(0,0,0,.1);overflow:hidden;transition:all 0.2s;display:flex;flex-direction:column}
.productCard.active{border-color:rgb(178,255,0);box-shadow:0 4px 16px rgba(178,255,0,.6)}
.productCardContentName{font-size:16px;font-weight:700;color:#141414;margin-bottom:4px}
.productCardContentPrice{font-size:28px;font-weight:800;color:#141414}
.productCardContentButton{width:100%;height:40px;border-radius:40px;font-size:15px;font-weight:600;border:1px solid;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all 0.15s}
.productCardContentButton.currentPlan{background:#e8e8e8;color:#333;border-color:#e8e8e8;cursor:not-allowed}
.productCardContentButton.open{background:#fff;color:#333;border-color:#333}
.productCardBottomItem{display:flex;align-items:flex-start;gap:8px;padding:10px 0;font-size:13px;border-bottom:1px solid #f0f0f0}
.points-select{width:100%;padding:7px 10px;border:1px solid #e8e8e8;border-radius:8px;font-size:13px;cursor:pointer}
.perks-row{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
.perk-tag{padding:2px 8px;border-radius:100px;font-size:11px;font-weight:600}
.discount-tag{background:rgba(212,253,83,.25);color:#5a6a00}
.model-detail-toggle{padding:10px 24px;background:none;border:1px solid #e8e8e8;border-radius:8px;font-size:14px;color:#333;cursor:pointer}
.model-category-header{padding:10px 16px;font-weight:700;background:#f7f7f7;color:#141414;border-top:1px solid #e8e8e8}
.model-row{display:flex;gap:0;border-bottom:1px solid #f0f0f0}
.model-name{flex:0 0 180px;padding:10px 16px;font-size:13px;color:#333}
.model-cost{font-size:11px;color:#999;margin-left:4px}
.model-plan-cell{flex:1;padding:10px 8px;text-align:center;font-size:12px;color:#333}
</style>
```
