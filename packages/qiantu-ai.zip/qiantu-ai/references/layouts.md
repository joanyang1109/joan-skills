# 千图AI 布局模板

## 目录

1. [布局 1：首页创作模式（最常用）](#布局-1首页创作模式最常用)
2. [布局 2：工具详情页（左参数 + 右预览）](#布局-2工具详情页左参数--右预览)
3. [布局 3：作品展示页（瀑布流）](#布局-3作品展示页瀑布流)
4. [布局 4：弹窗/模态框](#布局-4弹窗模态框)
5. [响应式处理](#响应式处理)

---

## 布局 1：首页创作模式（最常用）

Header + 左侧图标栏 + 中央提示词 + 功能卡片 + 社区瀑布流

```html
<!DOCTYPE html>
<html lang="zh-CN" data-theme="light">
<head>
  <meta charset="UTF-8">
  <title>千图AI</title>
  <style>
    /* [粘贴 design-tokens.md] */

    .qtd-layout {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    /* header 见 components.md */

    .qtd-body {
      display: flex;
      flex: 1;
    }
    /* sidebar 见 components.md */

    .qtd-main {
      flex: 1;
      overflow-y: auto;
      background: var(--qtd-bg-page);
    }
    .qtd-home-hero {
      text-align: center;
      padding: 48px 24px 32px;
    }
    .qtd-home-title {
      font-size: 32px;
      font-weight: 800;
      color: var(--qtd-text-primary);
      margin: 0 0 8px;
    }
    .qtd-home-subtitle {
      font-size: 15px;
      color: var(--qtd-text-secondary);
      margin: 0 0 32px;
    }
    .qtd-home-content {
      max-width: var(--qtd-content-max);
      margin: 0 auto;
      padding: 0 24px 48px;
    }
    /* prompt-box, feature-grid, tabs, waterfall 见 components.md */
  </style>
</head>
<body>
<div class="qtd-layout">
  <!-- Header -->
  <header class="qtd-header">...</header>

  <div class="qtd-body">
    <!-- 左侧图标导航 -->
    <aside class="qtd-sidebar">...</aside>

    <!-- 主内容 -->
    <main class="qtd-main">
      <!-- Hero 区 -->
      <div class="qtd-home-hero">
        <h1 class="qtd-home-title">欢迎使用千图AI</h1>
        <p class="qtd-home-subtitle">实时更新全球模型 创意一键同款</p>
        <!-- 提示词输入框 -->
        <div class="qtd-prompt-box">...</div>
      </div>

      <div class="qtd-home-content">
        <!-- 功能卡片 -->
        <div class="qtd-feature-grid">...</div>

        <!-- 社区区域 -->
        <div class="qtd-section-header">
          <h2 class="qtd-section-title">AI 社区：探索更多创意表达</h2>
        </div>
        <div class="qtd-tabs">...</div>
        <div class="qtd-waterfall" style="margin-top:16px;">...</div>
      </div>
    </main>
  </div>
</div>
</body>
</html>
```

---

## 布局 2：工具详情页（左参数 + 右预览）

```html
<div class="qtd-layout">
  <header class="qtd-header">...</header>
  <div class="qtd-body">
    <aside class="qtd-sidebar">...</aside>
    <main class="qtd-tool-workspace">
      <!-- 左侧：参数面板 -->
      <div class="qtd-param-panel">
        <h3 class="qtd-panel-title">生成设置</h3>
        <!-- 参数表单 -->
        <div class="qtd-param-group">
          <label class="qtd-label">模型</label>
          <select class="qtd-select">...</select>
        </div>
        <div class="qtd-param-group">
          <label class="qtd-label">比例</label>
          <div class="qtd-ratio-grid">...</div>
        </div>
        <button class="qtd-btn-create" style="width:100%;">✦ 开始生成</button>
      </div>
      <!-- 右侧：预览区 -->
      <div class="qtd-preview-area">
        <div class="qtd-preview-placeholder">
          <span>生成结果将显示在这里</span>
        </div>
      </div>
    </main>
  </div>
</div>
```

```css
.qtd-tool-workspace {
  display: flex;
  flex: 1;
  gap: 0;
  overflow: hidden;
}
.qtd-param-panel {
  width: 280px;
  flex-shrink: 0;
  background: var(--qtd-bg-content);
  border-right: 1px solid var(--qtd-border);
  padding: 20px 16px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.qtd-panel-title {
  font-size: 15px;
  font-weight: 600;
  color: var(--qtd-text-primary);
  margin: 0;
}
.qtd-param-group { display: flex; flex-direction: column; gap: 6px; }
.qtd-label { font-size: 13px; color: var(--qtd-text-secondary); }
.qtd-select {
  background: var(--qtd-bg-input);
  border: 1px solid var(--qtd-border);
  border-radius: 10px;
  padding: 8px 12px;
  font-size: 14px;
  color: var(--qtd-text-primary);
  outline: none;
  cursor: pointer;
}
.qtd-select:focus { border-color: var(--qtd-lime); }

.qtd-preview-area {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--qtd-bg-page);
  padding: 24px;
}
.qtd-preview-placeholder {
  width: 100%;
  max-width: 600px;
  aspect-ratio: 1;
  border-radius: 20px;
  border: 2px dashed var(--qtd-border);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--qtd-text-tertiary);
  font-size: 15px;
}
```

---

## 布局 3：作品展示页（瀑布流）

```html
<div class="qtd-layout">
  <header class="qtd-header">...</header>
  <div class="qtd-body">
    <aside class="qtd-sidebar">...</aside>
    <main class="qtd-gallery-main">
      <div class="qtd-gallery-header">
        <h2 class="qtd-section-title">探索作品</h2>
        <div class="qtd-tabs">...</div>
      </div>
      <div class="qtd-waterfall">...</div>
    </main>
  </div>
</div>
```

```css
.qtd-gallery-main {
  flex: 1;
  padding: 24px;
  overflow-y: auto;
}
.qtd-gallery-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
  flex-wrap: wrap;
  gap: 12px;
}
```

---

## 布局 4：弹窗/模态框

```html
<div class="qtd-modal-overlay" onclick="closeModal()">
  <div class="qtd-modal" onclick="event.stopPropagation()">
    <div class="qtd-modal-header">
      <h3 class="qtd-modal-title">开通 AI 创作 VIP</h3>
      <button class="qtd-modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="qtd-modal-body">
      <!-- 内容 -->
    </div>
    <div class="qtd-modal-footer">
      <button class="qtd-btn-ghost">取消</button>
      <button class="qtd-btn-vip">立即开通</button>
    </div>
  </div>
</div>
```

```css
.qtd-modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(4px);
}
.qtd-modal {
  background: var(--qtd-bg-header);
  border: 1px solid var(--qtd-border);
  border-radius: 24px;
  padding: 24px;
  min-width: 360px;
  max-width: 480px;
  width: 90%;
  box-shadow: var(--qtd-shadow-modal);
}
.qtd-modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;
}
.qtd-modal-title { font-size: 18px; font-weight: 700; margin: 0; }
.qtd-modal-close {
  background: none;
  border: none;
  font-size: 18px;
  cursor: pointer;
  color: var(--qtd-text-tertiary);
  padding: 4px;
}
.qtd-modal-footer {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
  margin-top: 20px;
  padding-top: 16px;
  border-top: 1px solid var(--qtd-border);
}
```

---

## 响应式处理

```css
/* 在 1100px 以下折叠为单列 */
@media (max-width: 1100px) {
  .qtd-feature-grid { grid-template-columns: repeat(2, 1fr); }
  .qtd-waterfall { columns: 2; }
  .qtd-tool-workspace { flex-direction: column; }
  .qtd-param-panel { width: 100%; border-right: none; border-bottom: 1px solid var(--qtd-border); }
}

@media (max-width: 640px) {
  .qtd-nav { display: none; } /* 移动端隐藏顶部导航 */
  .qtd-feature-grid { grid-template-columns: 1fr 1fr; }
  .qtd-waterfall { columns: 2; }
  .qtd-home-title { font-size: 22px; }
  .qtd-prompt-box { border-radius: 20px; }
}
```
