# 千图AI 高级交互模式

从真实产品实现中提炼的复杂交互模式，供需要还原完整产品体验时参考。

## 目录

1. [bg-box 浮动下拉面板模式](#1-bg-box-浮动下拉面板模式)
2. [Z-index 层级体系](#2-z-index-层级体系)
3. [模型选择下拉面板](#3-模型选择下拉面板)
4. [参数面板（比例 / 时长 / 运镜）](#4-参数面板比例--时长--运镜)
5. [AI工具 Mega Dropdown（body 级定位）](#5-ai工具-mega-dropdownbody-级定位)
6. [图片选择器完整系统](#6-图片选择器完整系统)
7. [关闭下拉的标准处理](#7-关闭下拉的标准处理)
8. [工具栏结构](#8-工具栏结构)
9. [常见陷阱 & 避免方法](#9-常见陷阱--避免方法)

---

## 1. bg-box 浮动下拉面板模式

这是千图AI最有特色的下拉定位方式：下拉面板以"包裹触发元素"的方式呈现，形成一个视觉连续的大卡片，而不是普通的下方弹出。

### 核心思想

下拉框的位置和尺寸动态计算，使其像一个放大版的容器把触发元素"包住"：

```css
.bg-box-drop {
  position: fixed;
  background: var(--qtd-bg-page);
  border-radius: 20px;
  box-shadow: var(--qtd-shadow-modal);
  /* 注意：不设置 border，只用阴影区分层级 */
  z-index: 300;
  overflow: hidden;
}
```

### JS 定位逻辑

```js
function openBgBoxDrop(triggerEl, dropEl, dropWidth, dropHeight) {
  const rect = triggerEl.getBoundingClientRect();
  const PADDING = 8; // 触发元素四周留出的间距

  dropEl.style.left   = (rect.left - PADDING) + 'px';
  dropEl.style.top    = (rect.top  - PADDING) + 'px';
  dropEl.style.width  = (rect.width  + PADDING * 2) + 'px';
  // paddingTop 留出高度，让触发元素的位置看起来没有移动
  dropEl.style.paddingTop = (rect.height + PADDING * 2) + 'px';
  dropEl.style.minHeight  = dropHeight + 'px';
  dropEl.style.display    = 'block';
}
```

**使用场景**：模型选择、图片生成参数面板、图片选择器。

### 滚动时重新定位

下拉框是 `position:fixed`，但页面滚动时触发元素位置变化，需要监听滚动事件：

```js
window.addEventListener('scroll', function() {
  if (activeDrop) repositionDrop(activeDrop);
}, { passive: true });
```

---

## 2. Z-index 层级体系

避免层叠冲突，严格遵循以下层级：

| 层级 | z-index | 说明 |
|------|---------|------|
| 顶部导航栏 | 200 | `.qtd-header` |
| 普通下拉面板 | 300 | 模型选择、参数面板、图片选择器 |
| Prompt 输入框 | 400 | `.qtd-prompt-box`（有 position:relative） |
| 工具栏下拉（AI工具等）| 600 | **必须挂载到 body**，否则会被 header 裁切 |
| 弹窗蒙层 | 800 | `.qtd-modal-mask` |
| 弹窗内容 | 900 | `.qtd-modal` |

### 关键原则

**AI工具等 mega-dropdown 必须挂载到 `<body>` 末尾**，不能放在 header 内部。原因：header 自身创建了新的 stacking context（因为 `position:fixed + z-index:200`），其内部子元素无论 z-index 多大都无法超出 header 层级。

```js
// 错误：把 mega-dropdown 放在 header 内
// 正确：
document.body.appendChild(toolsDrop);
// 然后用 getBoundingClientRect 定位
```

---

## 3. 模型选择下拉面板

### 布局：2列网格

```html
<div class="model-drop">
  <div class="model-grid">
    <div class="model-card active">
      <div class="model-card-head">
        <span class="model-icon">⚡</span>
        <span class="model-name">快速</span>
        <span class="model-badge standard">标准版</span>
      </div>
      <p class="model-desc">速度快，适合日常创作</p>
      <div class="model-cost">
        <span class="cost-dot">●</span> 消耗 1 点
      </div>
    </div>
  </div>
</div>
```

```css
.model-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; padding: 12px; }
.model-card { border-radius: 14px; padding: 12px; border: 2px solid transparent;
  background: var(--qtd-bg-content); cursor: pointer; transition: all .15s; }
.model-card:hover { border-color: var(--qtd-border); }
.model-card.active { border-color: var(--qtd-lime); background: var(--qtd-bg-hover); }
.model-card.active .model-name { color: var(--qtd-lime-dark); }
```

### 版本徽章

```css
.model-badge { font-size: 10px; padding: 2px 6px; border-radius: 100px; font-weight: 500; }
.model-badge.standard { background: #E8F4FF; color: #1890FF; }
.model-badge.pro      { background: #FFF3E0; color: #FF6B35; }
.model-badge.ultra    { background: linear-gradient(135deg,#FFD700,#FF6B35); color:#fff; }
[data-theme="dark"] .model-badge.standard { background: rgba(24,144,255,.2); }
[data-theme="dark"] .model-badge.pro      { background: rgba(255,107,53,.2); }
```

---

## 4. 参数面板（比例 / 时长 / 运镜）

### Chip 组件

```css
.param-chip {
  padding: 5px 12px;
  border-radius: 100px;
  font-size: 12px;
  border: 1.5px solid var(--qtd-border);
  background: var(--qtd-bg-content);
  cursor: pointer;
  transition: all .15s;
  white-space: nowrap;
}
.param-chip:hover  { border-color: var(--qtd-lime); }
.param-chip.active { background: var(--qtd-lime); color: #333; border-color: var(--qtd-lime); font-weight: 500; }
[data-theme="dark"] .param-chip.active { color: #000; }
```

```html
<div class="param-group">
  <div class="param-label">视频比例</div>
  <div class="param-chips">
    <button class="param-chip active">16:9</button>
    <button class="param-chip">9:16</button>
    <button class="param-chip">1:1</button>
    <button class="param-chip">4:3</button>
  </div>
</div>
```

---

## 5. AI工具 Mega Dropdown（body 级定位）

顶部导航"AI工具"触发大型下拉面板，必须放在 body 末尾。

```js
const toolsDrop = document.getElementById('tools-drop');
document.body.appendChild(toolsDrop);

function openToolsDrop(triggerEl) {
  const rect = triggerEl.getBoundingClientRect();
  toolsDrop.style.cssText = `
    position:fixed;
    top:${rect.bottom + 8}px;
    left:${Math.max(0, rect.left - 100)}px;
    z-index:600;
    display:block;
  `;
}
```

```css
.tools-drop-inner {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 8px;
  padding: 16px;
  min-width: 480px;
}
.tool-item {
  display: flex; align-items: center; gap: 10px;
  padding: 10px 12px; border-radius: 12px; cursor: pointer; transition: background .15s;
}
.tool-item:hover { background: var(--qtd-bg-hover); }
.tool-item-icon { width: 36px; height: 36px; border-radius: 10px; flex-shrink: 0; }
.tool-item-name { font-size: 13px; font-weight: 500; }
.tool-item-desc { font-size: 11px; color: var(--qtd-text-tertiary); }
```

---

## 6. 图片选择器完整系统

图片选择器是视频生成页的核心交互，包含多个子系统。

### 6.1 Toolbar 添加按钮（永远显示）

```css
.cadd {
  width: 28px; height: 28px;
  border-radius: 50%;            /* 圆形 */
  border: 1.5px dashed var(--qtd-border);
  color: var(--qtd-text-tertiary);
  font-size: 17px;
  display: flex; align-items: center; justify-content: center;
  background: transparent; cursor: pointer; flex-shrink: 0;
  transition: all .15s;
}
.cadd:hover { border-color: var(--qtd-lime); color: var(--qtd-text-primary); }
/* ⚠️ 上传图片后不要隐藏此按钮！用户随时可以继续添加帧 */
```

### 6.2 Frame Strip（图帧预览条）

Frame strip 位于 prompt-box 内部最顶端，hint 行上方。

```html
<!-- prompt-box 内部结构，顺序不可颠倒 -->
<div class="prompt-box" id="prompt-box">
  <div id="frame-strip"></div>   <!-- ← 最顶部 -->
  <div class="ph">...</div>       <!-- ← hint 行 -->
  <textarea class="pi"></textarea>
  <div class="ptb">...</div>      <!-- ← 工具栏 -->
</div>
```

```css
#frame-strip {
  display: none; padding: 0 0 10px 0; gap: 6px;
  flex-wrap: wrap; align-items: flex-start;
  position: relative; z-index: 10;
}
#frame-strip.has-frames { display: flex; }
```

#### Frame 缩略图：40×40px

```css
.frame-thumb {
  width: 40px; height: 40px; border-radius: 10px;
  position: relative; cursor: pointer; flex-shrink: 0;
  overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,.1);
  transition: transform .15s, box-shadow .15s;
}
.frame-thumb:hover { transform: scale(1.05); }
.ft-label {
  position: absolute; bottom: 2px; left: 50%; transform: translateX(-50%);
  font-size: 9px; background: rgba(0,0,0,.55); color: #fff;
  padding: 1px 3px; border-radius: 3px; white-space: nowrap;
}
.ft-del {
  position: absolute; top: 1px; right: 1px;
  width: 14px; height: 14px; border-radius: 50%;
  background: rgba(0,0,0,.6); color: #fff; font-size: 8px;
  display: none; align-items: center; justify-content: center; cursor: pointer;
}
.frame-thumb:hover .ft-del { display: flex; }
```

#### Strip 内的 + 按钮：40×40px 方形（覆盖圆形）

```css
#frame-strip .cadd {
  width: 40px; height: 40px;
  border-radius: 10px;          /* 方形，非圆形 */
  background: var(--qtd-bg-content);
  border: 1.5px solid var(--qtd-border);
  font-size: 18px;
}
```

### 6.3 帧选择逻辑（最多2帧，超出替换首帧）

```js
let selectedFrames = [];

function addFrame(frameData) {
  if (selectedFrames.length < 2) {
    selectedFrames.push(frameData);
  } else {
    selectedFrames[0] = frameData; // 超过2帧替换首帧
  }
  updateFrameThumbs();
}

function updateFrameThumbs() {
  const strip = document.getElementById('frame-strip');
  strip.innerHTML = selectedFrames.map((f, i) => `
    <div class="frame-thumb" data-idx="${i}" onmouseenter="showFP(this,${i})">
      <div class="ft-bg" style="background:${f.bgStyle||'#eee'};position:absolute;inset:0;"></div>
      ${f.isFile ? `<img src="${f.url}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:9px;">` : ''}
      <div class="ft-label">${i===0?'首帧':'尾帧'}</div>
      <div class="ft-del" onclick="removeFrame(${i},event)">✕</div>
    </div>`).join('')
    + `<button class="cadd" onclick="togImgPick(event)">＋</button>`;

  strip.classList.toggle('has-frames', selectedFrames.length > 0);
  // ⚠️ 不要在这里隐藏 toolbar 的 cadd 按钮
}
```

### 6.4 悬浮预览卡（全局 mousemove 方案）

`mouseleave` 在快速移动时不可靠，用全局 mousemove 代替：

```js
let fpTimer = null;

function showFP(thumbEl, idx) {
  const card = document.getElementById('frame-preview-card');
  const rect = thumbEl.getBoundingClientRect();
  // 填充预览卡内容...
  card.style.left = (rect.right + 8) + 'px';
  card.style.top  = (rect.top - 10) + 'px';
  card.classList.add('show');
  clearTimeout(fpTimer);
}

function hideFP() {
  document.getElementById('frame-preview-card').classList.remove('show');
}

document.addEventListener('mousemove', function(e) {
  const card = document.getElementById('frame-preview-card');
  if (!card.classList.contains('show')) return;
  const thumbs = document.querySelectorAll('.frame-thumb');
  let over = false;
  thumbs.forEach(t => {
    const r = t.getBoundingClientRect();
    if (e.clientX >= r.left-6 && e.clientX <= r.right+6 &&
        e.clientY >= r.top-6  && e.clientY <= r.bottom+6) over = true;
  });
  if (!over) { clearTimeout(fpTimer); fpTimer = setTimeout(hideFP, 100); }
});
```

```css
.frame-preview-card {
  position: fixed; background: var(--qtd-bg-page); border-radius: 14px;
  box-shadow: var(--qtd-shadow-modal); padding: 10px; z-index: 500;
  min-width: 140px; pointer-events: none;
  opacity: 0; transform: scale(.95) translateY(4px);
  transition: opacity .15s, transform .15s;
}
.frame-preview-card.show { opacity: 1; transform: scale(1) translateY(0); }
```

### 6.5 「最近使用」分类布局

**横向滚动行**：上传按钮 + 搜索按钮 + 照片缩略图，全部128×128px，在同一行内水平滚动。
**推荐模板**在横向行下方，有筛选 tab 和 3列网格。

```html
<div class="ip-body">
  <div class="ip-sec-label">最近使用</div>
  <div class="ip-recent-row">
    <div class="ip-action-item" onclick="triggerFileInput()">
      <span class="ip-action-ico">＋</span><span class="ip-action-lbl">上传图片</span>
    </div>
    <div class="ip-action-item">
      <span class="ip-action-ico">🔍</span><span class="ip-action-lbl">搜索图片</span>
    </div>
    <!-- 图片缩略图，128×128px，与按钮同行 -->
    <div class="ip-recent-img selected">
      <img src="..." alt=""><div class="ip-img-check">✓</div>
    </div>
  </div>
  <div class="ip-tmpl-hd">推荐模板</div>
  <div class="ip-tabs">
    <button class="ip-tab active">全部</button>
    <button class="ip-tab">风景</button>
    <button class="ip-tab">人像</button>
  </div>
  <div class="ip-tmpl-grid"><!-- 3列模板卡片 --></div>
</div>
```

```css
.ip-recent-row {
  display: flex; gap: 8px; overflow-x: auto; padding-bottom: 6px;
  scrollbar-width: none; align-items: flex-start;
}
.ip-recent-row::-webkit-scrollbar { display: none; }

/* 128×128px 方块按钮（上传/搜索） */
.ip-action-item {
  flex-shrink: 0; width: 128px; height: 128px; border-radius: 14px;
  border: 1.5px dashed var(--qtd-border); background: var(--qtd-bg-content);
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 8px; cursor: pointer; transition: all .15s;
}
.ip-action-item:hover { border-color: var(--qtd-lime); background: var(--qtd-bg-hover); }

/* 图片缩略图：与按钮同宽同高 128px */
.ip-recent-img {
  flex-shrink: 0; width: 128px; height: 128px; border-radius: 12px;
  overflow: hidden; cursor: pointer; position: relative;
  border: 2.5px solid transparent; transition: border-color .13s, transform .13s;
}
.ip-recent-img:hover { transform: scale(1.02); }
.ip-recent-img.selected { border-color: var(--qtd-lime); }
.ip-recent-img img { width: 100%; height: 100%; object-fit: cover; }
.ip-img-check {
  position: absolute; bottom: 5px; right: 5px;
  width: 18px; height: 18px; border-radius: 50%;
  background: var(--qtd-lime); color: #333; font-size: 10px;
  font-weight: bold; display: flex; align-items: center; justify-content: center;
}

/* 推荐模板 */
.ip-tmpl-hd { font-size: 12px; color: var(--qtd-text-secondary); font-weight: 500; margin: 14px 0 8px; }
.ip-tabs { display: flex; gap: 4px; flex-wrap: wrap; margin-bottom: 10px; }
.ip-tab {
  padding: 4px 10px; border-radius: 100px; font-size: 11px;
  border: 1px solid var(--qtd-border); background: transparent;
  color: var(--qtd-text-secondary); cursor: pointer; transition: all .13s;
}
.ip-tab.active { background: var(--qtd-lime); color: #333; border-color: var(--qtd-lime); font-weight: 500; }
.ip-tmpl-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 7px; }
.ip-tmpl-card { border-radius: 10px; overflow: hidden; cursor: pointer; aspect-ratio: 16/9; transition: transform .13s; }
.ip-tmpl-card:hover { transform: scale(1.03); }
```

---

## 7. 关闭下拉的标准处理

```js
document.addEventListener('click', function(e) {
  document.querySelectorAll('.floating-drop').forEach(drop => {
    if (drop.style.display !== 'none' && !drop.contains(e.target)) {
      const trigger = document.getElementById(drop.dataset.triggerId);
      if (!trigger || !trigger.contains(e.target)) {
        drop.style.display = 'none';
      }
    }
  });
});

document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    document.querySelectorAll('.floating-drop').forEach(d => d.style.display = 'none');
  }
});
```

---

## 8. 工具栏结构

```html
<div class="ptb">
  <div class="tbl">
    <button class="cadd" id="cadd-btn" onclick="togImgPick(event)">＋</button>
    <button class="tb-chip" onclick="togModelDrop(event)">⚡ 快速 ▾</button>
    <button class="tb-chip" onclick="togParamDrop(event,'ratio')">▣ 16:9 ▾</button>
    <button class="tb-chip" onclick="togParamDrop(event,'dur')">⏱ 5s ▾</button>
  </div>
  <div class="tbr">
    <span class="cost-badge">消耗1点</span>
    <button class="qtd-btn-create">✦ 创作</button>
  </div>
</div>
```

```css
.tb-chip {
  display: flex; align-items: center; gap: 4px;
  padding: 4px 10px; border-radius: 100px; font-size: 12px;
  border: 1px solid var(--qtd-border); background: transparent;
  color: var(--qtd-text-secondary); cursor: pointer; transition: all .15s;
}
.tb-chip:hover { border-color: var(--qtd-lime); color: var(--qtd-text-primary); }
.ptb { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding-top: 10px; }
.tbl { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.tbr { display: flex; align-items: center; gap: 8px; flex-shrink: 0; }
.cost-badge { font-size: 11px; padding: 3px 8px; border-radius: 100px; background: var(--qtd-bg-hover); color: var(--qtd-text-tertiary); }
```

---

## 9. 常见陷阱 & 避免方法

| 陷阱 | 正确做法 |
|------|---------|
| 把 mega-dropdown 放在 header 内 | 移至 body 末尾，用 `getBoundingClientRect` 定位 |
| 用 `mouseleave` 控制预览卡隐藏 | 改用全局 `mousemove` + ±6px 容差检测 |
| 上传图片后隐藏 toolbar 的 "+" 按钮 | 永远保持可见，用户随时可以添加帧 |
| frame-strip 的 "+" 用圆形 `.cadd` | 用 `#frame-strip .cadd` 覆盖为 40px 方形 |
| 图片选择器"最近使用"用网格布局 | 用水平滚动行（上传+搜索+图片全部128px同行） |
| 浮动面板用 `position:absolute` | 用 `position:fixed` + JS 动态计算位置 |
| 颜色硬编码 | 始终使用 `var(--qtd-xxx)` 变量 |
