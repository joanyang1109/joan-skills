# 千图AI 组件库（ai.58pic.com）

> **所有 class 名、HTML 结构均来自 `demo-source/ai-site/` 真实源文件。**
> 直接读取并复制这些文件，不要根据此文档重建。
> 此文档仅作为快速索引，帮助定位到正确的源文件。

## 目录

1. [顶部导航栏](#顶部导航栏)
2. [主题切换开关](#主题切换开关)
3. [创作输入框（create-box）](#创作输入框)
4. [AI工具分类卡片行](#ai工具分类卡片行)
5. [社区标题标签行](#社区标题标签行)
6. [社区工具栏（搜索+排序）](#社区工具栏)
7. [瀑布流占位卡片](#瀑布流占位卡片)
8. [首屏标题区](#首屏标题区)
9. [右侧反馈+回顶](#右侧反馈回顶)

---

## 顶部导航栏

**源文件**：`demo-source/ai-site/modules/app-header.html` + `app-header.css`

**核心 class 名**：

```
.qtd-header-container.demo-static-header   → header 容器，fixed 顶部，高 80px
  .qtd-head-left-info                       → 左侧区域（logo + 导航项）
    .logo-box-container > .logo-box
      a.qtd-head-logo                       → Logo 图片链接
      a.qtd-head-jump-a                     → "主站" 跳转链接
    .ai-tool-header-btn                     → 顶部导航项（AI模板库/AI模型/AI工具），含下拉箭头
  .qtd-head-right-info                      → 右侧区域
    .right-info-item.user-info
      .demo-theme-toggle                    → 主题切换
      .vip-header-limit                     → 资产/点数显示
      a.func-info-item-link                 → 用户信息区（头像+昵称+VIP标识）
        .user-info-text-box
        .user-photo > img.user-face
```

**关键 CSS**：
```css
/* 顶栏背景跟随主题 */
.qtd-header-container.demo-static-header {
  background: var(--qtd-ai-drak-bg-1);  /* 深色=#000, 浅色=#fff */
  height: 80px;
  z-index: 2100;
}
/* 导航文字 hover = 荧光绿 */
.ai-tool-header-btn:hover { color: var(--qtd-ai-text-color-hover-1); }
```

---

## 主题切换开关

**源文件**：`demo-source/ai-site/modules/app-header.html` + `app-header.css` + `theme-toggle.js`

```html
<button class="demo-theme-toggle" id="demo-theme-toggle" role="switch" aria-checked="false">
  <span class="demo-theme-toggle__label demo-theme-toggle__label--dark">深色</span>
  <span class="demo-theme-toggle__track" aria-hidden="true">
    <span class="demo-theme-toggle__thumb"></span>
  </span>
  <span class="demo-theme-toggle__label demo-theme-toggle__label--light">浅色</span>
</button>
```

切换逻辑：给 `<html>` 添加/移除 `qtd-ai-light-mode` class，同时给按钮加 `demo-theme-toggle--light`。
完整 JS 见 `demo-source/ai-site/modules/theme-toggle.js`。

---

## 创作输入框

**源文件**：`demo-source/ai-site/modules/create-box-newv2.html` + `create-box-newv2.css`

```
.demo-create-box-wrap > .demo-create-box-mount
  .qtdCreateTaskBox.demo-create-box--embed
    .create-task-main.active
      .top-box-wrap                         → 图片参考区
        .choose-style-box                   → 参考图槽（已选图）
          img + .mask-box > i.icon-Close    → 悬停删除按钮
        .choose-style-box > .upload-img-box → 上传槽（空态，点击上传）
      .bottom-box-wrap
        .create-textarea-model-box
          .create-textarea-box
            div[contenteditable].create-textarea-input-box   → 文字输入区
            .placeholder-box                → 占位文字
          .textarea-box-bottom              → 底部选项工具栏
            .qtd-model-list-container-wrap.style-box         → 风格选择
            .qtd-model-list-container-wrap.mode-box          → 模式（智能设计·Pro）
            .qtd-model-list-container-wrap.model-box         → 模型（Agent）
        .create-submit-box.active           → 创作按钮
```

---

## AI工具分类卡片行

**源文件**：`demo-source/ai-site/pages/home/modules/classify-ai-tools.html` + `classify-ai-tools.css`

```html
<div class="demo-classify-box">
  <!-- 普通工具卡（前3项） -->
  <article class="demo-classify-item">
    <div class="demo-classify-item__img" style="background: linear-gradient(...)"></div>
    <div class="demo-classify-item__body">
      <div class="demo-classify-item__title">文生图</div>
      <p class="demo-classify-item__desc">一句话生成高质量画面</p>
    </div>
  </article>

  <!-- 第4项：悬停展开更多（纯 CSS hover） -->
  <div class="demo-classify-more">
    <article class="demo-classify-item demo-classify-item--fourth">
      <div class="demo-classify-item__img"></div>
      <div class="demo-classify-item__body">
        <div class="demo-classify-item__head">
          <span class="demo-classify-item__title">更多工具</span>
          <span class="demo-classify-item__chev">▼</span>
        </div>
        <p class="demo-classify-item__desc">悬停展开列表</p>
      </div>
    </article>
    <div class="demo-classify-more__panel">
      <!-- 展开后的更多工具卡 -->
    </div>
  </div>
</div>
```

---

## 社区标题标签行

**源文件**：`demo-source/ai-site/pages/home/modules/community-header.html` + `community-header.css` + `community-header.js`

```html
<h2 class="recommendTplListTitle demo-recommend-title">AI社区：探索更多创意表达</h2>
<div class="content-list-tag-box-wrap demo-content-list-tag-box-wrap">
  <div class="content-list-tag-box demo-content-list-tag-box" data-demo-tag-box>
    <button class="floor-title demo-floor-title"><span>◇</span> AI工具</button>
    <button class="floor-title demo-floor-title is-active" data-demo-tag>推荐</button>
    <button class="floor-title demo-floor-title" data-demo-tag>插画</button>
    <button class="floor-title demo-floor-title" data-demo-tag>摄影</button>
    <div class="floor-title-after demo-floor-title-after" data-demo-tag-after></div>
  </div>
</div>
```

激活态：`floor-title.is-active`（荧光绿下划线，由 `community-header.js` 动态更新位置）

---

## 社区工具栏

**源文件**：`demo-source/ai-site/pages/home/modules/community-toolbar.html` + `community-toolbar.css`

```html
<div class="content-list-sort-box demo-content-list-sort-box">
  <input type="search" class="demo-toolbar-input" placeholder="输入关键词按回车搜索">
  <div class="contentListSortBox demo-content-list-sort-box-inner">
    <div class="content-list-choose-item demo-sort-current">推荐 <span>↕</span></div>
    <div class="content-list-more-box demo-sort-more" role="menu">
      <button class="floor-title demo-sort-option is-active">推荐</button>
      <button class="floor-title demo-sort-option">最新</button>
    </div>
  </div>
</div>
```

---

## 瀑布流占位卡片

**源文件**：`demo-source/ai-site/modules/community-masonry.html` + `community-masonry.css`

```html
<div class="content-floor-box demo-content-floor-box demo-community-masonry-wrap">
  <div class="floor-col-item demo-community-masonry">
    <article class="demo-masonry-card">
      <div class="demo-masonry-card__img" style="height: 180px; background: ..."></div>
      <div class="demo-masonry-card__meta">
        <p class="demo-masonry-card__title">示例作品 A</p>
      </div>
    </article>
    <!-- 更多高度不同的卡片... -->
  </div>
</div>
```

布局：CSS `column-count` 多列（线上为 masonic）。每张卡片 `height` 不同模拟瀑布流。

---

## 首屏标题区

**源文件**：`demo-source/ai-site/pages/home/modules/hero-titles.html` + `hero-titles.css`

```html
<p class="demo-hero__title">
  欢迎使用<em>千图AI <span>：还原你想象的画面</span></em>
</p>
<p class="demo-hero__subtitle">实时更新全球模型 创意一键同款</p>
```

---

## 右侧反馈+回顶

**源文件**：`demo-source/ai-site/pages/home/modules/feedback-aside.html` + `feedback-aside.css` + `feedback-aside.js`

`feedback-aside.js` 还负责：顶栏滚动遮罩、`?loading=1` 加载态、`?admin=1` 管理条显示、回顶逻辑。

---

## 完整首页组装（参考 demo-source/ai-site/pages/home/index.html）

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <link rel="stylesheet" href="https://at.alicdn.com/t/c/font_4071226_yuk7h8umu1.css">
  <!-- 2. 主题变量（内联 theme.css 内容 或相对路径引入） -->
  <!-- 3. 各模块 CSS -->
  <link rel="stylesheet" href="../../modules/app-header.css">
  <link rel="stylesheet" href="../../modules/page-shell.css">
  <link rel="stylesheet" href="../../modules/create-box-newv2.css">
  <link rel="stylesheet" href="modules/hero-titles.css">
  <link rel="stylesheet" href="modules/classify-ai-tools.css">
  <link rel="stylesheet" href="../../modules/community-masonry.css">
  <link rel="stylesheet" href="modules/community-header.css">
  <link rel="stylesheet" href="modules/community-toolbar.css">
  <link rel="stylesheet" href="modules/feedback-aside.css">
</head>
<body>
  [app-header.html]     [page-shell.html]
  [hero-titles.html]    [create-box-newv2.html]
  [classify-ai-tools.html]
  [community-header.html]   [community-toolbar.html]
  [community-masonry.html]  [feedback-aside.html]

  <script>[theme-toggle.js]</script>
  <script>[community-header.js]</script>
  <script>[feedback-aside.js]</script>
</body>
</html>
```

> 完整可运行版本：直接打开 `demo-source/ai-site/pages/home/index.html`
