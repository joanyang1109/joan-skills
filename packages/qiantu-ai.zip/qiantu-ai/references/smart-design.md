# 千图智能设计 / 无限画布 (canvas.58pic.com)

> **权威来源**：`demo-source/canvas-editor/`（前端参考页：`canvas.58pic.com/zh-CN/canvas/127`）
> 此产品线为在线设计编辑器，布局与 AI站/主站完全不同：全屏画布 + 悬浮工具条 + 深色 AI 输入条。

## 设计特征

- **底色**：浅灰点阵背景（`#ebebeb` + `#c0c0c0` 点网格），模拟设计工具工作区
- **控件风格**：圆角白底浮层（box-shadow，非 border），对齐 Figma / 即梦风格
- **品牌色**：`#c8ff00`（`--qtd-accent-lime`），荧光绿仅用于选区框/主按钮
- **AI 输入条**：深色（`rgba(31,31,31,0.92)`）圆角长条，固定在底部居中
- **无侧边栏**：工具全部在顶部/底部悬浮条中，画布全屏

## CSS 变量（来自 demo-source/canvas-editor/theme.css）

```css
/* 页面基底 */
--qtd-page-bg: #ebebeb;
--qtd-dot-grid-color: #c0c0c0;
--qtd-dot-grid-size: 22px;

/* 表面与文字 */
--qtd-surface: #ffffff;
--qtd-text-primary: #1a1a1a;
--qtd-text-secondary: #444444;
--qtd-text-tertiary: #555555;
--qtd-text-muted: #888888;
--qtd-border-subtle: #e0e0e0;
--qtd-border-light: #e8e8e8;

/* 品牌强调 */
--qtd-accent-lime: #c8ff00;         /* ★ 选区/主按钮 */
--qtd-accent-lime-hover: #d4ff1a;
--qtd-accent-olive: #8ab800;

/* AI 深色输入条 */
--qtd-ai-dark-bg: rgba(31, 31, 31, 0.92);
--qtd-ai-dark-border: rgba(255, 255, 255, 0.08);
--qtd-ai-chip-bg: rgba(255, 255, 255, 0.1);
--qtd-ai-placeholder: rgba(255, 255, 255, 0.45);

/* 阴影 */
--qtd-shadow-float:
  0 4px 6px rgba(0,0,0,0.04),
  0 10px 20px rgba(0,0,0,0.08),
  0 20px 40px rgba(0,0,0,0.06);
--qtd-shadow-float-hover:
  0 4px 8px rgba(0,0,0,0.06),
  0 12px 24px rgba(0,0,0,0.1),
  0 24px 48px rgba(0,0,0,0.08);

/* 圆角 */
--qtd-radius-pill: 999px;
--qtd-radius-card: 4px;
--qtd-radius-panel: 20px;

/* 画布卡片尺寸（可调整） */
--qtd-canvas-width: min(360px, 86vw);
--qtd-canvas-aspect: 1664 / 2496;
--qtd-canvas-height: calc(var(--qtd-canvas-width) / (1664 / 2496));

/* 层级 */
--qtd-z-canvas: 1;
--qtd-z-chrome: 100;
--qtd-z-ai-bar: 1000;

/* 顶栏控件参数（对齐 Header.module.scss） */
--qtd-canvas-chrome-radius: 32px;
--qtd-canvas-chrome-padding: 8px;
--qtd-canvas-chrome-gap: 12px;
--qtd-canvas-chrome-shadow: 0 2px 8px 0 rgba(0,0,0,0.25);
--qtd-canvas-chrome-edge: 24px;
--qtd-canvas-toolbar-btn-size: 32px;
--qtd-canvas-toolbar-icon-size: 20px;
```

## 工具条基础类（直接来自 theme.css）

```css
/* 顶栏白底浮层条 — 共用 .qtd-canvas-toolbar-bar */
.qtd-canvas-toolbar-bar {
  display: flex; align-items: center;
  gap: var(--qtd-canvas-chrome-gap);
  padding: var(--qtd-canvas-chrome-padding);
  background: var(--new-bg-1, #fff);
  border-radius: var(--qtd-canvas-chrome-radius);
  box-shadow: var(--qtd-canvas-chrome-shadow);
}

/* 居中工具栏（上传/文字/形状/画笔/素材库） */
.qtd-canvas-toolbar-bar--center {
  position: fixed; top: 16px;
  left: 50%; transform: translateX(-50%);
}

/* 右侧操作区（撤销/重做/下载） */
.qtd-canvas-toolbar-bar--right {
  position: fixed; top: 16px;
  right: var(--qtd-canvas-chrome-edge);
}

/* 圆形图标按钮 */
.qtd-canvas-toolbar-btn {
  width: 32px; height: 32px; padding: 0; border: none;
  background: transparent; border-radius: 50%;
  display: inline-flex; align-items: center; justify-content: center;
  cursor: pointer; transition: background 0.2s;
}
.qtd-canvas-toolbar-btn:hover { background: var(--new-grey-3, #f5f5f5); }
.qtd-canvas-toolbar-btn svg { width: 20px; height: 20px; }

/* 下载按钮（带文字） */
.qtd-canvas-toolbar-download {
  display: inline-flex; align-items: center; gap: 6px;
  min-height: 32px; padding: 0 12px; border: none;
  background: transparent; border-radius: var(--qtd-canvas-chrome-radius);
  font-size: 14px; font-weight: 500; cursor: pointer;
}
.qtd-canvas-toolbar-download:hover { background: var(--new-grey-3, #f5f5f5); }

/* 分割线 */
.qtd-canvas-toolbar-divider { width: 1px; height: 16px; background: var(--qtd-fun-color-4, #e8e8e8); }
```

## 模块文件清单（demo-source/canvas-editor/modules/）

| 文件 | 内容 |
|------|------|
| `mod-01-background.*` | 全屏点阵背景（给 body 加 `.qtd-demo-page.qtd-dot-bg`） |
| `mod-02-canvas-stage.*` | 居中白色画布卡片（含占位图/标题/说明） |
| `mod-03-top-left.*` | 左上角圆形返回按钮 |
| `mod-04-top-center-toolbar.*` | 顶部居中工具条（上传/文字/形状/画笔/素材库） |
| `mod-05-top-right-actions.*` | 右上撤销/重做/下载 |
| `mod-06-right-feedback.*` | 右侧竖向反馈胶囊 |
| `mod-07-bottom-zoom.*` | 左下缩放控件（−/百分比/+） |
| `mod-08-bottom-center-pencil.*` | 底部居中画笔 FAB |
| `mod-09-bottom-right-views.*` | 右下视图切换（图层/网格/布局） |
| `mod-10-ai-prompt-bar.*` | **底部 AI 输入条**（深色圆角长条 + Agent标签 + 创作按钮） |
| `mod-11-download-popover.*` | 下载浮层（格式/倍率/字体授权，`~340px fixed`） |
| `mod-12-text-toolbar.*` | 悬浮工具栏（文字工具栏 + 图片工具栏，互斥显示） |

## 关键 HTML 片段（复制即用）

### 底部 AI 输入条（`mod-10`）

```html
<div class="qtd-ai-prompt-wrap">
  <div class="qtd-ai-prompt" role="group" aria-label="AI 创作">
    <div class="qtd-ai-prompt__main">
      <div class="qtd-ai-prompt__placeholder">请文字输入你想实现的创意灵感～</div>
      <div class="qtd-ai-prompt__row">
        <span class="qtd-ai-chip" title="Agent 模式">
          <span class="qtd-ai-chip__dot" aria-hidden="true"></span>
          Agent
        </span>
      </div>
    </div>
    <div class="qtd-ai-prompt__actions">
      <button type="button" class="qtd-ai-submit" tabindex="-1">创作</button>
      <span class="qtd-ai-free-tag">免费</span>
    </div>
  </div>
</div>
```

### 中央画布卡片（`mod-02`）

```html
<div class="qtd-canvas-stage">
  <div class="qtd-canvas-card" role="presentation">
    <div class="qtd-canvas-sheet">
      <img class="qtd-canvas-sheet__img qtd-demo-image-target"
           src="[图片URL]" alt="" width="320" height="480">
      <h2 class="qtd-canvas-sheet__title qtd-demo-text-target">设计标题</h2>
      <p class="qtd-canvas-sheet__desc qtd-demo-text-target">副标题说明文案</p>
    </div>
  </div>
</div>
```

> `qtd-demo-image-target` / `qtd-demo-text-target` 是 `mod-12` 悬浮工具栏的触发标记。

### 顶部居中工具条（`mod-04`）

```html
<div class="qtd-canvas-toolbar-bar qtd-canvas-toolbar-bar--center" role="toolbar" aria-label="编辑工具">
  <button class="qtd-canvas-toolbar-btn" aria-label="上传"><!-- Upload SVG --></button>
  <button class="qtd-canvas-toolbar-btn" aria-label="文字"><!-- Text SVG --></button>
  <button class="qtd-canvas-toolbar-btn" aria-label="形状"><!-- Shape SVG --></button>
  <button class="qtd-canvas-toolbar-btn" aria-label="画笔"><!-- Brush SVG --></button>
  <div class="qtd-canvas-toolbar-divider" aria-hidden="true"></div>
  <button class="qtd-canvas-toolbar-btn" aria-label="素材库"><!-- Folder SVG --></button>
</div>
```

## 交互脚本

| 文件 | 说明 |
|------|------|
| `mod-11-download-popover.js` | 点击下载按钮展开/收起浮层；ESC / 空白区关闭 |
| `mod-12-text-toolbar.js` | 文字栏/图片栏互斥显示；点目标元素定位，再点关闭 |

## 与其他产品线的主题变量差异

| 变量 | AI站 | 智能设计 | 说明 |
|------|------|----------|------|
| 背景 | `--new-bg-1` (#141414 深色) | `--qtd-page-bg` (#ebebeb) | 编辑器是浅灰底 |
| 品牌绿 | `--qtd-ai-text-color-hover-1` (#d8ff00) | `--qtd-accent-lime` (#c8ff00) | 数值略不同 |
| 主文字 | `--new-text-1` | `--qtd-text-primary` (#1a1a1a) | 变量名不同 |
| 阴影 | `--new-shadow-1` | `--qtd-shadow-float` | 样式不同 |
