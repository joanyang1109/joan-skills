# 千图AI 设计 Tokens（ai.58pic.com）

> **权威来源**：`demo-source/ai-site/theme.css`（由前端从 `styles/newTheme.scss` + `styles/theme.scss` 直接转写）。
> 本文件是该 theme.css 的使用说明。**生成 demo 时请直接引用 theme.css 原文**，不要重建 CSS 变量。

## 主题切换机制

```html
<!-- 深色（默认） -->
<html>

<!-- 浅色模式 -->
<html class="qtd-ai-light-mode">
```

**不是** `data-theme="dark"`。切换函数（来自 `demo-source/ai-site/modules/theme-toggle.js`）：

```js
// theme-toggle.js 实际逻辑
const html = document.documentElement;
const LIGHT_CLASS = 'qtd-ai-light-mode';
function toggleTheme(isLight) {
  html.classList.toggle(LIGHT_CLASS, isLight);
  localStorage.setItem('qtd-theme', isLight ? 'light' : 'dark');
}
// 初始化
const saved = localStorage.getItem('qtd-theme');
if (saved === 'light') html.classList.add(LIGHT_CLASS);
```

## CSS 变量速查（来自 demo-source/ai-site/theme.css）

### 灰阶系统（深色模式下的值）

| 变量 | 深色值 | 浅色值（`.qtd-ai-light-mode`） |
|------|--------|-------------------------------|
| `--new-grey-1` | `#000000` | `#ffffff` |
| `--new-grey-2` | `#141414` | `#fafafa` |
| `--new-grey-3` | `#1f1f1f` | `#f5f5f5` |
| `--new-grey-4` | `#333333` | `#e8e8e8` |
| `--new-grey-5` | `#4d4d4d` | `#d8d8d8` |
| `--new-grey-6` | `#d8d8d8` | `#333333` |
| `--new-grey-7` | `#ffffff` | `#141414` |

### 文字色系

| 变量 | 深色值 | 浅色值 |
|------|--------|--------|
| `--new-text-1` | `#ffffff` | `#333333` |
| `--new-text-2` | `#fafafa` | `#333333` |
| `--new-text-3` | `#999999` | `#4d4d4d` |
| `--new-text-4` | `#666666` | `#666666` |
| `--new-text-5` | `#4d4d4d` | `#999999` |
| `--new-text-8` | `#141414` | `#ffffff` |
| `--new-bg-1` | `#141414` | `#ffffff` |
| `--new-bg-2` | `#1f1f1f` | `#fafafa` |
| `--new-bg-3` | `#1f1f1f` | `#f5f5f5` |

### 背景色系（`--qtd-ai-drak-bg-*`）

| 变量 | 深色值 | 浅色值 |
|------|--------|--------|
| `--qtd-ai-drak-bg-1` | `#000` | `#fff` |
| `--qtd-ai-drak-bg-4` | `rgba(0,0,0,0.7)` | `rgba(255,255,255,0.7)` |
| `--qtd-ai-drak-bg-6` | `rgba(0,0,0,0.5)` | `rgba(255,255,255,0.5)` |
| `--qtd-ai-drak-bg-11` | `rgba(0,0,0,0)` | `rgba(255,255,255,0)` |

### 品牌色 / 交互色

| 变量 | 值 | 说明 |
|------|-----|------|
| `--qtd-ai-text-color-hover-1` | `#d8ff00`（深色）/ `#141414`（浅色） | ★ 荧光绿高亮，品牌核心色 |
| `--qtd-ai-light-color-6` | `#d8ff00` | 荧光绿（始终为绿，不随主题变） |
| `--qtd-ai-text-color-1` | `#fff`（深色）/ `#141414`（浅色） | 主文字 |
| `--qtd-ai-text-color-2` | `#999999`（深色）/ `#333`（浅色） | 次要文字 |
| `--qtd-ai-text-color-3` | `#666666`（深色）/ `#4d4d4d`（浅色） | 辅助文字 |

### left-color 系（用于左侧导航、createBox 等区域）

| 变量 | 深色值 | 浅色值（未指定则同深色） |
|------|--------|--------------------------|
| `--left-color-1` | `#141414` | `#ffffff` |
| `--left-color-2` | `#1f1f1f` | — |
| `--left-color-3` | `#333333` | `#f5f5f5` |
| `--left-color-4` | `#4d4d4d` | `#e8e8e8` |
| `--left-color-5` | `#666666` | — |
| `--left-color-6` | `#999999` | — |
| `--left-color-7` | `#fafafa` | — |
| `--left-color-8` | `#ffffff` | — |
| `--left-color-9` | `#e8e8e8` | `#e8e8e8` |
| `--left-color-10` | `#333333` | `#e8e8e8` |
| `--left-text-color-1` | `#ffffff` | `#333333` |
| `--left-text-color-2` | `#999999` | `#666666` |
| `--left-text-color-3` | `#d8d8d8` | `#666666` |

### 其他常用

```css
--qtd-transition-cubic-1: cubic-bezier(0.645, 0.045, 0.355, 1);
--qtd-ai-drak-func-color-1: #141414;    /* 深色时 */
--qtd-ai-drak-func-color-4: rgba(255, 255, 255, 0.25);

/* z-index（仅 demo 用，线上取 component 自身层级） */
--demo-z-top-mask: 11;
--demo-z-create: 10;
--demo-z-feedback: 2000;
--demo-z-admin: 9999;
```

## body 基础样式

```css
/* 来自 theme.css */
body {
  font-family: 'PingFang SC', -apple-system, BlinkMacSystemFont, sans-serif;
  background: var(--qtd-ai-drak-bg-1);
  color: var(--new-text-1);
  transition: background-color 0.25s var(--qtd-transition-cubic-1),
              color 0.25s var(--qtd-transition-cubic-1);
}
html { color-scheme: dark; }
html.qtd-ai-light-mode { color-scheme: light; }
```

## demo 中的标准引用写法

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>千图AI - [页面]</title>
  <!-- 1. 引入 iconfont（需联网） -->
  <link rel="stylesheet" href="https://at.alicdn.com/t/c/font_4071226_yuk7h8umu1.css">
  <!-- 2. 引入主题变量（本地路径 or 内联 theme.css 内容） -->
  <link rel="stylesheet" href="../../theme.css">
  <!-- 3. 引入模块样式 -->
  <link rel="stylesheet" href="../../modules/app-header.css">
</head>
<body>
  <!-- 4. 复制对应模块的 .html 片段 -->
</body>
</html>
```

## 与旧文档的差异（迁移提示）

| 旧写法（已废弃） | 正确写法 |
|------------------|----------|
| `data-theme="dark"` | `class=""` (默认深色) |
| `data-theme="light"` | `class="qtd-ai-light-mode"` |
| `--qtd-bg-primary` | `--new-bg-1` / `--qtd-ai-drak-bg-1` |
| `--qtd-text-primary` | `--new-text-1` |
| `--qtd-brand-green` | `--qtd-ai-text-color-hover-1` (#d8ff00) |
| `rgb(178, 255, 0)` | `#d8ff00`（实测值） |
| `.qtd-btn-primary` | 见 demo-source/ai-site/modules/ 对应组件 |
| `.qtd-sidebar` | 见 demo-source/ai-site/modules/app-header.html |
