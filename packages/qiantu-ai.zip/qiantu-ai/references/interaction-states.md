# 交互状态机规范（三站通用）

> 核心原则：**直接查 stylesheet 伪类规则，而非 getComputedStyle**（只能拿到默认态）。
> 所有 hover/active/focus 数据均通过 `document.styleSheets` 提取自真实样式表。

## 目录

1. [提取伪类规则的标准方法](#一提取伪类规则的标准方法)
2. [千图AI 交互状态](#二千图aiai58piccom交互状态)
3. [千图主站 交互状态](#三千图主站58piccom交互状态)
4. [千图企业站 交互状态](#四千图企业站qiye58piccom交互状态)
5. [三站共用：输入框焦点态颜色对照](#五三站共用输入框焦点态颜色对照)
6. [Ant Design 组件状态（千图AI 专用）](#六ant-design-组件状态千图ai-专用)
7. [CSS 变量 — 三站交互色速查](#七css-变量--三站交互色速查)

---

## 一、提取伪类规则的标准方法

在生成 demo 前，先用此代码提取目标组件的所有交互态规则：

```javascript
// 提取指定关键词相关的 :hover / :active / :focus 规则
function extractInteractionRules(keywords = []) {
  const rules = [];
  [...document.styleSheets].forEach(ss => {
    try {
      [...ss.cssRules || []].forEach(rule => {
        if (!rule.selectorText) return;
        const sel = rule.selectorText;
        const isPseudo = sel.includes(':hover') || sel.includes(':active') || sel.includes(':focus');
        if (!isPseudo) return;
        const matchesKeyword = keywords.length === 0 ||
          keywords.some(kw => sel.toLowerCase().includes(kw.toLowerCase()));
        if (matchesKeyword) {
          rules.push({ selector: sel, css: rule.style.cssText });
        }
      });
    } catch(e) {} // 跨域 stylesheet 会报错，忽略
  });
  return rules;
}

// 示例用法
extractInteractionRules(['productCard', 'btn', 'tab', 'publicItem', 'Button']);
```

---

## 二、千图AI（ai.58pic.com）交互状态

### 按钮（`.productCardContentButton`）

| 状态 | 背景色 | 文字色 | 边框 | 其他 |
|------|--------|--------|------|------|
| default（白框款） | `#ffffff` | `rgb(51,51,51)` | `1px solid rgb(51,51,51)` | — |
| hover（白框款） | `rgb(20,20,20)` | `#ffffff` | `rgb(20,20,20)` | — |
| default（黑底推荐款） | `rgb(20,20,20)` | `#ffffff` | `1px solid rgb(51,51,51)` | — |
| hover（黑底推荐款） | `rgb(178,255,0)` | `rgb(20,20,20)` | `rgb(178,255,0)` | — |
| disabled（当前计划） | `rgb(232,232,232)` | `rgb(51,51,51)` | `rgb(232,232,232)` | `cursor:not-allowed` |

```css
/* 实现 */
.productCardContentButton { transition: all 0.15s ease; }

.productCardContentButton:not(.currentPlan):hover {
  background: rgb(20, 20, 20);
  color: #ffffff;
  border-color: rgb(20, 20, 20);
}

.productCard.active .productCardContentButton:hover {
  background: rgb(178, 255, 0);
  color: rgb(20, 20, 20);
  border-color: rgb(178, 255, 0);
}
```

### Tab 切换（`.publicItem`）

| 状态 | 背景 | 文字色 | 阴影 |
|------|------|--------|------|
| default | transparent | `var(--qtd-text-secondary, #666)` | none |
| hover | `rgba(255,255,255,0.5)` | `var(--qtd-text-primary, #141414)` | none |
| active（选中） | `#ffffff` | `rgb(51,51,51)` | `0 2px 8px rgba(0,0,0,0.12)` |

```css
.publicItem { transition: all 0.2s ease; cursor: pointer; }
.publicItem:hover:not(.active) { background: rgba(255,255,255,0.5); }
.publicItem.active { background: #fff; color: rgb(51,51,51); font-weight: 600;
                     box-shadow: 0 2px 8px rgba(0,0,0,0.12); }
```

### 定价卡片（`.productCard`）

| 状态 | 边框 | 阴影 | 变换 |
|------|------|------|------|
| default | `2px solid transparent` | `0 2px 8px rgba(0,0,0,0.1)` | — |
| hover | `2px solid rgba(178,255,0,0.4)` | `0 8px 24px rgba(0,0,0,0.15)` | `translateY(-2px)` |
| active（推荐） | `2px solid rgb(178,255,0)` | `0 4px 16px rgba(178,255,0,0.6)` | — |

```css
.productCard { transition: all 0.2s ease; }
.productCard:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,0.15); }
.productCard.active { border-color: rgb(178,255,0); box-shadow: 0 4px 16px rgba(178,255,0,0.6); }
```

### 下拉菜单（Ant Design Dropdown）

AI 站使用 Ant Design，dropdown 由 `.ant-dropdown-trigger` 触发：

```css
.ant-dropdown-trigger { cursor: pointer; transition: color 0.2s; }
.ant-dropdown-trigger:hover { color: var(--qtd-color-lime, rgb(178,255,0)); }

/* Dropdown 面板 */
.ant-dropdown { z-index: 1050; }
.ant-dropdown-menu-item {
  padding: 8px 16px;
  transition: background 0.15s;
}
.ant-dropdown-menu-item:hover { background: rgba(178,255,0,0.1); }
```

### 导航图标（左侧 Icon Sidebar）

```css
/* AI 站左侧竖排图标导航 */
.nav-icon-item {
  display: flex; flex-direction: column; align-items: center;
  padding: 12px 8px; border-radius: 12px; cursor: pointer;
  color: var(--qtd-text-secondary);
  transition: all 0.15s ease;
}
.nav-icon-item:hover {
  background: var(--qtd-bg-secondary);
  color: var(--qtd-color-lime, rgb(178,255,0));
}
.nav-icon-item.active {
  background: var(--qtd-bg-secondary);
  color: var(--qtd-color-lime, rgb(178,255,0));
  font-weight: 600;
}
```

### 输入框（搜索 / 提示词输入）

```css
/* AI 站输入框 */
.qtd-input, .search-input, textarea {
  background: var(--qtd-bg-secondary);
  border: 1.5px solid var(--qtd-border-default);
  border-radius: 12px;
  color: var(--qtd-text-primary);
  transition: border-color 0.15s, box-shadow 0.15s;
  outline: none;
}
.qtd-input:focus, .search-input:focus, textarea:focus {
  border-color: rgb(178, 255, 0);               /* 荧光绿焦点边框 */
  box-shadow: 0 0 0 3px rgba(178,255,0, 0.15);  /* 荧光绿光晕 */
}
.qtd-input::placeholder { color: var(--qtd-text-tertiary); }
```

---

## 三、千图主站（58pic.com）交互状态

### 主色 Token
```css
--qtp-green: #00B277;
--qtp-green-hover: #009966;
--qtp-lime-badge: rgba(178,255,0,0.4);
```

### 按钮

| 类型 | Default | Hover | Active |
|------|---------|-------|--------|
| 绿色主按钮 | `bg:#00B277` `color:#fff` | `bg:#009966` `shadow:0 4px 12px rgba(0,178,119,.3)` | `bg:#008855` `transform:scale(0.98)` |
| 白色次按钮 | `bg:#fff` `border:1.5px solid #00B277` `color:#00B277` | `bg:rgba(0,178,119,.08)` | `bg:rgba(0,178,119,.15)` |
| 灰色禁用 | `bg:#f5f5f5` `color:#999` `cursor:not-allowed` | — | — |

```css
/* 主站绿色按钮 */
.qtp-btn-primary {
  background: #00B277;
  color: #ffffff;
  border: none;
  border-radius: 6px;
  padding: 10px 20px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.15s ease;
}
.qtp-btn-primary:hover {
  background: #009966;
  box-shadow: 0 4px 12px rgba(0,178,119,0.3);
}
.qtp-btn-primary:active {
  background: #008855;
  transform: scale(0.98);
}
```

### 搜索框（大圆角 Pill，888px radius）

```css
.search-bar {
  border: 2px solid #00B277;
  border-radius: 888px;
  background: #ffffff;
  padding: 10px 20px;
  transition: box-shadow 0.15s, border-color 0.15s;
}
.search-bar:focus-within {
  border-color: #00B277;
  box-shadow: 0 0 0 4px rgba(0,178,119,0.15);
}
```

### 素材卡片（图片悬停遮罩）

```css
.pic-card {
  border-radius: 8px;
  overflow: hidden;
  position: relative;
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;
}
.pic-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 24px rgba(0,0,0,0.15);
}

/* hover 遮罩（显示操作按钮） */
.pic-card .mask {
  position: absolute; inset: 0;
  background: rgba(0,0,0,0.4);
  opacity: 0;
  transition: opacity 0.2s;
  display: flex; align-items: flex-end;
  padding: 12px;
}
.pic-card:hover .mask { opacity: 1; }

/* 遮罩内操作按钮 */
.mask-btn {
  background: #ffffff;
  color: #141414;
  border-radius: 4px;
  padding: 6px 12px;
  font-size: 12px;
  cursor: pointer;
  transition: background 0.15s;
}
.mask-btn:hover { background: #00B277; color: #ffffff; }
```

### 权益行 hover（定价页）

```css
.vip-type-equity-content-item {
  padding: 12px 16px;
  border-radius: 8px;
  transition: background 0.15s;
}
.vip-type-equity-content-item:hover,
.vip-type-equity-content-item.hover {
  background: rgba(0,178,119,0.06);
}
```

---

## 四、千图企业站（qiye.58pic.com）交互状态

### 主色 Token
```css
--qte-brand-gradient: linear-gradient(to right, #40FFAA, #4079FF);
--qte-blue: #1980FF;
--qte-blue-hover: #1a6fd4;
```

### 套餐切换卡（`.vip-card-item`）

```css
.vip-card-item {
  cursor: pointer;
  transition: all 0.2s ease;
  opacity: 0.8;
}
.vip-card-item:hover { opacity: 1; transform: translateY(-2px); }
.vip-card-item.active { opacity: 1; }
```

### 企业蓝色按钮（`.qtd-btn.qtd-primary-business-btn`）

| 状态 | 背景 | 阴影 |
|------|------|------|
| default | `rgb(25,128,255)` | none |
| hover | `rgb(26,111,212)` | `0 4px 12px rgba(25,128,255,0.4)` |
| active | `rgb(20,90,180)` | `0 2px 8px rgba(25,128,255,0.3)` |
| disabled | `rgba(25,128,255,0.4)` | none |

```css
.qtd-btn.qtd-primary-business-btn {
  background: rgb(25,128,255);
  color: #fff;
  border-radius: 8px;
  transition: all 0.15s ease;
}
.qtd-btn.qtd-primary-business-btn:hover {
  background: #1a6fd4;
  box-shadow: 0 4px 12px rgba(25,128,255,0.4);
}
.qtd-btn.qtd-primary-business-btn:active {
  background: #145ab4;
  box-shadow: 0 2px 8px rgba(25,128,255,0.3);
}
```

### 渐变按钮（获取方案 CTA）

```css
.btn-gradient-brand {
  background: linear-gradient(to right, #40FFAA, #4079FF);
  color: #ffffff;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  transition: opacity 0.15s, box-shadow 0.15s;
}
.btn-gradient-brand:hover {
  opacity: 0.9;
  box-shadow: 0 4px 16px rgba(64,121,255,0.4);
}
```

### 导航链接（企业站白色文字）

```css
/* 企业站 header 导航链接 */
header a { color: rgb(255,255,255); text-decoration: none; transition: opacity 0.15s; }
header a:hover { opacity: 0.75; }
header a.active { opacity: 1; font-weight: 600; }
```

---

## 五、三站共用：输入框焦点态颜色对照

| 产品线 | 焦点边框色 | 光晕色 |
|--------|-----------|--------|
| 千图AI | `rgb(178,255,0)` | `rgba(178,255,0,0.15)` |
| 千图主站 | `#00B277` | `rgba(0,178,119,0.15)` |
| 千图企业站 | `#1980FF` | `rgba(25,128,255,0.15)` |

---

## 六、Ant Design 组件状态（千图AI 专用）

千图AI 大量使用 Ant Design（antd）组件库，以下为常见组件的真实交互状态：

### Ant Design Select / Dropdown

```css
/* Select 下拉选项 hover */
.ant-select-item-option:hover,
.ant-select-item-option-active {
  background: rgba(178,255,0,0.1);
}
/* Select 选中 */
.ant-select-item-option-selected {
  background: rgba(178,255,0,0.2);
  font-weight: 600;
  color: rgb(178,255,0);
}

/* Dropdown menu item hover */
.ant-dropdown-menu-item:hover { background: rgba(178,255,0,0.1); }
```

### Ant Design Switch

```css
/* 关闭态 */
.ant-switch { background: rgba(0,0,0,0.25); transition: background 0.2s; }
/* 开启态 */
.ant-switch-checked { background: rgb(178,255,0); }
/* 圆钮 */
.ant-switch-handle::before {
  background: #ffffff;
  border-radius: 50%;
  box-shadow: 0 2px 4px rgba(0,0,0,0.3);
}
```

### Ant Design Tooltip

```css
.ant-tooltip-inner {
  background: rgba(20,20,20,0.85);
  color: #ffffff;
  border-radius: 8px;
  font-size: 12px;
  padding: 6px 10px;
  backdrop-filter: blur(8px);
}
```

---

## 七、CSS 变量 — 三站交互色速查

```css
/* ===== 千图AI (--qtd- prefix) ===== */
--qtd-color-lime: rgb(178, 255, 0);          /* 荧光绿，主交互色 */
--qtd-color-lime-light: rgba(178,255,0,0.15);/* 荧光绿 focus 光晕 */
--qtd-bg-hover: rgba(255,255,255,0.06);      /* 深色主题 hover 背景 */
--qtd-bg-active: rgba(255,255,255,0.12);     /* 深色主题 active 背景 */

/* ===== 千图主站 (--qtp- prefix) ===== */
--qtp-green: #00B277;
--qtp-green-hover: #009966;
--qtp-green-light: rgba(0,178,119,0.08);     /* hover 背景 */
--qtp-green-focus: rgba(0,178,119,0.15);     /* focus 光晕 */

/* ===== 千图企业站 (--qte- prefix) ===== */
--qte-blue: #1980FF;
--qte-blue-hover: #1a6fd4;
--qte-blue-light: rgba(25,128,255,0.1);      /* hover 背景 */
--qte-blue-focus: rgba(25,128,255,0.15);     /* focus 光晕 */
--qte-gradient: linear-gradient(to right, #40FFAA, #4079FF);
```
