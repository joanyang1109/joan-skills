# docs/demo — 模块说明与页面对照

本目录为 **homeNewV2 首页** 等的静态 UI 切片。目录约定：

- **`theme.css`**：全局主题变量（根目录）。
- **`modules/`**：**跨页面复用**的公共切片（样式 / HTML 片段 / 个别全局脚本）。
- **`pages/<页面名>/`**：某一页的入口与 **仅该页使用** 的模块（`index.html` + `modules/`）。
- **`index.html`**：Hub，链到各页。

## 目录结构（摘要）

```
docs/demo/
├── theme.css
├── MODULES.md
├── index.html
├── modules/                    # 公共
│   ├── app-header.css / .html
│   ├── page-shell.css / .html
│   ├── create-box-newv2.css / .html
│   ├── community-masonry.css / .html   # 瀑布流占位（可复用到其他列表页）
│   ├── theme-toggle.js
│   └── home-assemble.js        # 可选：HTTP 下 fetch 片段组装（见文末）
└── pages/
    ├── home.html               # 兼容跳转 → home/index.html
    └── home/
        ├── index.html          # 首页主文件（推荐 file:// 打开）
        └── modules/            # 仅首页
            ├── hero-titles.css / .html
            ├── classify-ai-tools.css / .html
            ├── community-header.css / .js / .html
            ├── community-toolbar.css / .html
            ├── community-loading.css / .html
            ├── community-admin.css / .html
            └── feedback-aside.css / .js / .html
    └── pricing/                        # 定价页：静态 HTML/CSS + 接口数据
        ├── index.html                  # 定价页切片（file:// 可开）
        ├── modules/                    # 定价页专用样式与脚本
        │   ├── pricing-01-page-shell.css … pricing-07-qa-slogan.css
        │   └── pricing-demo.js
        ├── ai-pricing-index.core.json  # 接口 `data` 核心字段（卡片 + 对比表）
        ├── data.full.json              # 完整快照
        └── extract-core.py
```

## 定价页 `pages/pricing/` 数据说明

| 文件 | 说明 |
|------|------|
| [pages/pricing/ai-pricing-index.core.json](pages/pricing/ai-pricing-index.core.json) | 与线上一致：`{ code, msg, data }`。`data` 仅含 **`vip_split_plan_anaid_functions`**（Swiper 卡片区）与 **`vip_split_details`**（模型对比表）。已去掉 CRM/库存等与 UI 无关字段；**页头/页脚** 使用公共 `Layout`，不在本接口 `data` 中。 |
| [pages/pricing/data.full.json](pages/pricing/data.full.json) | 自线上导出的完整响应备份，便于对照字段差异。 |
| [pages/pricing/extract-core.py](pages/pricing/extract-core.py) | 更新 `data.full.json` 后执行：`python3 extract-core.py` |

## 定价页 `pages/pricing/` HTML/CSS 切片

| 文件 | 职责 |
|------|------|
| [pages/pricing/index.html](pages/pricing/index.html) | 入口：公共 `app-header` + 定价主流程（标题、限时条、卡片行、推荐块、对比表节选、Q&A、slogan）；**不含**站点 `Footer`（线上为公共组件） |
| [pages/pricing/modules/pricing-01-page-shell.css](pages/pricing/modules/pricing-01-page-shell.css) | 滚动容器、背景图、顶栏渐变遮罩 |
| [pages/pricing/modules/pricing-02-hero.css](pages/pricing/modules/pricing-02-hero.css) | 主标题、限时优惠条 |
| [pages/pricing/modules/pricing-03-card-area.css](pages/pricing/modules/pricing-03-card-area.css) | 单独购买入口、个人/企业切换、卡片横向区、「详细对比」锚点 |
| [pages/pricing/modules/pricing-04-product-card.css](pages/pricing/modules/pricing-04-product-card.css) | 产品卡片（对齐 `productCard.module.scss` 节选） |
| [pages/pricing/modules/pricing-05-recommend.css](pages/pricing/modules/pricing-05-recommend.css) | 左右价值对比 + 推荐套餐卡 |
| [pages/pricing/modules/pricing-06-product-table.css](pages/pricing/modules/pricing-06-product-table.css) | 对比表布局节选（完整矩阵见线上 `ProductTable`） |
| [pages/pricing/modules/pricing-07-qa-slogan.css](pages/pricing/modules/pricing-07-qa-slogan.css) | 常见问题、底部 CTA |
| [pages/pricing/modules/pricing-demo.js](pages/pricing/modules/pricing-demo.js) | 滚动遮罩、FAQ 展开、对比区滚动锚点 |

数据契约见同目录 `ai-pricing-index.core.json`（`vip_split_plan_anaid_functions` / `vip_split_details`）。

## 公共 `modules/` 一览

| 文件 | 职责 |
|------|------|
| [modules/app-header.css](modules/app-header.css) | 顶部栏 UI（对齐 `components/layout/header2.jsx`） |
| [modules/app-header.html](modules/app-header.html) | 片段：顶栏 DOM |
| [modules/theme-toggle.js](modules/theme-toggle.js) | 深色/浅色：`localStorage.theme` + `html.qtd-ai-light-mode` |
| [modules/page-shell.css](modules/page-shell.css) | 页面滚动壳、顶栏渐变遮罩、`.demo-common-content-box` |
| [modules/page-shell.html](modules/page-shell.html) | 片段：`.demo-home__top-mask` 等壳层占位 |
| [modules/create-box-newv2.css](modules/create-box-newv2.css) | CreateBoxNewv2 **展开态**（对齐 `createBoxNew.module.scss`） |
| [modules/create-box-newv2.html](modules/create-box-newv2.html) | 片段：创作区 DOM |
| [modules/community-masonry.css](modules/community-masonry.css) | 瀑布流占位（CSS `column-count`） |
| [modules/community-masonry.html](modules/community-masonry.html) | 片段：瀑布流占位卡片 |
| [modules/home-assemble.js](modules/home-assemble.js) | 可选组装脚本（见「本地预览」） |

## 首页 `pages/home/modules/` 一览

| 文件 | 职责 |
|------|------|
| [pages/home/modules/hero-titles.css](pages/home/modules/hero-titles.css) | 首屏欢迎标题与副标题 |
| [pages/home/modules/hero-titles.html](pages/home/modules/hero-titles.html) | 片段：标题文案 |
| [pages/home/modules/classify-ai-tools.css](pages/home/modules/classify-ai-tools.css) | AI 工具推荐卡片行 + 第四项悬停展开 |
| [pages/home/modules/classify-ai-tools.html](pages/home/modules/classify-ai-tools.html) | 片段：分类工具条 |
| [pages/home/modules/community-header.css](pages/home/modules/community-header.css) | 社区标题、标签条、下划线背景 |
| [pages/home/modules/community-header.js](pages/home/modules/community-header.js) | 标签选中与下划线位置 |
| [pages/home/modules/community-header.html](pages/home/modules/community-header.html) | 片段：社区标题区 |
| [pages/home/modules/community-toolbar.css](pages/home/modules/community-toolbar.css) | 搜索框 + 排序 |
| [pages/home/modules/community-toolbar.html](pages/home/modules/community-toolbar.html) | 片段：工具栏 |
| [pages/home/modules/community-loading.css](pages/home/modules/community-loading.css) | 首屏加载态 |
| [pages/home/modules/community-loading.html](pages/home/modules/community-loading.html) | 片段：加载态 |
| [pages/home/modules/community-admin.css](pages/home/modules/community-admin.css) | 管理员底栏 |
| [pages/home/modules/community-admin.html](pages/home/modules/community-admin.html) | 片段：管理条 |
| [pages/home/modules/feedback-aside.css](pages/home/modules/feedback-aside.css) | 右侧反馈 + 回顶 |
| [pages/home/modules/feedback-aside.js](pages/home/modules/feedback-aside.js) | 滚动顶栏遮罩、`?admin=` / `?loading=`、回顶 |
| [pages/home/modules/feedback-aside.html](pages/home/modules/feedback-aside.html) | 片段：反馈侧栏 |

## 与旧 `mod-NN-*` 文件名对照（迁移说明）

| 旧名 | 新位置 |
|------|--------|
| mod-11-app-header | `modules/app-header` |
| mod-11-theme-toggle.js | `modules/theme-toggle.js` |
| mod-01-page-shell | `modules/page-shell` |
| mod-03-create-box | `modules/create-box-newv2` |
| mod-07-community-masonry | `modules/community-masonry` |
| mod-02-hero-titles | `pages/home/modules/hero-titles` |
| mod-04-classify-ai-tools | `pages/home/modules/classify-ai-tools` |
| mod-05-community-header | `pages/home/modules/community-header` |
| mod-06-community-toolbar | `pages/home/modules/community-toolbar` |
| mod-08-community-loading | `pages/home/modules/community-loading` |
| mod-09-community-admin | `pages/home/modules/community-admin` |
| mod-10-feedback-aside | `pages/home/modules/feedback-aside` |

## 页面对照表

| 页面（产品语义） | 静态入口 | 线上路由 / 备注 |
|------------------|----------|-------------------|
| 首页（homeNewV2） | [pages/home/index.html](pages/home/index.html) | Next：`/pages/homeNewV2` 以项目为准 |

外链（首页 `index.html`）：[iconfont 4071226](https://at.alicdn.com/t/c/font_4071226_yuk7h8umu1.css)

## 模块依赖与演示边界

| 区块 | 依赖 theme.css | JS | 静态演示边界 |
|------|----------------|-----|--------------|
| app-header | 是 + iconfont | theme-toggle | 无 Popover；主题与 `newTheme.scss` 一致 |
| page-shell | 是 | 否 | 仅滚动容器与遮罩 |
| hero-titles | 是 | 否 | 文案静态 |
| create-box-newv2 | 是 | 否 | contenteditable 占位；无真实提交 |
| classify-ai-tools | 是 | 否 | 第四项 CSS 悬停代替 Popover |
| community-header | 是 | community-header.js | 「AI工具」仅为按钮 |
| community-toolbar | 是 | 否 | 搜索/排序无接口 |
| community-masonry | 是 | 否 | 非 CardB / masonic |
| community-loading | 是 | 否 | `?loading=1` 由 feedback 脚本切换 |
| community-admin | 是 | 否 | `?admin=1` 显示 |
| feedback-aside | 是 | feedback-aside.js | 反馈区简化 |

## 主题变量摘要（关键）

- 背景与文字：`--new-grey-*`、`--new-text-*`、`--qtd-ai-drak-bg-1`
- 交互强调：`--qtd-ai-text-color-hover-1`、`--qtd-transition-cubic-1`
- z-index：`--demo-z-feedback`、`--demo-z-admin`（见 theme.css）

## 与线上差异（统一说明）

1. 无 Next、React、真实接口；顶部栏无积分 Popover、用户下拉等弹层。
2. CreateBox 为展开态静态还原；逻辑见 `components/huitu/createBoxNewv2.jsx`。
3. 瀑布流为 CSS 多列 + 渐变块，非线上 masonic + CardB。
4. 历史侧栏 / 左导航未模拟。

## 响应式

与 `homeNewV2.module.scss` 思路对齐；`.demo-common-content-box` 断点见各 CSS 注释。

## 本地预览

- **首页** [`pages/home/index.html`](pages/home/index.html)：内联完整 DOM，可直接 **`file://`** 打开；相对路径加载 `../../theme.css`、`../../modules/*`、`./modules/*`（iconfont 与图片需联网）。
- **Hub** [`index.html`](index.html)：可 `file://`。
- **旧路径** [`pages/home.html`](pages/home.html)：自动跳转至 `home/index.html`。
- **可选组装**：`home-assemble.js` + 占位节点需 **HTTP 静态服务**（`fetch` 无法读 `file://`），例如 `npx serve docs/demo` 后访问 `/pages/home/index.html`（需在页面中引入 `data-demo-assemble` 壳页，当前默认入口为内联版，不依赖组装）。

可选 query（首页）：

- `?admin=1` — 显示管理员条  
- `?loading=1` — 显示首屏加载态  
