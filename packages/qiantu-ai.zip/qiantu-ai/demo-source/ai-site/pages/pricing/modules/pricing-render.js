/**
 * 从 CDN fetch 定价 JSON（与线上 index.php?r=ai/ai-pricing/index 同源结构），渲染卡片 + 对比表。
 * 默认使用完整快照；可改 PRICING_JSON_URL 为 core 以减小体积。
 */
(function () {
  /** @type {string} 完整数据（你已上传 CDN） */
  var PRICING_JSON_URL = 'https://static.qiantucdn.com/static/canvas/demo/data.full.json';
  /** @type {string} 核心 data（可选，体积更小） */
  var PRICING_CORE_URL = 'https://static.qiantucdn.com/static/canvas/demo/ai-pricing-index.core.json';

  var USE_CORE = false;

  function escapeHtml(s) {
    if (s == null || s === '') return '';
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function n(v) {
    var x = Number(v);
    return isNaN(x) ? 0 : x;
  }

  function normPlanModels(m) {
    if (!m || typeof m !== 'object') return null;
    return {
      image: m.image,
      video: m.video,
      music: m.music,
      threeD: m.threeD || m.thirdD,
    };
  }

  /**
   * 与 pages/pricing.jsx 一致：按 product_show_group 分组
   */
  function buildCardList(planFunctions) {
    var list = (planFunctions || []).map(function (item, index) {
      if (!item.product_show_group) {
        item.product_show_group = item.product_show_group || index + 1;
      }
      return item;
    });
    var grouped = {};
    list.forEach(function (item) {
      var gid = item.product_show_group;
      if (!grouped[gid]) grouped[gid] = [];
      grouped[gid].push(item);
    });
    return Object.keys(grouped).map(function (gid) {
      var groupItems = grouped[gid];
      return {
        activeItem: groupItems[0] || {},
        moreItem: groupItems || [],
      };
    });
  }

  function renderPlanModels(models, isFree) {
    if (!models) return '';
    var parts = [];
    var m = normPlanModels(models);
    if (!m) return '';

    function block(iconClass, label, arr, freeWord) {
      if (!arr || !arr.length) return '';
      var show = arr.slice(0, 4).join('、');
      var tail = arr.length > 4 ? (isFree ? '等免费模型' : '等会员高级模型') : '';
      var title = arr.join('、');
      return (
        '<div class="modelItem">' +
        '<i class="icon ' +
        iconClass +
        ' modelItemIcon"></i><p><span>' +
        escapeHtml(label) +
        '</span><em>' +
        escapeHtml(show) +
        escapeHtml(tail) +
        '</em>' +
        (arr.length > 4
          ? '<span class="demo-pricing-tip" title="' +
            escapeHtml(title) +
            '"><i class="icon icon-a-Frame10 yiwen"></i></span>'
          : '') +
        '</p></div>'
      );
    }

    parts.push(block('icon-Frame-11', '图片', m.image, isFree));
    parts.push(block('icon-shipin', '视频', m.video, isFree));
    parts.push(block('icon-a-3D', '3D', m.threeD, isFree));
    parts.push(block('icon-yinleyinxiao-xianxing-01', '音频', m.music, false));
    return parts.join('');
  }

  function renderGift(gift) {
    if (!gift || typeof gift !== 'object') return '';
    var title = (gift.title || '').replace(/个人/g, '');
    var html =
      '<div class="productCardContentGiftBox">' +
      '<div class="productCardContentGiftBoxRow"><em>赠</em><span>' +
      escapeHtml(title) +
      ' ';
    if (gift.limit_text) {
      html += '<i>' + escapeHtml(gift.limit_text) + '</i>';
    }
    html += '</span>';
    var ql = gift.quotaLimit;
    if (ql && ql.length) {
      var hasActive = ql.some(function (x) {
        return n(x.status) === 1;
      });
      if (hasActive) html += '<em>同时享:</em>';
    }
    html += '</div>';
    if (ql && ql.length) {
      ql.forEach(function (_item) {
        var dis = n(_item.status) === 0;
        html +=
          '<div class="productCardContentGiftBoxRow">' +
          '<div class="productCardContentGiftBoxRowQuotaLimit' +
          (dis ? ' productCardContentGiftBoxRowQuotaLimitDisabled' : '') +
          '">' +
          '<div class="productCardContentGiftBoxRowQuotaLimitLeft">';
        if (dis) {
          html += '<i class="icon icon-guanbi productCardContentGiftBoxRowQuotaLimitIcon"></i>';
        }
        html +=
          '<p class="productCardContentGiftBoxRowQuotaLimitName">' +
          escapeHtml(_item.name || '') +
          '</p>';
        if (_item.desc) {
          html +=
            '<span class="demo-pricing-tip" title="' +
            escapeHtml(_item.desc) +
            '"><i class="icon icon-a-Frame10 yiwen"></i></span>';
        }
        if (_item.resolution) {
          html +=
            '<em class="productCardContentGiftBoxRowQuotaLimitResolution">' +
            escapeHtml(_item.resolution) +
            '</em>';
        }
        html += '</div><div class="productCardContentGiftBoxRowQuotaLimitRight">';
        if (_item.tag) {
          html += '<em>' + escapeHtml(_item.tag) + '</em>';
        }
        html += '</div></div></div>';
      });
    }
    html += '</div>';
    return html;
  }

  function renderOneCard(item, moreItems, active, cardIndex) {
    var hasMulti =
      moreItems &&
      moreItems.length > 1 &&
      String(item.title) !== '免费';
    var showMore = hasMulti;
    var pointsLabel = item.title === '免费' ? '每日到账' : '总到账';
    var priceLine =
      '¥<em>' +
      n(item.price).toLocaleString() +
      '</em><span>/' +
      escapeHtml(item.unit_text || '') +
      '</span>';
    if (n(item.original_price) > n(item.price)) {
      priceLine +=
        '<i>¥' + n(item.original_price).toLocaleString() + '</i>';
    }

    var pointInner =
      '<div class="productCardContentPointBoxIcon">' +
      '<i class="icon icon-a-Frame1321318321"></i>' +
      '<span>' +
      pointsLabel +
      ' ' +
      n(item.total_points).toLocaleString() +
      '点</span>';
    if (showMore) {
      pointInner +=
        '<i class="icon icon-xiala dropItem"></i>' +
        '<select class="demo-pricing-card-variant" data-card-index="' +
        cardIndex +
        '" aria-label="切换档位">' +
        moreItems
          .map(function (opt, i) {
            var sel =
              String(opt.product_id) === String(item.product_id) ||
              (i === 0 && String(item.product_id) === '0');
            return (
              '<option value="' +
              i +
              '"' +
              (sel ? ' selected' : '') +
              '>' +
              n(opt.total_points || opt.points).toLocaleString() +
              '点 · ¥' +
              n(opt.price).toLocaleString() +
              '</option>'
            );
          })
          .join('') +
        '</select>';
    }
    pointInner += '</div>';

    var dropdownBlock =
      '<div class="productCardContentDropdownBox" style="border-radius:' +
      (item.gift ? '8px 8px 0 0' : '8px') +
      '">' +
      '<div class="productCardContentPointBox">' +
      pointInner +
      '<p class="productCardContentPointTips">' +
      escapeHtml(item.generation_limit || '') +
      '</p></div></div>';

    var plans = item.plan_and_functions || [];
    var bottomPlans = '';
    var plen = plans.length;
    plans.forEach(function (plan, index) {
      var iconClass = n(plan.status) === 1 ? 'icon-duigou success' : 'icon-guanbi error';
      var lim = item.title === '免费' && index === 1 ? '<em>限时</em>' : '';
      bottomPlans +=
        '<div class="productCardBottomItemBox' +
        (plan.models ? ' productCardBottomItemBoxModel' : '') +
        '">' +
        '<div class="productCardBottomItem">' +
        '<i class="icon ' +
        iconClass +
        '"></i><span>' +
        lim +
        escapeHtml(plan.msg || '') +
        '</span>';
      if (plan.desc) {
        bottomPlans +=
          '<span class="demo-pricing-tip" title="' +
          escapeHtml(plan.desc) +
          '"><i class="icon icon-a-Frame10 yiwen"></i></span>';
      }
      bottomPlans += '</div>';
      if (plan.models) {
        bottomPlans += renderPlanModels(plan.models, item.title === '免费');
      }
      if (plen >= 2 && index === plen - 2) {
        bottomPlans += '<div class="productCardBottomItemLine"></div>';
      }
      bottomPlans += '</div>';
    });

    var iconHtml = item.icon
      ? '<img src="' + escapeHtml(item.icon) + '" alt="" />'
      : '';
    var btnClass =
      'productCardContentButton' +
      (item.button === '当前计划' ? ' currentPlan' : '');

    return (
      '<article class="productCard' +
      (active ? ' active' : '') +
      '" data-card-index="' +
      cardIndex +
      '">' +
      '<div class="productCardContent">' +
      '<div class="productCardContentTitle">' +
      '<div class="productCardContentName">' +
      iconHtml +
      '<span>' +
      escapeHtml(item.title || '') +
      '</span></div>' +
      '<div class="productCardContentPrice">' +
      priceLine +
      '</div></div>' +
      '<div class="productCardContentDropdown">' +
      dropdownBlock +
      renderGift(item.gift) +
      '</div></div>' +
      '<div class="productCardBottom">' +
      '<button type="button" class="' +
      btnClass +
      '" data-shop-id="' +
      escapeHtml(String(item.product_id || '')) +
      '"><span>' +
      escapeHtml(item.button || '') +
      '</span></button>' +
      bottomPlans +
      '</div></article>'
    );
  }

  function bindCardButtons(root) {
    root.querySelectorAll('.productCardContentButton').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var id = btn.getAttribute('data-shop-id');
        if (!id) return;
        var href =
          '//www.58pic.com/index.php?m=sponsor&a=indexnew&page_type=34&shop_id=' +
          encodeURIComponent(id);
        var w = window.open(href, '_blank');
        if (!w) window.location.href = href;
      });
    });
  }

  function renderCards(container, cardList, setActiveIdx) {
    var activeIdx = typeof setActiveIdx === 'number' ? setActiveIdx : 1;
    window.__pricingActiveCardIdx = activeIdx;
    var html = cardList
      .map(function (group, index) {
        return renderOneCard(
          group.activeItem,
          group.moreItem,
          index === activeIdx,
          index
        );
      })
      .join('');
    container.innerHTML = html;

    if (!container._pricingVariantBound) {
      container._pricingVariantBound = true;
      container.addEventListener('change', function (ev) {
        var sel = ev.target;
        if (!sel || !sel.classList || !sel.classList.contains('demo-pricing-card-variant')) return;
        var idx = n(sel.getAttribute('data-card-index'));
        var gi = n(sel.value);
        if (!window.__pricingCardList || !window.__pricingCardList[idx]) return;
        var group = window.__pricingCardList[idx];
        var item = group.moreItem[gi];
        if (!item) return;
        var article = container.querySelector('.productCard[data-card-index="' + idx + '"]');
        if (!article) return;
        var newHtml = renderOneCard(item, group.moreItem, article.classList.contains('active'), idx);
        var wrap = document.createElement('div');
        wrap.innerHTML = newHtml;
        article.replaceWith(wrap.firstElementChild);
        bindCardButtons(container);
        var cards = container.querySelectorAll('.productCard');
        var ax = window.__pricingActiveCardIdx;
        cards.forEach(function (el, i) {
          el.classList.toggle('active', i === ax);
        });
      });
    }

    bindCardButtons(container);

    container.querySelectorAll('.productCard').forEach(function (card, i) {
      card.addEventListener('mouseenter', function () {
        container.querySelectorAll('.productCard').forEach(function (c) {
          c.classList.remove('active');
        });
        card.classList.add('active');
      });
    });

    var swiperBox = container.closest('.swiperBox');
    if (swiperBox) {
      swiperBox.addEventListener('mouseleave', function () {
        var ax = window.__pricingActiveCardIdx;
        container.querySelectorAll('.productCard').forEach(function (c, i) {
          c.classList.toggle('active', i === ax);
        });
      });
    }
  }

  var SECTION_KEYS = [
    { key: 'image', icon: 'icon-Frame-11', label: '图片模型' },
    { key: 'video', icon: 'icon-shipin', label: '视频模型' },
    { key: 'threeD', icon: 'icon-a-3D', label: '3D模型' },
    { key: 'music', icon: 'icon-yinle', label: '音乐模型' },
    { key: 'quotaLimit', icon: 'icon-wuxian', label: '无限使用' },
    { key: 'other_privilege', icon: 'icon-leixing-1', label: '其他权益' },
  ];

  function colRows(item, key) {
    if (key === 'threeD') {
      return item.threeD || item.thirdD;
    }
    return item[key];
  }

  function renderProductTable(container, list) {
    if (!list || !list.length || !list[0]) {
      container.innerHTML = '<p class="demo-table-note">暂无对比数据</p>';
      return;
    }

    if (!container._pricingExpand) {
      container._pricingExpand = {
        imageExpand: true,
        videoExpand: true,
        threeDExpand: true,
        musicExpand: true,
        quotaLimitExpand: true,
        other_privilegeExpand: true,
      };
    }
    var expand = container._pricingExpand;

    var first = list[0];

    function rowsForKey(key) {
      var arr = colRows(first, key);
      if (!arr || !arr.length) return null;
      return arr;
    }

    function filterRows(key, rows) {
      var ex = expand[key + 'Expand'];
      if (!rows) return [];
      return ex ? rows : rows.slice(0, 2);
    }

    function fixedColumnBlock(meta) {
      var key = meta.key;
      var rows = rowsForKey(key);
      if (!rows) return '';
      var fr = filterRows(key, rows);
      var showToggle = rows.length > 3;
      var expanded = expand[key + 'Expand'];

      var body = fr
        .map(function (row, index) {
          var img =
            row.mini_logo ? '<img src="' + escapeHtml(row.mini_logo) + '" alt="" loading="lazy"/>' : '';
          var desc =
            key !== 'other_privilege' && key !== 'quotaLimit'
              ? '<p>' + escapeHtml(row.desc || '') + '</p>'
              : '';
          return (
            '<div class="fixedColumnItemContentRow" data-row-key="' +
            key +
            '-' +
            index +
            '">' +
            '<div class="fixedColumnItemContentRowItem">' +
            img +
            '<span>' +
            escapeHtml(row.name || '') +
            '</span></div>' +
            desc +
            '</div>'
          );
        })
        .join('');

      var toggle = showToggle
        ? '<div class="fixedColumnItemContentBottom" data-expand-key="' +
          key +
          '"><div><i class="icon icon-xiala" style="transform:rotate(' +
          (expanded ? '180deg' : '0deg') +
          ')"></i><span>' +
          (expanded ? '收起' : '展开') +
          '</span></div></div>'
        : '';

      return (
        '<div class="fixedColumnItemContent" data-section="' +
        key +
        '">' +
        '<div class="fixedColumnItemContentRowTitle">' +
        '<div><i class="icon ' +
        meta.icon +
        '"></i><span>' +
        escapeHtml(meta.label) +
        '</span></div></div>' +
        body +
        toggle +
        '</div>'
      );
    }

    var fixedInner = SECTION_KEYS.map(function (meta) {
      return rowsForKey(meta.key) ? fixedColumnBlock(meta) : '';
    }).join('');

    var expandAll =
      expand.imageExpand &&
      expand.videoExpand &&
      expand.threeDExpand &&
      expand.musicExpand &&
      expand.quotaLimitExpand &&
      expand.other_privilegeExpand;

    function planColumn(item) {
      var pid = item.prduct_id || item.product_id;
      var price = n(item.price);
      var priceHtml =
        price > 0
          ? '<em>¥ </em><span>' + price.toLocaleString() + '</span><em>元</em>'
          : '<span><em>按需定制</em></span>';
      var href =
        price > 0
          ? '//www.58pic.com/index.php?m=sponsor&a=indexnew&page_type=34&shop_id=' +
            encodeURIComponent(pid || '')
          : 'https://www.58pic.com/index.php?m=contactQimo&type=ka';

      function cellsForKey(key) {
        var rows = colRows(item, key);
        if (!rows || !rows.length) return '';
        var ex = expand[key + 'Expand'];
        var slice = ex ? rows : rows.slice(0, 2);
        var showSpacer = rows.length > 3;
        var chtml = slice
          .map(function (row, index) {
            var inner =
              key === 'other_privilege' || key === 'quotaLimit'
                ? '<span>' +
                  escapeHtml(row.desc || '') +
                  (!row.desc
                    ? '<i class="icon ' +
                      (n(row.status) === 1 ? 'icon-duigou' : 'icon-guanbi') +
                      '"></i>'
                    : '') +
                  '</span>'
                : '<span>' + escapeHtml(row.generation_count_text || '') + '</span>';
            return (
              '<div class="productTableItemContentRow" data-col-key="' +
              key +
              '-' +
              index +
              '">' +
              inner +
              '</div>'
            );
          })
          .join('');
        var bottom = showSpacer
          ? '<div class="productTableItemContentBottom" data-spacer="' + key + '"></div>'
          : '';
        return (
          '<div class="productTableItemContent" data-plan-col-key="' +
          key +
          '">' +
          '<div class="productTableItemContentRowTitle"></div>' +
          chtml +
          bottom +
          '</div>'
        );
      }

      var colBlocks = SECTION_KEYS.map(function (meta) {
        var planRows = colRows(item, meta.key);
        return planRows && planRows.length ? cellsForKey(meta.key) : '';
      }).join('');

      return (
        '<div class="productTableSlide">' +
        '<div class="productTableItem">' +
        '<div class="productTableItemTitle">' +
        '<p class="productTableItemTitleText">' +
        escapeHtml(item.name || '') +
        '</p>' +
        '<p class="productTableItemTitlePrice">' +
        priceHtml +
        '</p>' +
        '<a href="' +
        href +
        '" target="_blank" rel="noreferrer">' +
        escapeHtml(item.button || '') +
        '</a></div>' +
        colBlocks +
        '</div></div>'
      );
    }

    var slides = list.map(planColumn).join('');

    container.innerHTML =
      '<div class="productTable">' +
      '<div class="fixedColumn">' +
      '<div class="fixedColumnItemTitle">' +
      '<div class="demo-pricing-expand-all" role="button" tabindex="0">' +
      '<span>' +
      (expandAll ? '收起' : '展开') +
      '全部计划和功能</span>' +
      '<i class="icon icon-quanyi_zhankai"></i></div></div>' +
      fixedInner +
      '</div>' +
      '<div class="swiperContainer">' +
      '<div class="swiperButtonPrev demo-pricing-table-prev"><i class="icon icon-shouqi-hengxiang"></i></div>' +
      '<div class="productTableSwiper demo-pricing-table-plans">' +
      slides +
      '</div>' +
      '<div class="swiperButtonNext demo-pricing-table-next"><i class="icon icon-shouqi-hengxiang"></i></div>' +
      '</div></div>';

    container.querySelector('.demo-pricing-expand-all').addEventListener('click', function () {
      var next = !expandAll;
      Object.keys(expand).forEach(function (k) {
        expand[k] = next;
      });
      renderProductTable(container, list);
    });

    SECTION_KEYS.forEach(function (meta) {
      var k = meta.key;
      container.querySelectorAll('[data-expand-key="' + k + '"]').forEach(function (el) {
        el.addEventListener('click', function () {
          expand[k + 'Expand'] = !expand[k + 'Expand'];
          renderProductTable(container, list);
        });
      });
    });

    var plansEl = container.querySelector('.demo-pricing-table-plans');
    var prev = container.querySelector('.demo-pricing-table-prev');
    var next = container.querySelector('.demo-pricing-table-next');
    if (plansEl && prev && next) {
      prev.addEventListener('click', function () {
        plansEl.scrollBy({ left: -200, behavior: 'smooth' });
      });
      next.addEventListener('click', function () {
        plansEl.scrollBy({ left: 200, behavior: 'smooth' });
      });
    }
  }

  function updateRecommend(cardList) {
    var rec = document.getElementById('demo-pricing-recommend');
    if (!rec || !cardList || !cardList[1]) return;
    var item = cardList[1].activeItem;
    if (!item) return;
    var icon = rec.querySelector('.recommendProductBoxCardBoxRightIcon img');
    var title = rec.querySelector('.recommendProductBoxCardBoxRightIcon span');
    var price = rec.querySelector('.recommendProductBoxCardBoxRightPrice span:last-child');
    var btn = rec.querySelector('.recommendProductBoxCardBoxRightButton button');
    var gift = rec.querySelector('.recommendProductBoxCardBoxRightButton em');
    if (icon) icon.src = item.icon || icon.src;
    if (title) title.textContent = item.title || '';
    if (price) {
      price.innerHTML =
        '<i>¥</i>' +
        n(item.price).toLocaleString() +
        '<em>/' +
        escapeHtml(item.unit_text || '') +
        '起</em>';
    }
    if (btn) btn.textContent = item.button || '立即开通';
    if (gift) {
      if (item.gift && item.gift.title) {
        gift.textContent = '限时赠' + item.gift.title;
        gift.style.display = '';
      } else {
        gift.style.display = 'none';
      }
    }
    rec.onclick = function (e) {
      if (e.target.closest('button')) return;
      var id = item.product_id;
      var href =
        '//www.58pic.com/index.php?m=sponsor&a=indexnew&page_type=34&shop_id=' + encodeURIComponent(id || '');
      window.open(href, '_blank');
    };
  }

  function showError(msg) {
    var cards = document.getElementById('demo-pricing-cards');
    var table = document.getElementById('demo-pricing-table-root');
    var err =
      '<div class="demo-pricing-error" role="alert"><p>' +
      escapeHtml(msg) +
      '</p><p>可检查网络或将 JSON 置于同域后重试。</p></div>';
    if (cards) cards.innerHTML = err;
    if (table) table.innerHTML = err;
    var loading = document.getElementById('demo-pricing-loading');
    if (loading) loading.hidden = true;
  }

  function run() {
    var url = USE_CORE ? PRICING_CORE_URL : PRICING_JSON_URL;
    var cardsEl = document.getElementById('demo-pricing-cards');
    var tableEl = document.getElementById('demo-pricing-table-root');
    var loading = document.getElementById('demo-pricing-loading');

    fetch(url, { credentials: 'omit' })
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      })
      .then(function (res) {
        if (n(res.code) !== 1 || !res.data) {
          throw new Error(res.msg || '接口返回异常');
        }
        var data = res.data;
        var planFunctions = data.vip_split_plan_anaid_functions;
        var details = data.vip_split_details || [];

        var cardList = buildCardList(planFunctions);
        window.__pricingCardList = cardList;

        if (loading) loading.hidden = true;
        if (cardsEl) {
          renderCards(cardsEl, cardList, 1);
        }
        if (tableEl) {
          tableEl._pricingExpand = null;
          window.__pricingTableList = details;
          renderProductTable(tableEl, details);
        }
        updateRecommend(cardList);
      })
      .catch(function (e) {
        console.error('[pricing-render]', e);
        showError(e.message || String(e));
      });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();
