/**
 * 定价页静态演示：滚动顶栏遮罩、FAQ 展开
 */
(function () {
  var root = document.querySelector('.demo-pricing-page');
  if (!root) return;

  function onScroll() {
    var y = window.scrollY || document.documentElement.scrollTop || 0;
    if (y > 8) {
      root.classList.add('demo-pricing-page--scrolled');
    } else {
      root.classList.remove('demo-pricing-page--scrolled');
    }
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  document.querySelectorAll('[data-demo-pricing-qa]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var id = btn.getAttribute('aria-controls');
      var panel = id ? document.getElementById(id) : null;
      var expanded = btn.getAttribute('aria-expanded') === 'true';
      var next = !expanded;
      btn.setAttribute('aria-expanded', next ? 'true' : 'false');
      if (panel) {
        panel.hidden = !next;
      }
      var icon = btn.querySelector('.qaBoxIcon');
      if (icon) {
        icon.style.transform = next ? 'rotate(180deg)' : 'rotate(0deg)';
      }
    });
  });

  var moreBtn = document.querySelector('.moreDetailButton');
  var tableAnchor = document.getElementById('demo-pricing-table-anchor');
  if (moreBtn && tableAnchor) {
    moreBtn.addEventListener('click', function () {
      tableAnchor.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  }
})();
