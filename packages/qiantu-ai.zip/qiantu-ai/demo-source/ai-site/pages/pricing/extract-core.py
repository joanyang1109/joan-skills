#!/usr/bin/env python3
"""从 data.full.json 生成 ai-pricing-index.core.json（与 pricing.jsx 使用的字段对齐）。"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

DROP_PLAN = frozenset({
    "creator", "created", "modified", "fav_num", "down_limit", "day_stock", "total_stock",
    "distribution_type", "last_modify", "is_model", "overseas_price", "effective_time",
    "aging_price", "pic_source", "pic_type", "pic_category", "page_type",
    "sort", "other_type", "is_show_fntime", "is_disc", "time_remark",
    "authority", "sub_account", "basic_id", "is_abroad", "vip_token", "custom_type",
    "first_price", "everytime_price", "renew_copy", "is_renew", "sort_1",
    "upgrade_discount_status", "upgrade_discount_config", "total_limit", "question_prompt",
    "is_life", "limit", "grant_product_id", "grant_mode", "ai_concurrent_limit",
    "is_default", "tag", "remark",
})

DETAIL_WHITELIST = frozenset({
    "name", "price", "button", "button_url", "product_id",
    "image", "video", "threeD", "thirdD", "music",
    "quotaLimit", "other_privilege",
})

MODEL_KEYS = frozenset({
    "name", "consume_point", "desc", "generation_count", "generation_count_text", "mini_logo", "status",
})
PRIV_KEYS = frozenset({"name", "desc", "status", "msg"})


def trim_plan_function_row(row):
    if not isinstance(row, dict):
        return row
    allowed = ("title", "desc", "status", "msg", "models")
    out = {k: row[k] for k in allowed if k in row}
    if "models" in out and isinstance(out["models"], dict):
        m = out["models"]
        clean = {}
        for mk, mv in m.items():
            if mk in ("image", "video", "music", "thirdD", "threeD") and isinstance(mv, list):
                clean[mk] = mv
        out["models"] = clean
    return out


def trim_gift(g):
    if not isinstance(g, dict):
        return g
    keys = ("title", "limit_text", "quotaLimit")
    out = {k: g[k] for k in keys if k in g}
    if "quotaLimit" in out and isinstance(out["quotaLimit"], list):
        out["quotaLimit"] = [
            {x: q[x] for x in ("name", "desc", "status", "resolution", "tag") if x in q}
            for q in out["quotaLimit"]
        ]
    return out


def trim_plan_item(obj):
    if not isinstance(obj, dict):
        return obj
    out = {}
    for k, v in obj.items():
        if k in DROP_PLAN:
            continue
        if k == "plan_and_functions" and isinstance(v, list):
            out[k] = [trim_plan_function_row(x) for x in v]
        elif k == "gift" and isinstance(v, dict):
            out[k] = trim_gift(v)
        else:
            out[k] = v
    return out


def trim_model_row(r):
    if not isinstance(r, dict):
        return r
    return {k: r[k] for k in MODEL_KEYS if k in r}


def trim_priv_row(r):
    if not isinstance(r, dict):
        return r
    return {k: r[k] for k in PRIV_KEYS if k in r}


def trim_detail_item(obj):
    if not isinstance(obj, dict):
        return obj
    out = {}
    for k, v in obj.items():
        if k not in DETAIL_WHITELIST:
            continue
        if k in ("image", "video", "threeD", "thirdD", "music") and isinstance(v, list):
            out[k] = [trim_model_row(x) for x in v]
        elif k in ("quotaLimit", "other_privilege") and isinstance(v, list):
            out[k] = [trim_priv_row(x) for x in v]
        else:
            out[k] = v
    return out


def main():
    full_path = ROOT / "data.full.json"
    out_path = ROOT / "ai-pricing-index.core.json"
    full = json.loads(full_path.read_text(encoding="utf-8"))
    data = full.get("data") or {}
    core = {
        "code": full.get("code", 1),
        "msg": full.get("msg", "操作成功"),
        "data": {
            "vip_split_plan_anaid_functions": [trim_plan_item(x) for x in data.get("vip_split_plan_anaid_functions") or []],
            "vip_split_details": [trim_detail_item(x) for x in data.get("vip_split_details") or []],
        },
    }
    out_path.write_text(json.dumps(core, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Wrote", out_path)


if __name__ == "__main__":
    main()
