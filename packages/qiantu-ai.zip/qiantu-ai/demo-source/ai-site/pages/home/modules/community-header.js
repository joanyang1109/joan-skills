/**
 * community-header — 标签条下划线随选中项移动（静态演示）
 */
(function () {
  var box = document.querySelector('[data-demo-tag-box]');
  var after = document.querySelector('[data-demo-tag-after]');
  if (!box || !after) return;

  function moveAfter(activeEl) {
    if (!activeEl) return;
    var parent = activeEl.closest('.demo-content-list-tag-box');
    if (!parent) return;
    var parentRect = parent.getBoundingClientRect();
    var elRect = activeEl.getBoundingClientRect();
    after.style.width = elRect.width + 'px';
    after.style.left = elRect.left - parentRect.left + parent.scrollLeft + 'px';
  }

  box.querySelectorAll('[data-demo-tag]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      box.querySelectorAll('[data-demo-tag]').forEach(function (b) {
        b.classList.remove('is-active');
      });
      btn.classList.add('is-active');
      moveAfter(btn);
    });
  });

  var active = box.querySelector('[data-demo-tag].is-active');
  if (active) {
    requestAnimationFrame(function () {
      moveAfter(active);
    });
  }
  function syncAfter() {
    var a = box.querySelector('[data-demo-tag].is-active');
    if (a) moveAfter(a);
  }

  window.addEventListener('resize', syncAfter, { passive: true });

  var wrap = document.querySelector('.demo-content-list-tag-box-wrap');
  if (wrap) {
    wrap.addEventListener('scroll', syncAfter, { passive: true });
  }
})();
