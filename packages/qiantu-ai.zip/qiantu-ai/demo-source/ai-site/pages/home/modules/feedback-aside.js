/**
 * feedback-aside：回顶、滚动顶栏遮罩、可选 query 开关
 */
(function () {
  var root = document.querySelector('.demo-home');
  if (!root) return;

  var params = new URLSearchParams(window.location.search);
  if (params.get('admin') === '1') {
    document.body.classList.add('demo-home--admin');
  }
  if (params.get('loading') === '1') {
    document.body.classList.add('demo-home--show-loading');
  }

  function onScroll() {
    if (root.scrollTop > 32) {
      document.body.classList.add('demo-home--scrolled');
    } else {
      document.body.classList.remove('demo-home--scrolled');
    }
  }

  root.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  var goTopBtn = document.querySelector('[data-demo-go-top]');
  if (goTopBtn) {
    goTopBtn.addEventListener('click', function () {
      root.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }
})();
