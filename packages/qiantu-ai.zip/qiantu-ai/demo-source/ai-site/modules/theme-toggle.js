/**
 * 主题切换：与线上一致使用 localStorage key `theme`，值为 `light` | `dark`
 * 在 document.documentElement（html）上切换 class `qtd-ai-light-mode`
 */
(function () {
  var STORAGE_KEY = 'theme';

  function getStoredTheme() {
    try {
      return localStorage.getItem(STORAGE_KEY);
    } catch (e) {
      return null;
    }
  }

  function setStoredTheme(theme) {
    try {
      localStorage.setItem(STORAGE_KEY, theme);
    } catch (e) {
      /* ignore */
    }
  }

  function applyTheme(theme) {
    var root = document.documentElement;
    var isLight = theme === 'light';
    root.classList.toggle('qtd-ai-light-mode', isLight);
    setStoredTheme(isLight ? 'light' : 'dark');

    var btn = document.getElementById('demo-theme-toggle');
    if (btn) {
      btn.setAttribute('aria-checked', isLight ? 'true' : 'false');
      btn.classList.toggle('demo-theme-toggle--light', isLight);
    }
  }

  function init() {
    var stored = getStoredTheme();
    if (stored === 'light' || stored === 'dark') {
      applyTheme(stored);
    } else {
      applyTheme('dark');
    }

    var btn = document.getElementById('demo-theme-toggle');
    if (!btn) return;

    btn.addEventListener('click', function () {
      var next = document.documentElement.classList.contains('qtd-ai-light-mode') ? 'dark' : 'light';
      applyTheme(next);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
