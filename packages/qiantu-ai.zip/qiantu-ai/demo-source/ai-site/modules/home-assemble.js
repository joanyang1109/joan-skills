/**
 * 可选：将 HTML 片段注入占位节点，再加载依赖脚本。
 * 必须通过 HTTP(S) 打开页面（fetch）；file:// 会失败。
 * 日常本地预览请直接用内联版 pages/home/index.html（见 MODULES.md），无需本脚本。
 *
 * 路径约定：
 * - 公共片段：与本文件同目录（modules/*.html）
 * - 首页专用片段：../pages/home/modules/*.html
 */
(function () {
  var assembleScript = document.querySelector('script[data-demo-assemble]');
  if (!assembleScript || !assembleScript.src) {
    console.error('[home-assemble] missing script[data-demo-assemble]');
    return;
  }

  var COMMON_BASE = new URL('./', assembleScript.src);
  var HOME_MODULES_BASE = new URL('../pages/home/modules/', assembleScript.src);

  /** @type {Array<[string, URL, string]>} */
  var PARTS = [
    ['fragment-mod-11', COMMON_BASE, 'app-header.html'],
    ['fragment-mod-01', COMMON_BASE, 'page-shell.html'],
    ['fragment-mod-02', HOME_MODULES_BASE, 'hero-titles.html'],
    ['fragment-mod-03', COMMON_BASE, 'create-box-newv2.html'],
    ['fragment-mod-04', HOME_MODULES_BASE, 'classify-ai-tools.html'],
    ['fragment-mod-05', HOME_MODULES_BASE, 'community-header.html'],
    ['fragment-mod-06', HOME_MODULES_BASE, 'community-toolbar.html'],
    ['fragment-mod-08', HOME_MODULES_BASE, 'community-loading.html'],
    ['fragment-mod-07', COMMON_BASE, 'community-masonry.html'],
    ['fragment-mod-09', HOME_MODULES_BASE, 'community-admin.html'],
    ['fragment-mod-10', HOME_MODULES_BASE, 'feedback-aside.html'],
  ];

  /** @type {Array<[URL, string]>} */
  var SCRIPTS_AFTER = [
    [COMMON_BASE, 'theme-toggle.js'],
    [HOME_MODULES_BASE, 'community-header.js'],
    [HOME_MODULES_BASE, 'feedback-aside.js'],
  ];

  function showFetchError(err) {
    var bar = document.createElement('div');
    bar.setAttribute('role', 'alert');
    bar.style.cssText =
      'position:fixed;left:0;right:0;top:0;z-index:99999;padding:12px 16px;background:#3d1a1a;color:#fff;font-size:14px;text-align:center;font-family:sans-serif;';
    bar.textContent =
      '无法加载模块 HTML（请使用本地静态服务打开 docs/demo，例如在项目根执行: npx serve docs/demo ，再访问 /pages/home/index.html）。';
    document.body.insertBefore(bar, document.body.firstChild);
    console.error('[home-assemble]', err);
  }

  function loadScriptSequential(list, index) {
    if (index >= list.length) {
      document.dispatchEvent(new CustomEvent('demo:fragments-ready', { bubbles: true }));
      return;
    }
    var base = list[index][0];
    var name = list[index][1];
    var s = document.createElement('script');
    s.src = new URL(name, base).href;
    s.onload = function () {
      loadScriptSequential(list, index + 1);
    };
    s.onerror = function () {
      console.error('[home-assemble] script failed:', s.src);
      loadScriptSequential(list, index + 1);
    };
    document.body.appendChild(s);
  }

  async function run() {
    try {
      for (var i = 0; i < PARTS.length; i++) {
        var id = PARTS[i][0];
        var base = PARTS[i][1];
        var file = PARTS[i][2];
        var el = document.getElementById(id);
        if (!el) {
          console.warn('[home-assemble] missing #' + id);
          continue;
        }
        var res = await fetch(new URL(file, base));
        if (!res.ok) {
          throw new Error(file + ' ' + res.status);
        }
        el.innerHTML = await res.text();
      }

      loadScriptSequential(SCRIPTS_AFTER, 0);
    } catch (e) {
      showFetchError(e);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();
