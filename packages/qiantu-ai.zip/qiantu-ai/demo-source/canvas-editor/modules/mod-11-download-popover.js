/**
 * 下载浮层：点击 #qtd-demo-download-trigger 显示/隐藏；
 * 点击文档其它区域或按 Escape 关闭。
 * 合并方式 Tab 仅切换演示态 .qtd-dl-tab--active。
 */
(function () {
  const TRIGGER_ID = 'qtd-demo-download-trigger';
  const POPOVER_ID = 'qtd-dl-popover';

  function init() {
    const trigger = document.getElementById(TRIGGER_ID);
    const popover = document.getElementById(POPOVER_ID);
    if (!trigger || !popover) return;

    function isOpen() {
      return popover.classList.contains('qtd-dl-popover--open');
    }

    function setOpen(open) {
      popover.classList.toggle('qtd-dl-popover--open', open);
      popover.setAttribute('aria-hidden', open ? 'false' : 'true');
      trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
    }

    trigger.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      setOpen(!isOpen());
    });

    document.addEventListener('click', function (e) {
      if (!isOpen()) return;
      const t = e.target;
      if (popover.contains(t) || trigger.contains(t)) return;
      setOpen(false);
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && isOpen()) {
        setOpen(false);
      }
    });

    popover.querySelectorAll('[data-qtd-merge]').forEach(function (tab) {
      tab.addEventListener('click', function () {
        popover.querySelectorAll('[data-qtd-merge]').forEach(function (btn) {
          btn.classList.toggle('qtd-dl-tab--active', btn === tab);
          btn.setAttribute('aria-selected', btn === tab ? 'true' : 'false');
        });
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
