/**
 * 悬浮工具栏：文字（.qtd-demo-text-target）与图片（.qtd-demo-image-target）共用逻辑；
 * 同时只显示一条；位置：选区水平居中、优先在选区上方。
 */
(function () {
  var VIS = 'qtd-float-toolbar--visible';

  var CONFIG = [
    {
      id: 'qtd-text-toolbar',
      selector: '.qtd-demo-text-target',
      reset: function (tb) {
        var fmt = tb.querySelector('.qtd-text-toolbar__format');
        if (fmt) fmt.classList.remove('qtd-text-toolbar__format--open');
      },
      bindExtras: function (tb) {
        var fmt = tb.querySelector('.qtd-text-toolbar__format');
        if (!fmt) return;
        fmt.addEventListener('click', function (e) {
          e.stopPropagation();
          fmt.classList.toggle('qtd-text-toolbar__format--open');
        });
      },
    },
    {
      id: 'qtd-image-toolbar',
      selector: '.qtd-demo-image-target',
      reset: function (tb) {
        var ai = tb.querySelector('.qtd-image-toolbar__ai');
        if (ai) ai.classList.remove('qtd-image-toolbar__ai--open');
      },
      bindExtras: function (tb) {
        var ai = tb.querySelector('.qtd-image-toolbar__ai');
        if (!ai) return;
        ai.addEventListener('click', function (e) {
          e.stopPropagation();
          ai.classList.toggle('qtd-image-toolbar__ai--open');
        });
      },
    },
  ];

  function init() {
    var toolbars = [];
    var flatTargets = [];

    CONFIG.forEach(function (cfg) {
      var el = document.getElementById(cfg.id);
      var nodes = document.querySelectorAll(cfg.selector);
      if (!el || !nodes.length) return;
      for (var i = 0; i < nodes.length; i++) flatTargets.push(nodes[i]);
      toolbars.push({ cfg: cfg, el: el, targets: nodes, activeTarget: null });
    });

    if (!toolbars.length) return;

    function hideOne(tb) {
      tb.activeTarget = null;
      tb.el.classList.remove(VIS);
      tb.el.setAttribute('aria-hidden', 'true');
      tb.cfg.reset(tb.el);
    }

    function hideAll() {
      toolbars.forEach(hideOne);
    }

    function isVisible(tb) {
      return tb.el.classList.contains(VIS);
    }

    function positionToolbar(toolbarEl, anchorEl) {
      var rect = anchorEl.getBoundingClientRect();
      var margin = 8;
      var estH = 56;
      var top = rect.top - margin - estH;
      if (top < 12) {
        top = rect.bottom + margin;
      }
      var left = rect.left + rect.width / 2;
      toolbarEl.style.left = left + 'px';
      toolbarEl.style.top = top + 'px';
    }

    function showFor(tb, targetEl) {
      toolbars.forEach(function (other) {
        if (other !== tb) hideOne(other);
      });
      tb.activeTarget = targetEl;
      tb.el.classList.add(VIS);
      tb.el.setAttribute('aria-hidden', 'false');
      requestAnimationFrame(function () {
        positionToolbar(tb.el, targetEl);
      });
    }

    toolbars.forEach(function (tb) {
      tb.cfg.bindExtras(tb.el);
      hideOne(tb);
    });

    toolbars.forEach(function (tb) {
      Array.prototype.forEach.call(tb.targets, function (node) {
        node.addEventListener('click', function (e) {
          e.stopPropagation();
          if (isVisible(tb) && tb.activeTarget === node) {
            hideOne(tb);
            return;
          }
          showFor(tb, node);
        });
      });
    });

    document.addEventListener(
      'click',
      function (e) {
        var t = e.target;
        var i;
        for (i = 0; i < toolbars.length; i++) {
          if (toolbars[i].el.contains(t)) return;
        }
        for (i = 0; i < flatTargets.length; i++) {
          if (flatTargets[i].contains(t)) return;
        }
        hideAll();
      },
      true
    );

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') hideAll();
    });

    window.addEventListener('resize', function () {
      toolbars.forEach(function (tb) {
        if (tb.activeTarget && isVisible(tb)) positionToolbar(tb.el, tb.activeTarget);
      });
    });

    window.addEventListener(
      'scroll',
      function () {
        toolbars.forEach(function (tb) {
          if (tb.activeTarget && isVisible(tb)) positionToolbar(tb.el, tb.activeTarget);
        });
      },
      true
    );
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
