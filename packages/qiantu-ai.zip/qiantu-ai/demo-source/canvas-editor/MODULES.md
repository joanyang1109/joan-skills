# 无限画布 UI 模块说明（静态还原）

参考页面：[canvas.58pic.com/zh-CN/canvas/127](https://canvas.58pic.com/zh-CN/canvas/127)（标题「未命名画板」）。本目录将页面按**视觉区块**拆成独立 HTML 片段与对应 CSS，公共色板与阴影集中在 `theme.css`。**不包含业务逻辑**（撤销/下载/缩放等仅为占位）。

本地整页预览：在浏览器中打开 `docs/demo/index.html`（或对该目录启本地静态服务后访问）。

---

## 文件一览

| 文件 | 说明 |
|------|------|
| `theme.css` | 全局 CSS 变量：背景、文字、品牌色、阴影、画布比例、层级等 |
| `index.html` | 串联全部模块的完整静态页，便于对照线上布局 |
| `reference-canvas-127.png` | 抓取参考页时的视口截图（便于设计对齐） |
| `modules/mod-01-*` ~ `mod-12-*` | 各模块独立片段与样式 |
| `modules/mod-11-download-popover.js` | 下载浮层：点击「下载」展开/收起，点击空白处或 Escape 关闭 |
| `modules/mod-12-text-toolbar.js` | 文字/图片悬浮工具栏：共用逻辑，互斥显示；点击标题、说明或海报图展示 |

---

## 模块对照表

### mod-01：点阵背景（`mod-01-background`）

- **作用**：全屏浅灰底 + 点状网格，模拟编辑器工作区。
- **用法**：给根节点（通常为 `body`）同时加 `qtd-demo-page`、`qtd-dot-bg`（见 `mod-01-background.css`）。
- **依赖**：`theme.css`。

### mod-02：中央画布（`mod-02-canvas-stage`）

- **作用**：居中白色画板卡片，内为 **一张图 + 标题 + 说明文案**；演示图使用千图预览 CDN（可在 HTML 中替换 `img` 的 `src`）。
- **可调**：`theme.css` 中 `--qtd-canvas-width`、高度由 `--qtd-canvas-aspect` 推导。
- **依赖**：`theme.css`。

### mod-03：左上返回（`mod-03-top-left`）

- **作用**：圆形白底返回按钮，顶/左各约 16px。
- **依赖**：`theme.css`。

### mod-04：顶部居中工具条（`mod-04-top-center-toolbar`）

- **作用**：与线上 `Header.tsx` 中 `.center` 一致：**上传、文字、形状(Mask)、画笔、素材库(Folder)**，使用 `src/components/Icons/index.tsx` 内同名 SVG。
- **样式**：公共类在 `theme.css` — `.qtd-canvas-toolbar-bar`、`.qtd-canvas-toolbar-bar--center`、`.qtd-canvas-toolbar-btn`；尺寸对齐 `Header.module.scss`（`padding: 8px`、`border-radius: 32px`、`gap: 12px`、`box-shadow: 0 2px 8px rgba(0,0,0,.25)`，图标区 `20px`、按钮命中区 `32px`）。
- **依赖**：`theme.css`。

### mod-05：右上历史与下载（`mod-05-top-right-actions`）

- **作用**：撤销、重做、竖线分隔、`DownloadIcon` +「下载」文案；图标同 `UndoIcon` / `RedoIcon` / `DownloadIcon`。
- **样式**：`.qtd-canvas-toolbar-bar--right`（`right: 24px` 与画布 Header 左右边距一致）、`.qtd-canvas-toolbar-download`。
- **依赖**：`theme.css`。

### mod-06：右侧反馈（`mod-06-right-feedback`）

- **作用**：竖向胶囊，图标 +「反馈」文案；`bottom` 需与右下视图条错开（默认约 `168px`，可按项目微调）。
- **依赖**：`theme.css`。
- **备注**：线上另有「旧版」等入口时，视觉与反馈同类，可拷贝结构改文案与图标。

### mod-07：左下缩放（`mod-07-bottom-zoom`）

- **作用**：「−、百分比、+」缩放控件；百分比为静态展示。
- **依赖**：`theme.css`。

### mod-08：底部居中画笔 FAB（`mod-08-bottom-center-pencil`）

- **作用**：圆形白底画笔/编辑入口，与顶栏工具风格一致。
- **依赖**：`theme.css`。

### mod-09：右下视图切换（`mod-09-bottom-right-views`）

- **作用**：图层、网格、布局三类视图；演示中「网格」为激活态。
- **依赖**：`theme.css`。

### mod-10：底部 AI 提示条（`mod-10-ai-prompt-bar`）

- **作用**：深色圆角条，含占位文案「请文字输入你想实现的创意灵感～」、`Agent` 标签、主操作「创作」及「免费」说明；布局与仓库内 `AiInputV2` 大输入条**概念对齐**，此处为纯静态简化版。
- **依赖**：`theme.css`（荧光绿按钮使用 `--qtd-accent-lime`）。
- **层级**：`--qtd-z-ai-bar` 高于普通悬浮控件，避免被遮挡。

### mod-11：下载浮层（`mod-11-download-popover`）

- **作用**：对齐 [canvas 画板](https://canvas.58pic.com/zh-CN/canvas/8519) 点击「下载」后 `ant-popover` 内容：**合为1张 / 共N张**、**格式**、**倍率**、**复制** + **商用下载**、下方 **字体授权提醒** 卡片（示例文案与线上截图一致时可对照 `DownloadPreviewContent`）。
- **样式**：`mod-11-download-popover.css`（宽约 `340px`，`fixed` 在右上，贴近顶栏下载按钮）；视觉参考仓库 `DownloadPreview.module.scss`。
- **交互**：`mod-11-download-popover.js` 绑定 `#qtd-demo-download-trigger`（顶栏下载按钮），点击切换显示；点击页面其它区域或按 `Escape` 关闭；「合为1张 / 共2张」仅切换 Tab 高亮（无真实导出）。
- **依赖**：`theme.css`（使用 `--new-text-*` 等，与 `theme.scss` 一致更佳）。

### mod-12：悬浮工具栏 — 文字 + 图片（`mod-12-text-toolbar`）

- **作用**：根容器统一为 `.qtd-float-toolbar`（原文字条外观），对齐 `shared.module.scss` 的 `@mixin toolbar`：圆角白底、约 56px 高、阴影。文字条对齐 `TextToolbar`；图片条对齐 `ImageToolbar`（`ImageToolbar.module.scss`）：**AI抠图**（带下拉示意）+ 选区 / 裁切 / 蒙版 / 删除等图标钮，**复用** `.qtd-text-toolbar__pill`、`.qtd-text-toolbar__divider`，图标用 `.qtd-float-toolbar__icon-btn`。
- **展示条件**：标题/说明为 `qtd-demo-text-target`，海报图为 `qtd-demo-image-target`（`mod-02` 已带）；点击后 `position: fixed`，水平居中于选区，优先在**上方**。文字条与图片条**同时只显示一条**（点另一侧会切换）。
- **交互**：`mod-12-text-toolbar.js` — 再次点击同一选区关闭；点页面其它区域或 `Escape` 关闭；「格式」「AI抠图」按钮仅切换高亮态。无画布业务，仅静态演示。
- **依赖**：`theme.css`。

---

## 主题变量（`theme.css` 摘要）

- **页面与网格**：`--qtd-page-bg`、`--qtd-dot-grid-color`、`--qtd-dot-grid-size`
- **表面与文字**：`--qtd-surface`、`--qtd-text-primary` / `secondary` / `muted`
- **品牌色**：`--qtd-accent-lime`、`--qtd-accent-olive`（选区、主按钮等）
- **AI 深色条**：`--qtd-ai-dark-bg`、`--qtd-ai-placeholder` 等
- **阴影**：`--qtd-shadow-float`、`--qtd-shadow-float-hover`

修改主题时优先改 `theme.css`，各 `mod-*.css` 已尽量引用变量。

---

## 与线上差异说明

- 线上为 React + Canvas 运行时，本套仅为 **HTML/CSS 外观切片**，无画布渲染、无接口。
- 画板内真实设计稿以用户作品为准；此处海报为 **占位示意**。
- 缩放百分比、Agent 文案等以线上实时数据为准。
