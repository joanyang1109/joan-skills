---
name: qiantu-qiye
description: >
  千图企业站（qiye.58pic.com）官方设计规范还原工具。从真实前端逆向提取的 HTML/CSS 模块，
  含首页、定价页、充值弹窗三个核心页面的完整源文件，class 名与线上代码直接对应，可交付前端开发使用。
  只要用户提到任何与千图企业站相关的需求——包括但不限于"千图企业"、"千图企业站"、"企业方案"、
  "企业授权"、"B端"、"企业VIP"、"企业充值"、"qiye.58pic"、"企业站demo"、"企业站风格"、
  "定价页"、"充值弹窗"、"中小微企业套餐"、"PLUS定制"——都应立即使用此 skill，无需等用户明确说出"用skill"。
---

# 千图企业站（qiantu-qiye）Demo 系统

## ⚡ 两套主题速查

| 页面 | 主题 | 主色 | 背景 |
|------|------|------|------|
| 首页（登录态工作台） | 深色 | `#1980FF` 纯蓝 | `#141414` |
| 定价页 `/enterprise/pricing` | 浅色 | `#FA5555` 红 | `#FFFFFF` |
| 充值弹窗 `/index.php?m=companyVip` | 浅色+渐变 | `rgb(250,85,85)` 红 | 渐变背景 |

> 企业站两套色系完全独立，不可混用——深色用于 app 工作台，浅色用于所有营销/购买页面。

---

## ⚠️ 关键色彩区分

| 区域 | 主色 | 用途 |
|------|------|------|
| 首页导航/交互 | `#1980FF` 纯蓝 | logo 圆圈、搜索按钮、激活态 |
| 定价页价格/CTA | `#FA5555` = `rgb(250,85,85)` | 价格数字、立即开通按钮 |
| 充值弹窗 | `rgb(250,85,85)` 红 + `rgb(119,41,23)` 深棕红 | 选中套餐边框、确认按钮 |

充值弹窗渐变背景：`linear-gradient(239deg, rgb(255,214,220) 0%, rgb(246,245,246) 26.54%)`

---

## 工作流程

### Step 1 — 判断需求，读对应源文件

源文件存放在 `assets/` 目录，class 名与线上代码一致，直接使用而非重建。

**首页（workspace 工作台）**
```
读: assets/enterprise-site/pages/home/index.html
读: assets/enterprise-site/pages/home/home.css
```

**定价页**
```
读: assets/enterprise-site/pages/pricing/index.html
读: assets/enterprise-site/pages/pricing/pricing.css
```

**充值弹窗**
```
读: assets/enterprise-site/modules/recharge-modal.html
读: assets/enterprise-site/modules/recharge-modal.css
```

**通用 tokens 和弹窗规范**
```
读: references/enterprise-site-tokens.md   （CSS 变量 + 组件 HTML/CSS + 页面骨架）
读: references/overlays.md                 （弹窗挂载规则、z-index 层级）
```

### Step 2 — 内联组装

将读取的 CSS 内联到 `<style>`，HTML 片段按布局顺序组合，输出**单个可运行 HTML 文件**。

### Step 3 — 只改这些，其余保持不动

- 文案、价格、活动信息等内容占位符
- 演示用 mock 数据
- 页面 `<title>`

保持 class 名与源文件一致，这样前端可以直接对照线上代码开发。

---

## 定价页商品数据（真实，截至 2026-04）

### 中小微企业VIP tab

| 档位 | 适用主体 | 价格/年 | 划线价 | 保障金 | AI点数/月 |
|------|---------|---------|--------|--------|----------|
| 个人版 | 注册资本≤100万｜个人 | ¥299 | ¥399 | 无 | — |
| 基础版 | 注册资本≤100万｜1主体 | ¥799 | ¥999 | ¥10,000 | 400点 |
| 专业版 | 注册资本≤200万｜1主体 | ¥1,599 | ¥1,999 | ¥20,000 | 800点 |
| 旗舰版 | 注册资本≤500万｜1主体 | ¥2,499 | ¥2,999 | ¥30,000 | 1,200点 |
| 转售版 | 注册资本≤2000万｜1主体 | ¥4,999 | ¥5,999 | ¥60,000 | 2,000点 |

### 大型企业定制PLUS tab

| 类型 | 入口 |
|------|------|
| 央企/国企/事业单位 | 在线开通 |
| 上市公司 / 集团公司 / 股份公司 | 联系客服定制 |
| 龙头企业（注册资本>2亿） | 联系客服定制 |

---

## CSS 变量速查

### 深色主题（首页工作台）
```css
--qte-bg-page:        #141414;
--qte-bg-card:        #1E1E1E;
--qte-brand-blue:     #1980FF;
--qte-text-primary:   #FFFFFF;
--qte-text-secondary: rgba(255,255,255,0.65);
--qte-border:         rgba(255,255,255,0.10);
```

### 浅色主题（定价页/充值弹窗）
```css
--vip-red:        #FA5555;
--vip-red-light:  rgb(252,179,187);
--vip-red-dark:   rgb(119,41,23);
--vip-bg-grad:    linear-gradient(239deg, rgb(255,214,220) 0%, rgb(246,245,246) 26.54%);
```

---

## 资源索引

### assets/（源文件，内联使用）

| 路径 | 内容 |
|------|------|
| `assets/enterprise-site/pages/home/index.html + home.css` | 首页：深色工作台，含双侧边栏、顶部导航、搜索框、AI 工具卡、内容瀑布流 |
| `assets/enterprise-site/pages/pricing/index.html + pricing.css` | 定价页：浅色，双 tab，真实商品数据，权益对比表 |
| `assets/enterprise-site/modules/recharge-modal.html + recharge-modal.css` | 充值弹窗：左侧权益展示 + 右侧套餐选择/支付/确认 |

### references/（规范文档，按需读取）

| 文件 | 内容 |
|------|------|
| `references/enterprise-site-tokens.md` | 完整 CSS 变量表、关键组件 HTML/CSS、页面骨架 |
| `references/overlays.md` | 弹窗挂载规则、z-index 层级、登录弹窗结构 |
