# 千图企业站 (qiye.58pic.com) 设计 Tokens

> 来源：qiye.58pic.com 真实界面逆向提取
> 用途：为企业站页面（企业方案、行业场景、定价页）生成 demo 时使用
> 前缀约定：`--qte-` (qiantu-enterprise)

## 目录

1. [视觉定位](#视觉定位)
2. [CSS 变量系统](#css-变量系统)
3. [视觉特征速查](#视觉特征速查)
4. [关键组件 HTML + CSS](#关键组件-html--css)
5. [完整页面骨架](#完整页面骨架)

---

## 视觉定位

企业站整体风格是**深色·宇宙·科技感**，与主站白净风完全不同：
- 纯深色背景 `#141414`，配合星空/宇宙背景图
- 主品牌色已更新为**纯蓝** `#1980FF`（logo 圆圈、搜索按钮、激活文字、类目渐变底色均用此色）
- 操作按钮（使用/AI生成）用**黄绿色** `#D4FD53`
- 旧的青绿渐变 `#40FFAA→#4079FF` 现在只用于 AI 生成加载动画，不再作为主品牌色
- Logo 徽章底色为 `#1980FF` 纯蓝圆形，区别于主站的绿圆圈
- 大标题有发光 / glow 效果
- CTA 按钮为白色实心，反差鲜明

---

## CSS 变量系统

```css
/* =============================================
   千图企业站 Design Tokens
   来源：qiye.58pic.com 真实界面逆向提取
   ============================================= */

:root, [data-product="enterprise"] {
  /* 主品牌色（2025年后更新为纯蓝） */
  --qte-brand-blue:       #1980FF;                /* ★ 主品牌色：logo圆圈、搜索按钮、激活文字 */
  --qte-blue-light:       #EBF7FF;                /* 浅蓝背景：VIP升级按钮hover */

  /* 操作按钮色 */
  --qte-lime-action:      #D4FD53;                /* 黄绿色：使用/AI生成 等操作按钮 */

  /* 旧品牌渐变（仅保留用于 AI 加载动画） */
  --qte-gradient-brand:   linear-gradient(to right, #40FFAA, #4079FF);   /* ⚠️ 仅动画/loading用，不再作主品牌色 */
  --qte-gradient-brand-v: linear-gradient(to bottom, #40FFAA, #4079FF);  /* ⚠️ 同上 */
  --qte-gradient-text:    linear-gradient(to right, #40FFAA, #6FA8FF);   /* 大标题 glow 效果（仍可用） */

  /* 背景色 */
  --qte-bg-page:          #141414;   /* 主背景：深炭黑 */
  --qte-bg-card:          #1E1E1E;   /* 卡片/区块背景 */
  --qte-bg-card-hover:    #252525;   /* 卡片 hover */
  --qte-bg-header:        rgba(20,20,20,0.85); /* header 半透明 */
  --qte-bg-pill:          rgba(255,255,255,0.08); /* 未激活 pill 背景 */

  /* 文字色 */
  --qte-text-primary:     #FFFFFF;
  --qte-text-secondary:   rgba(255,255,255,0.65);
  --qte-text-tertiary:    rgba(255,255,255,0.40);
  --qte-text-on-white:    #333333;   /* 白色按钮上的深色文字 */

  /* 强调色（共用） */
  --qte-green:            #00B277;   /* 与主站共用绿色，用于 badge */
  --qte-lime-badge:       rgba(178,255,0,0.4); /* 免费10点 badge */
  --qte-hot-coral:        #FF6B6B;   /* "热门" badge */
  --qte-blue-tag:         #1980FF;   /* 行业标签激活蓝（已从 #4C9EFF 更新） */

  /* 边框 */
  --qte-border:           rgba(255,255,255,0.10);
  --qte-border-glow:      rgba(64,255,170,0.3); /* 发光边框 */

  /* 阴影 */
  --qte-shadow-card:      0 4px 24px rgba(0,0,0,0.4);
  --qte-shadow-glow:      0 0 20px rgba(64,255,170,0.15);

  /* 尺寸 */
  --qte-header-height:    64px;
  --qte-content-max:      1200px;

  /* 圆角 */
  --qte-radius-pill:      888px;
  --qte-radius-card:      16px;
  --qte-radius-badge:     88px;
  --qte-radius-btn:       20px;
  --qte-radius-sm:        8px;
}
```

---

## 视觉特征速查

| 元素 | 规格 |
|------|------|
| 页面背景 | `#141414` 深色 + 宇宙星空背景图 |
| Logo | 纯蓝圆圈 `#1980FF`，"千图 企业商用图库"（旧版为渐变，已更新） |
| 搜索按钮 | `#1980FF` 纯蓝实心 |
| 激活 Tab / 激活文字 | `#1980FF` 纯蓝 |
| 操作按钮（使用/AI生成）| `#D4FD53` 黄绿色实心 |
| "主站" 按钮 | 白色描边 + 白色文字（outline 样式）|
| Hero 标题 | 大字白色/渐变文字，有 text-shadow glow |
| CTA "获取方案" | 白色实心 + 深色文字 + 20px 圆角 |
| 行业 Tab | 激活：白色 pill；未激活：半透明灰 |
| "每日免费10点" | `rgba(178,255,0,0.4)` 黄绿色，88px 圆角 |
| 内容卡片 | 深色 `#1E1E1E` + 16px 圆角 |
| 合作企业 Logo | 灰色/低透明度显示在深色背景上 |
| AI 加载动画 | `#40FFAA→#4079FF` 渐变（旧品牌色仅此处保留）|

---

## 关键组件 HTML + CSS

### Header

```html
<header class="qte-header">
  <div class="qte-header-inner">
    <div class="qte-header-left">
      <button class="qte-menu-btn">☰</button>
      <div class="qte-logo-badge">
        <div class="qte-logo-circle">千图</div>
        <span class="qte-enterprise-label">企业商用图库</span>
      </div>
      <button class="qte-mainsite-btn">主站</button>
      <nav class="qte-nav">
        <div class="qte-nav-item">所有分类 ▾</div>
        <div class="qte-nav-item">✦ 千图AI ▾</div>
      </nav>
    </div>
    <div class="qte-header-center">千图创意图库</div>
    <div class="qte-header-right">
      <button class="qte-icon-btn" title="VIP">◆</button>
      <button class="qte-icon-btn" title="钻石">▽</button>
      <button class="qte-btn-login">登录/注册</button>
    </div>
  </div>
</header>
```

```css
.qte-header {
  position: sticky; top: 0; z-index: 100;
  width: 100%; height: var(--qte-header-height);
  background: var(--qte-bg-header);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid var(--qte-border);
}
.qte-header-inner {
  display: flex; align-items: center;
  justify-content: space-between;
  height: 100%; padding: 0 20px; position: relative;
}
.qte-header-left, .qte-header-right {
  display: flex; align-items: center; gap: 10px;
}
.qte-header-center {
  position: absolute; left: 50%; transform: translateX(-50%);
  font-size: 18px; font-weight: 600; color: var(--qte-text-primary);
}
/* Logo 渐变徽章 */
.qte-logo-badge {
  display: flex; align-items: center; gap: 6px;
  padding: 4px 10px 4px 4px;
  background: linear-gradient(135deg, rgba(64,255,170,0.2), rgba(64,121,255,0.2));
  border: 1px solid rgba(64,255,170,0.3);
  border-radius: 20px;
}
.qte-logo-circle {
  width: 30px; height: 30px; border-radius: 50%;
  background: var(--qte-brand-blue); /* 已更新：纯蓝 #1980FF，不再用渐变 */
  color: #fff; font-size: 11px; font-weight: 700;
  display: flex; align-items: center; justify-content: center;
}
.qte-enterprise-label {
  font-size: 13px; font-weight: 600; color: var(--qte-text-primary);
}
/* "主站" 按钮 */
.qte-mainsite-btn {
  padding: 5px 14px;
  background: none;
  border: 1px solid rgba(255,255,255,0.4);
  color: var(--qte-text-primary);
  border-radius: var(--qte-radius-btn);
  font-size: 13px; cursor: pointer;
  transition: all 0.15s;
}
.qte-mainsite-btn:hover { border-color: rgba(255,255,255,0.8); }
.qte-menu-btn {
  background: none; border: none; color: var(--qte-text-primary);
  font-size: 18px; cursor: pointer; padding: 4px;
}
.qte-nav { display: flex; align-items: center; gap: 4px; margin-left: 4px; }
.qte-nav-item {
  padding: 6px 12px; font-size: 14px; color: var(--qte-text-secondary);
  cursor: pointer; border-radius: 6px; transition: all 0.15s;
}
.qte-nav-item:hover { background: var(--qte-bg-pill); color: var(--qte-text-primary); }
.qte-btn-login {
  padding: 7px 18px;
  border: 1px solid rgba(255,255,255,0.5);
  color: var(--qte-text-primary);
  background: none;
  border-radius: var(--qte-radius-btn);
  font-size: 14px; cursor: pointer; transition: all 0.15s;
}
.qte-btn-login:hover { background: rgba(255,255,255,0.08); }
.qte-icon-btn {
  background: none; border: none; color: var(--qte-text-secondary);
  cursor: pointer; font-size: 16px; padding: 6px; border-radius: 50%;
  transition: background 0.15s;
}
.qte-icon-btn:hover { background: var(--qte-bg-pill); }
```

---

### Hero 区域

```html
<div class="qte-hero">
  <!-- 搜索区 -->
  <div class="qte-search-area">
    <div class="qte-search-tabs">
      <button class="qte-stab active">搜素材</button>
      <button class="qte-stab">AI创作</button>
      <span class="qte-free-badge">每日免费10点</span>
    </div>
    <div class="qte-search-box">
      <span>🔍</span>
      <input class="qte-search-input" placeholder="搜索关键词或粘贴图片找相似..." />
      <button class="qte-search-cam">📷</button>
      <button class="qte-search-btn">→</button>
    </div>
  </div>
  <!-- Hero 文案 -->
  <div class="qte-hero-content">
    <p class="qte-hero-sub">企业级 AI 创意引擎</p>
    <h1 class="qte-hero-title">视觉创意图库</h1>
    <button class="qte-cta-btn">获取方案</button>
  </div>
</div>
```

```css
.qte-hero {
  min-height: 100vh;
  background: var(--qte-bg-page)
    radial-gradient(ellipse at center, rgba(30,30,60,0.8) 0%, rgba(20,20,20,1) 70%);
  display: flex; flex-direction: column; align-items: center;
  justify-content: flex-start; padding: 20px 20px 60px; gap: 60px;
  position: relative; overflow: hidden;
}
/* 星空粒子效果（CSS伪代码可替换为 canvas/图片） */
.qte-hero::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(circle at 20% 50%, rgba(64,255,170,0.05) 0%, transparent 50%),
              radial-gradient(circle at 80% 20%, rgba(64,121,255,0.05) 0%, transparent 50%);
  pointer-events: none;
}
/* 搜索区（复用主站搜索样式，颜色适配深色） */
.qte-search-area { width: 100%; max-width: 860px; display: flex; flex-direction: column; gap: 10px; align-items: center; }
.qte-search-tabs { display: flex; align-items: center; gap: 0; }
.qte-stab {
  padding: 6px 16px; background: none; border: none;
  font-size: 15px; color: var(--qte-text-secondary);
  cursor: pointer; border-bottom: 2px solid transparent; transition: all 0.15s;
}
.qte-stab.active { color: var(--qte-text-primary); font-weight: 600; border-bottom-color: #40FFAA; }
.qte-free-badge {
  margin-left: 10px; padding: 2px 10px;
  background: var(--qte-lime-badge);
  border-radius: var(--qte-radius-badge);
  font-size: 12px; color: #333;
}
.qte-search-box {
  display: flex; align-items: center; width: 100%; height: 52px;
  background: rgba(255,255,255,0.95);
  border-radius: var(--qte-radius-pill); padding: 0 8px 0 16px; gap: 8px;
}
.qte-search-input {
  flex: 1; border: none; outline: none;
  font-size: 14px; color: #333; background: transparent;
}
.qte-search-input::placeholder { color: #999; }
.qte-search-cam { background: none; border: none; cursor: pointer; font-size: 18px; padding: 4px; color: #999; }
.qte-search-btn {
  width: 40px; height: 40px; border-radius: 50%;
  background: var(--qte-brand-blue); border: none; color: #fff; /* 已更新：#1980FF */
  font-size: 18px; cursor: pointer;
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
/* Hero 文案 */
.qte-hero-content {
  display: flex; flex-direction: column; align-items: center; gap: 16px;
  text-align: center;
}
.qte-hero-sub {
  font-size: 18px; color: var(--qte-text-secondary); letter-spacing: 0.05em;
}
.qte-hero-title {
  font-size: 64px; font-weight: 800; letter-spacing: -0.02em;
  background: var(--qte-gradient-text);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text;
  text-shadow: none;
  filter: drop-shadow(0 0 30px rgba(64,255,170,0.4));
}
.qte-cta-btn {
  padding: 14px 40px;
  background: #FFFFFF; color: var(--qte-text-on-white);
  border: none; border-radius: var(--qte-radius-btn);
  font-size: 16px; font-weight: 600; cursor: pointer;
  transition: all 0.2s;
  box-shadow: 0 4px 20px rgba(0,0,0,0.3);
}
.qte-cta-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 28px rgba(0,0,0,0.4); }
```

---

### 合作企业 Logo 展示

```html
<div class="qte-partners">
  <p class="qte-partners-title">被多家行业头部企业选择</p>
  <div class="qte-partners-logos">
    <div class="qte-partner-logo">携程</div>
    <div class="qte-partner-logo">中国移动</div>
    <div class="qte-partner-logo">Amazon</div>
    <div class="qte-partner-logo">太平洋保险</div>
    <div class="qte-partner-logo">招商银行</div>
    <div class="qte-partner-logo">美的 Midea</div>
  </div>
</div>
```

```css
.qte-partners {
  padding: 60px 20px;
  text-align: center;
  border-top: 1px solid var(--qte-border);
}
.qte-partners-title {
  font-size: 16px; color: var(--qte-text-secondary); margin-bottom: 32px;
}
.qte-partners-logos {
  display: flex; align-items: center; justify-content: center;
  gap: 48px; flex-wrap: wrap;
}
.qte-partner-logo {
  font-size: 16px; color: rgba(255,255,255,0.3);
  font-weight: 600; letter-spacing: 0.02em;
  transition: color 0.2s;
}
.qte-partner-logo:hover { color: rgba(255,255,255,0.7); }
```

---

### 行业场景模块

```html
<div class="qte-industry">
  <h2 class="qte-section-title">行业场景内容库+AI 解决方案</h2>
  <div class="qte-industry-tabs">
    <button class="qte-itab active">营销设计</button>
    <button class="qte-itab">社交媒体</button>
    <button class="qte-itab">AI人工智能</button>
    <button class="qte-itab">医药连锁</button>
    <button class="qte-itab">党政媒体</button>
    <button class="qte-itab">金融理财</button>
    <button class="qte-itab">电商直播</button>
    <button class="qte-itab">新能源汽车</button>
    <button class="qte-itab">生活服务</button>
  </div>
  <div class="qte-industry-cards">
    <div class="qte-icard qte-icard-coral">
      <span class="qte-hot-tag">热门</span>
      <h3>甲方总说设计太土？万款潮流模板拉高审美</h3>
    </div>
    <div class="qte-icard qte-icard-blue">
      <h3>甲方在会议室等着看？在线改字无需PS秒出成品</h3>
    </div>
  </div>
</div>
```

```css
.qte-industry {
  padding: 60px 20px;
  max-width: var(--qte-content-max); margin: 0 auto;
}
.qte-section-title {
  font-size: 28px; font-weight: 700; color: var(--qte-text-primary);
  text-align: center; margin-bottom: 32px;
}
.qte-industry-tabs {
  display: flex; gap: 8px; flex-wrap: wrap; justify-content: center; margin-bottom: 28px;
}
.qte-itab {
  padding: 8px 20px; border: none; cursor: pointer;
  border-radius: var(--qte-radius-pill); font-size: 14px;
  background: var(--qte-bg-pill); color: var(--qte-text-secondary);
  transition: all 0.15s;
}
.qte-itab.active {
  background: #FFFFFF; color: #333; font-weight: 600;
}
.qte-itab:hover:not(.active) { background: rgba(255,255,255,0.12); color: var(--qte-text-primary); }
.qte-industry-cards {
  display: grid; grid-template-columns: 1fr 1fr; gap: 16px;
}
.qte-icard {
  border-radius: var(--qte-radius-card); padding: 28px 24px;
  position: relative; min-height: 200px; cursor: pointer;
  transition: transform 0.2s;
}
.qte-icard:hover { transform: translateY(-3px); }
.qte-icard-coral { background: linear-gradient(135deg, #FF7B7B, #FF5C5C); }
.qte-icard-blue  { background: linear-gradient(135deg, #4C9EFF, #6B5BFF); }
.qte-icard h3 { font-size: 20px; font-weight: 700; color: #fff; line-height: 1.4; }
.qte-hot-tag {
  display: inline-block; padding: 2px 8px;
  background: rgba(255,255,255,0.25); color: #fff;
  border-radius: 4px; font-size: 12px; margin-bottom: 12px;
}
```

---

## 完整页面骨架

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>千图企业站 - [页面标题]</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, "PingFang SC", "Helvetica Neue", Arial, sans-serif;
      background: var(--qte-bg-page); color: var(--qte-text-primary);
    }
    /* 粘贴上方 CSS 变量 + 组件样式 */
    .qte-layout { display: flex; flex-direction: column; min-height: 100vh; }
  </style>
</head>
<body>
<div class="qte-layout">
  <!-- 1. Header -->
  <!-- 2. Hero（全屏，含搜索 + 大标题 + CTA） -->
  <!-- 3. 合作企业 Logo 区 -->
  <!-- 4. 行业场景模块 -->
  <!-- 5. 定价/方案模块（可选） -->
</div>
</body>
</html>
```
