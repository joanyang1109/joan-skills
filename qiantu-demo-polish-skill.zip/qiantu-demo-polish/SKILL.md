---
name: qiantu-demo-polish
description: >
  千图系 demo 后处理通用工具。用于在现有 HTML demo 完成后，补充页面上方的需求板块，
  并在本次修改区域自动增加 hover 逻辑说明卡片。适用于千图AI、千图主站、千图企业站、
  千图智能设计等 demo。用户提到"添加需求板块""补需求背景目的目标""加逻辑说明卡片"
  "给 demo 做交付包装"时触发。
---

# 千图 Demo 后处理

## 适用范围

- 只用于已经完成主体页面的千图系 HTML demo
- 负责补充交付说明，不负责重做主体业务内容
- 适用于千图AI、千图主站、千图企业站、千图智能设计

## 默认动作

1. 读取当前 demo HTML，识别页面导航、主内容区和本次主要改动区域
2. 在页面上方增加独立需求板块（PRD Banner），位置必须在导航上方，不被 `fixed` / `sticky` 导航遮挡
3. 在本次修改区域自动增加 hover 逻辑说明卡片，不需要用户额外指定位置
4. 保持页面原有风格和结构，只新增必要的标记类

## 需求板块样式规范（强制锁定）

需求板块的 HTML 结构、CSS 样式、配色、hover 交互、动画必须与标准模板完全一致，**禁止任何自行更改**。

以下是需求板块涉及的全部 CSS 和 HTML 模板代码。生成时**原样复制**，只替换占位文案。

### CSS 模板（原样写入 `<style>` 中）

```css
/* ============================== */
/* PRD TOP BANNER                 */
/* ============================== */
.prd-banner {
  background: linear-gradient(135deg, rgba(180,83,9,.07) 0%, rgba(255,246,220,.55) 50%, rgba(180,83,9,.05) 100%);
  border-bottom: 1.5px solid rgba(180,83,9,.18);
  font-size: 12px; color: #5a3a00; font-weight: 600; line-height: 1.6;
  overflow: visible;
  position: relative; z-index: 200;
}
.prd-pills-wrap {
  overflow: hidden;
  max-height: 200px;
  transition: max-height .38s cubic-bezier(.4,0,.2,1), opacity .28s ease, padding .28s;
  opacity: 1;
}
.prd-banner.collapsed .prd-pills-wrap {
  max-height: 0;
  opacity: 0;
}
.prd-banner-in {
  max-width: 1480px; margin: 0 auto;
  padding: 14px 20px 16px;
}
.prd-banner-head {
  display: flex; align-items: center; justify-content: space-between;
  gap: 12px; margin-bottom: 13px; flex-wrap: wrap;
}
.prd-banner-meta {
  font-size: 10.5px; color: #a07030; font-weight: 600;
}
.prd-toggle-btn {
  display: inline-flex; align-items: center; gap: 5px;
  padding: 5px 13px; border-radius: 999px; font-size: 11px; font-weight: 800;
  background: rgba(255,255,255,.75); color: #92400e;
  border: 1.5px solid rgba(180,83,9,.22); cursor: pointer;
  transition: background 200ms ease, box-shadow 200ms ease;
  flex-shrink: 0;
}
.prd-toggle-btn:hover { background: #fff; box-shadow: 0 2px 8px rgba(180,83,9,.12); }
.prd-toggle-ico { display: inline-block; transition: transform .3s; font-style: normal; }

/* ── PRD Pill row ── */
.prd-pills-row {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

/* Pill base */
.prd-pill {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 7px;
  padding: 8px 18px 8px 14px;
  border-radius: 999px;
  font-size: 13px;
  font-weight: 700;
  letter-spacing: .01em;
  color: #fff;
  cursor: default;
  user-select: none;
  white-space: nowrap;
  transition: filter 180ms ease, transform 160ms ease, box-shadow 160ms ease;
}
.prd-pill:hover {
  filter: brightness(1.06);
  transform: translateY(-1px);
}
/* 需求背景 — 蓝色 */
.prd-pill.bg {
  background: linear-gradient(145deg, #3b82f6, #1e62d0);
  box-shadow: 0 3px 10px rgba(59,130,246,.38),
              inset 0 1px 0 rgba(255,255,255,.22);
}
/* 需求目的 — 绿色 */
.prd-pill.aim {
  background: linear-gradient(145deg, #45b035, #2d8a22);
  box-shadow: 0 3px 10px rgba(69,176,53,.38),
              inset 0 1px 0 rgba(255,255,255,.22);
}
/* 需求目标 — 琥珀色 */
.prd-pill.goal {
  background: linear-gradient(145deg, #f59e0b, #d97706);
  box-shadow: 0 3px 10px rgba(245,158,11,.38),
              inset 0 1px 0 rgba(255,255,255,.22);
}
/* Pill icon container */
.prd-pill-ico {
  width: 22px; height: 22px;
  border-radius: 50%;
  background: rgba(255,255,255,.2);
  display: flex; align-items: center; justify-content: center;
  font-size: 12px;
  flex-shrink: 0;
}
.prd-pill-label { font-size: 13px; font-weight: 700; }

/* ── Hover content card ── fixed 定位，由 JS 控制 ── */
.prd-pill-card {
  position: fixed;
  z-index: 9998;
  width: 320px;
  min-width: 260px;
  max-width: min(320px, calc(100vw - 24px));
  max-height: calc(100vh - 32px);
  overflow-y: auto;
  overscroll-behavior: contain;
  background: #fff;
  border-radius: 14px;
  padding: 16px 18px;
  font-size: 12.5px;
  font-weight: 500;
  line-height: 1.72;
  color: #374151;
  white-space: normal !important;
  overflow-wrap: break-word;
  word-break: break-word;
  pointer-events: none;
  opacity: 0;
  transform: translateY(6px);
  transition:
    opacity .2s cubic-bezier(.4,0,.2,1),
    transform .2s cubic-bezier(.4,0,.2,1);
  top: 0; left: 0;
}
.prd-pill-card.pc-visible {
  opacity: 1;
  transform: translateY(0);
  pointer-events: auto;
}
/* Color-matched border + shadow */
.prd-pill.bg   .prd-pill-card { border: 1.5px solid rgba(59,130,246,.28);  box-shadow: 0 8px 32px rgba(59,130,246,.14), 0 2px 8px rgba(0,0,0,.06); }
.prd-pill.aim  .prd-pill-card { border: 1.5px solid rgba(69,176,53,.28);   box-shadow: 0 8px 32px rgba(69,176,53,.14),  0 2px 8px rgba(0,0,0,.06); }
.prd-pill.goal .prd-pill-card { border: 1.5px solid rgba(245,158,11,.28);  box-shadow: 0 8px 32px rgba(245,158,11,.14), 0 2px 8px rgba(0,0,0,.06); }
/* Card header bar */
.prd-pill-card-head {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: 11px;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: .06em;
  margin-bottom: 10px;
  padding-bottom: 9px;
}
.prd-pill.bg   .prd-pill-card-head { color: #1e62d0; border-bottom: 1.5px solid rgba(59,130,246,.18); }
.prd-pill.aim  .prd-pill-card-head { color: #2d8a22; border-bottom: 1.5px solid rgba(69,176,53,.18); }
.prd-pill.goal .prd-pill-card-head { color: #b45309; border-bottom: 1.5px solid rgba(245,158,11,.2); }
/* Card caret arrow */
.prd-pill-card::before {
  content: '';
  position: absolute;
  top: -7px; left: 20px;
  border: 7px solid transparent;
  border-top: 0;
}
.prd-pill.bg   .prd-pill-card::before { border-bottom-color: rgba(59,130,246,.3); }
.prd-pill.aim  .prd-pill-card::before { border-bottom-color: rgba(69,176,53,.3); }
.prd-pill.goal .prd-pill-card::before { border-bottom-color: rgba(245,158,11,.3); }
/* Caret inner (white fill) */
.prd-pill-card::after {
  content: '';
  position: absolute;
  top: -5px; left: 21px;
  border: 6px solid transparent;
  border-top: 0;
  border-bottom-color: #fff;
}
/* Card text styles */
.prd-pill-card ul { padding-left: 15px; margin: 6px 0 0; }
.prd-pill-card li { margin: 4px 0; }
.prd-pill-card strong { font-weight: 700; color: #111; }
.prd-pill-card .one-liner {
  margin-top: 10px; padding: 7px 11px; border-radius: 8px;
  font-weight: 800; font-size: 12.5px; color: #2d8a22;
  background: rgba(69,176,53,.08); border: 1px solid rgba(69,176,53,.18);
}
.prd-pill-card .event-note {
  margin-top: 10px; padding: 7px 10px; border-radius: 8px;
  font-size: 11px; font-weight: 700; color: #92400e;
  background: rgba(245,158,11,.08); border: 1px solid rgba(245,158,11,.2);
}
@media (max-width: 860px) {
  .prd-pills-row { gap: 8px; }
  .prd-pill-card { width: 270px; }
}
```

### HTML 模板（原样写入 `<body>` 顶部，在导航之前）

```html
<!-- ======== PRD 核心摘要横幅 ======== -->
<div class="prd-banner" id="prdBanner">
  <!-- Header：始终可见 -->
  <div class="prd-banner-in" style="padding-bottom:0;">
    <div class="prd-banner-head">
      <div class="prd-banner-meta">来源：{{PRD_SOURCE}} &nbsp;·&nbsp; {{PRIORITY}} &nbsp;·&nbsp; {{OWNER}} &nbsp;·&nbsp; {{DATE}}</div>
      <button class="prd-toggle-btn" onclick="togglePrdBanner()" aria-label="收起/展开PRD摘要">
        <i class="prd-toggle-ico">▲</i><span class="prd-toggle-txt">收起</span>
      </button>
    </div>
  </div>
  <!-- Pills：可折叠区域 -->
  <div class="prd-pills-wrap" id="prdPillsWrap">
  <div class="prd-banner-in" style="padding-top:8px;">
    <div class="prd-pills-row">

      <!-- 📌 需求背景 -->
      <div class="prd-pill bg">
        <span class="prd-pill-ico">📌</span>
        <span class="prd-pill-label">需求背景</span>
        <div class="prd-pill-card">
          <div class="prd-pill-card-head">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
            需求背景
          </div>
          {{BG_CONTENT}}
        </div>
      </div>

      <!-- 🎯 需求目的 -->
      <div class="prd-pill aim">
        <span class="prd-pill-ico">🎯</span>
        <span class="prd-pill-label">需求目的</span>
        <div class="prd-pill-card">
          <div class="prd-pill-card-head">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/></svg>
            需求目的
          </div>
          {{AIM_CONTENT}}
        </div>
      </div>

      <!-- 📊 需求目标 -->
      <div class="prd-pill goal">
        <span class="prd-pill-ico">📊</span>
        <span class="prd-pill-label">需求目标</span>
        <div class="prd-pill-card">
          <div class="prd-pill-card-head">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 14l-5-5 1.41-1.41L12 14.17l7.59-7.59L21 8l-9 9z"/></svg>
            可量化目标
          </div>
          {{GOAL_CONTENT}}
        </div>
      </div>

    </div>
  </div>
  </div>
</div>
```

### JS 模板（原样写入 `<script>` 中）

```javascript
/* ====== PRD BANNER TOGGLE ====== */
function togglePrdBanner() {
  var banner = document.getElementById('prdBanner');
  var ico    = banner.querySelector('.prd-toggle-ico');
  var txt    = banner.querySelector('.prd-toggle-txt');
  var isCollapsed = banner.classList.toggle('collapsed');
  ico.style.transform = isCollapsed ? 'rotate(180deg)' : '';
  txt.textContent = isCollapsed ? '展开' : '收起';
}

/* ====== FIXED-POSITION TOOLTIP ENGINE (PRD Pills) ====== */
(function() {
  var MARGIN = 10;
  function placeCard(anchor, card, preferDir, visClass) {
    visClass = visClass || 'lc-visible';
    var vw = window.innerWidth;
    var vh = window.innerHeight;
    var cardW = card.offsetWidth  || 290;
    var cardH = card.offsetHeight || 200;
    var spaceBelow = vh - anchor.bottom - MARGIN;
    var spaceAbove = anchor.top - MARGIN;
    var goAbove;
    if (preferDir === 'above') goAbove = true;
    else if (preferDir === 'below') goAbove = false;
    else goAbove = spaceBelow < cardH && spaceAbove > spaceBelow;
    var top;
    if (goAbove) { top = anchor.top - cardH - MARGIN; if (top < 8) top = 8; }
    else { top = anchor.bottom + MARGIN; if (top + cardH > vh - 8) top = vh - cardH - 8; if (top < 8) top = 8; }
    var left = anchor.left;
    if (left + cardW > vw - 8) left = vw - cardW - 8;
    if (left < 8) left = 8;
    card.style.top  = top  + 'px';
    card.style.left = left + 'px';
  }
  document.querySelectorAll('.prd-pill').forEach(function(pill) {
    var card = pill.querySelector('.prd-pill-card');
    if (!card) return;
    document.body.appendChild(card);
    pill.addEventListener('mouseenter', function() {
      card.style.visibility = 'hidden';
      card.classList.add('pc-visible');
      placeCard(pill.getBoundingClientRect(), card, 'below', 'pc-visible');
      card.style.visibility = '';
    });
    pill.addEventListener('mouseleave', function() {
      card.classList.remove('pc-visible');
    });
  });
})();
```

### 样式锁定规则

- 上述 CSS / HTML / JS 是标准模板，**禁止修改**任何色值、尺寸、圆角、阴影、渐变、动画参数
- 只允许替换 `{{占位符}}` 中的业务文案
- 不允许新增、删除或重排 pill 的数量和顺序（固定为 背景→目的→目标）
- 不允许更改 pill 的 emoji 图标（固定为 📌 🎯 📊）
- 不允许更改 hover 卡片的定位逻辑和动画
- 如果页面已有 `placeCard` 函数（逻辑卡片也会用到），合并为同一个函数，不重复声明

---

## 逻辑说明卡片样式规范（强制锁定）

逻辑说明卡片同样有固定样式，禁止自行更改。

### CSS 模板

```css
/* ── Logic Zone: wrapper ── */
.logic-zone { position: relative; }

/* ── Logic Tooltip Card ── fixed 定位，由 JS 控制位置 ── */
.logic-card {
  position: fixed;
  z-index: 9999;
  min-width: 230px;
  max-width: 290px;
  width: max-content;
  max-height: calc(100vh - 32px);
  overflow-y: auto;
  overscroll-behavior: contain;
  background: #1a2236;
  color: #dce9f5;
  border-radius: 12px;
  padding: 13px 15px;
  font-size: 11.5px;
  line-height: 1.68;
  white-space: normal;
  overflow-wrap: break-word;
  word-break: break-word;
  box-shadow: 0 12px 40px rgba(0,0,0,.38), 0 2px 10px rgba(0,0,0,.22);
  border: 1px solid rgba(130,180,230,.22);
  pointer-events: none;
  opacity: 0;
  transform: translateY(6px);
  transition: opacity .2s cubic-bezier(.4,0,.2,1), transform .2s cubic-bezier(.4,0,.2,1);
  top: 0; left: 0;
}
.logic-card.lc-visible {
  opacity: 1;
  transform: translateY(0);
}
.logic-card.lc-below::before {
  content: '';
  position: absolute;
  top: -6px; left: 18px;
  border: 6px solid transparent;
  border-top: 0;
  border-bottom-color: #1a2236;
}
.logic-card.lc-above::before {
  content: '';
  position: absolute;
  bottom: -6px; left: 18px;
  border: 6px solid transparent;
  border-bottom: 0;
  border-top-color: #1a2236;
}
.lc-title {
  font-size: 10.5px;
  font-weight: 800;
  letter-spacing: .06em;
  text-transform: uppercase;
  color: #7dd3fc;
  margin-bottom: 8px;
  padding-bottom: 7px;
  border-bottom: 1px solid rgba(130,180,230,.18);
  display: flex;
  align-items: center;
  gap: 5px;
}
.lc-title .lc-dot {
  width: 6px; height: 6px; border-radius: 50%;
  background: #7dd3fc; flex-shrink: 0;
}
.lc-section {
  font-size: 10px;
  font-weight: 700;
  color: #94d3a2;
  letter-spacing: .04em;
  margin: 7px 0 3px;
  text-transform: uppercase;
}
.lc-section:first-of-type { margin-top: 2px; }
.logic-card ul { padding-left: 13px; margin: 0; }
.logic-card li { margin: 2px 0; }
.logic-card code {
  background: rgba(255,255,255,.12);
  padding: 1px 5px;
  border-radius: 3px;
  font-size: 10px;
  color: #fbbf24;
}
.logic-zone::after {
  content: '';
  position: absolute;
  inset: -3px;
  border-radius: 10px;
  border: 1.5px dashed rgba(86,165,224,.0);
  transition: border-color .2s;
  pointer-events: none;
  z-index: 1;
}
.logic-zone:hover::after {
  border-color: rgba(86,165,224,.32);
}
```

### HTML 模板

```html
<div class="logic-zone">
  <!-- 原有页面内容保持不变 -->

  <div class="logic-card">
    <div class="lc-title"><span class="lc-dot"></span>{{CARD_TITLE}}</div>
    {{CARD_BODY}}
  </div>
</div>
```

### JS 模板（逻辑卡片定位引擎）

```javascript
document.querySelectorAll('.logic-zone').forEach(function(zone) {
  var card = zone.querySelector(':scope > .logic-card');
  if (!card) return;
  document.body.appendChild(card);
  zone.addEventListener('mouseenter', function() {
    card.style.visibility = 'hidden';
    card.classList.add('lc-visible');
    placeCard(zone.getBoundingClientRect(), card, 'auto', 'lc-visible');
    card.style.visibility = '';
  });
  zone.addEventListener('mouseleave', function() {
    card.classList.remove('lc-visible', 'lc-above', 'lc-below');
  });
});
```

---

## 需求板块内容撰写规范

需求板块固定包含三部分：`需求背景` / `需求目的` / `需求目标`。

写法约束如下：

- 默认先读取 `references/requirement-block-template.md`
- 除非用户明确要求改结构，否则按模板骨架生成，不临时自由发挥章节

### 需求背景

- 只写 2-3 条，每条 1 句话
- 每条只讲一个现状事实或问题
- 必须用"当前 / 现有 / 用户在 ..."开头，直接说问题
- 禁止写"随着…的发展""为了…""基于…调研"等散文式开头
- 禁止复述已知过程，只写结论性现状

### 需求目的

- 只写 1 句话，不超过 30 字
- 只回答"为什么做这件事"，一个核心动词 + 一个核心结果
- 禁止写实现细节、技术方案、过程描述
- 禁止写"通过 A 来达到 B"的复合句，拆成结果句

### 需求目标

- 只写 1-2 条，优先 1 条
- **必须量化**，必须包含具体数字或可测量的结果描述
- 量化标准（至少满足其一）：
  - 带具体数值：转化率提升 X%、GMV 增加 X 万、DAU 增加 X
  - 带可测量的交付结果：X 天内上线、支撑 X 个渠道投放
  - 带明确的 0→1 判定：实现用户可直接完成 X 操作
- 禁止出现以下空目标：
  - "提升用户体验"
  - "优化页面表达"
  - "增强用户感知"
  - "提高转化效果"
  - 任何不带数字、不带衡量标准的目标
- 如果当前阶段确实无法给出精确数值，必须写明"具体数值目标由 X 评审后填入"，同时给出最低限度的可衡量结果（如"实现用户可完成 X 操作"）

---

## 逻辑说明卡片规则

- 卡片只加在本次修改区域
- 位置由页面改动自动判断，不需要用户指定
- 自动判断优先级如下：
  1. 本轮新增或改动最集中的区块
  2. 页面视觉上最明显的改动区域
  3. 与需求目标直接相关的核心交互区域
- 如果页面存在多个核心改动区，可以分别加卡片，但避免全页滥加

卡片文案约束如下：

- 标题：一个 emoji + 一句话概括改动范围（如 "🛒 充值页新增 AI VIP 商品"）
- 正文使用 `lc-section` 分节，默认结构：
  - `调整点`：本区域改了什么，为什么
  - `保留项`：哪些线上逻辑不变
  - `特殊说明`：限制、边界、依赖（可选，有则写）
- 每项 1 句话，结论先行，不写长段说明

---

## 页面改动约束

- 不主动改商品结构、权益内容、主业务文案，除非用户明确要求
- 不删除线上原有数据块、模型块、权益块
- 不在 HTML、CSS、JS 中加入注释（模板自带的注释保留）
- 新增样式使用上述模板中的类名，不另起新类名

## 交付要求

- 优先在原 demo 文件内完成改动；如果用户明确要求另存，再输出新文件
- 交付时说明：
  - 是否已补需求板块
  - 是否已补 hover 逻辑说明卡片
  - 改动位置大致范围
